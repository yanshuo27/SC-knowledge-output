"""BooksComTwAdapter（台版 / 博客来）解析与降级容错单测。

约定（参见 tasks.md 任务 10.2 与 design.md Testing Strategy）：
- 使用 tests/adapters/fixtures/ 下录制的博客来 HTML 片段作为夹具。
- 用 pytest-httpx 的 httpx_mock 拦截请求，**绝不发起真实网络请求**。
- async 测试依赖 pyproject 中 asyncio_mode = "auto"，无需逐个标注。

覆盖点：
1. search 能从搜索结果页解析出候选列表（书名/作者/出版社/candidate_id/url）。
2. fetch 能从商品页解析出字段（书名/作者/出版社/定价 TWD/ISBN/出版日期/判型/latest_volume）。
3. 页面结构异常 / 空页面 / 网络错误 / HTTP 4xx-5xx → 降级为空结果，绝不外抛。
"""

from __future__ import annotations

from pathlib import Path

import httpx
import pytest

from app.shared import config
from app.modules.book_lookup.adapters.books_com_tw import BooksComTwAdapter
from app.modules.book_lookup.models import Candidate

_FIXTURES = Path(__file__).parent / "fixtures"


def _read_fixture(name: str) -> str:
    return (_FIXTURES / name).read_text(encoding="utf-8")


@pytest.fixture
def adapter() -> BooksComTwAdapter:
    return BooksComTwAdapter()


# ---------------------------------------------------------------------------
# search 解析
# ---------------------------------------------------------------------------


async def test_search_parses_candidates(adapter: BooksComTwAdapter, httpx_mock):
    """搜索页解析出候选，字段映射正确，异常条目被跳过。"""
    httpx_mock.add_response(text=_read_fixture("books_com_tw_search.html"))

    async with httpx.AsyncClient() as client:
        candidates = await adapter.search("葬送的芙莉蓮", client)

    # 夹具有 3 条 <li.item>，其中第 3 条无链接应被跳过 → 剩 2 条。
    assert len(candidates) == 2

    first = candidates[0]
    assert first.title == "葬送的芙莉蓮 1"
    assert first.author == "山田鐘人"
    assert first.publisher == "東立出版社"
    assert first.source == config.SOURCE_BOOKS_COM_TW
    # candidate_id 使用商品 id：books_com_tw:0010901234
    assert first.candidate_id == f"{config.SOURCE_BOOKS_COM_TW}:0010901234"
    # url 被规范化补全协议头并放入 identifiers。
    assert first.identifiers["url"] == "https://www.books.com.tw/products/0010901234"


async def test_search_empty_page_returns_empty(adapter: BooksComTwAdapter, httpx_mock):
    """空页面（无任何商品条目）降级为空列表，不抛异常。"""
    httpx_mock.add_response(text="<html><body>no results</body></html>")

    async with httpx.AsyncClient() as client:
        candidates = await adapter.search("不存在的书", client)

    assert candidates == []


async def test_search_http_error_returns_empty(adapter: BooksComTwAdapter, httpx_mock):
    """HTTP 5xx → 降级为空列表，不外抛。"""
    httpx_mock.add_response(status_code=503)

    async with httpx.AsyncClient() as client:
        candidates = await adapter.search("葬送的芙莉蓮", client)

    assert candidates == []


async def test_search_network_error_returns_empty(adapter: BooksComTwAdapter, httpx_mock):
    """网络异常（连接失败）→ 降级为空列表，不外抛。"""
    httpx_mock.add_exception(httpx.ConnectError("boom"))

    async with httpx.AsyncClient() as client:
        candidates = await adapter.search("葬送的芙莉蓮", client)

    assert candidates == []


# ---------------------------------------------------------------------------
# fetch 解析
# ---------------------------------------------------------------------------


def _make_candidate(url: str | None) -> Candidate:
    identifiers = {"url": url} if url is not None else {}
    return Candidate(
        candidate_id=f"{config.SOURCE_BOOKS_COM_TW}:0010901234",
        title="葬送的芙莉蓮 13",
        source=config.SOURCE_BOOKS_COM_TW,
        identifiers=identifiers,
    )


async def test_fetch_parses_product_fields(adapter: BooksComTwAdapter, httpx_mock):
    """商品页字段映射正确，包含定价 TWD、ISBN、出版日期、判型、latest_volume。"""
    httpx_mock.add_response(text=_read_fixture("books_com_tw_product.html"))
    candidate = _make_candidate("https://www.books.com.tw/products/0010901234")

    async with httpx.AsyncClient() as client:
        record = await adapter.fetch(candidate, config.EDITION_TW, client)

    assert record is not None
    assert record.edition == config.EDITION_TW
    assert record.source == config.SOURCE_BOOKS_COM_TW
    assert record.title == "葬送的芙莉蓮 13"
    assert record.author == "山田鐘人"
    assert record.publisher == "東立出版社"
    # 定价必须成对（金额 + 币种 TWD）。
    assert record.price is not None
    assert record.price.amount == 140.0
    assert record.price.currency == "TWD"
    assert record.isbn == "9789573289012"
    assert record.publish_date == "2021-08-10"
    assert record.format == "25開"
    # 从书名尾部数字推断最新册数。
    assert record.latest_volume == 13
    # 博客来不提供连载状态/总卷数，置 None（交由 Merger）。
    assert record.serialization_status is None
    assert record.total_volumes is None


async def test_fetch_missing_url_returns_none(adapter: BooksComTwAdapter):
    """candidate 无商品 url → 直接返回 None（不发请求）。"""
    candidate = _make_candidate(None)
    async with httpx.AsyncClient() as client:
        record = await adapter.fetch(candidate, config.EDITION_TW, client)
    assert record is None


async def test_fetch_malformed_page_returns_none(adapter: BooksComTwAdapter, httpx_mock):
    """页面结构异常（无 <h1> 书名）→ 降级为 None，不外抛。"""
    httpx_mock.add_response(text="<html><body><div>broken</div></body></html>")
    candidate = _make_candidate("https://www.books.com.tw/products/0010901234")

    async with httpx.AsyncClient() as client:
        record = await adapter.fetch(candidate, config.EDITION_TW, client)

    assert record is None


async def test_fetch_http_error_returns_none(adapter: BooksComTwAdapter, httpx_mock):
    """商品页 HTTP 404 → 降级为 None。"""
    httpx_mock.add_response(status_code=404)
    candidate = _make_candidate("https://www.books.com.tw/products/0010901234")

    async with httpx.AsyncClient() as client:
        record = await adapter.fetch(candidate, config.EDITION_TW, client)

    assert record is None


async def test_fetch_network_error_returns_none(adapter: BooksComTwAdapter, httpx_mock):
    """商品页网络异常 → 降级为 None，不外抛。"""
    httpx_mock.add_exception(httpx.ConnectTimeout("timeout"))
    candidate = _make_candidate("https://www.books.com.tw/products/0010901234")

    async with httpx.AsyncClient() as client:
        record = await adapter.fetch(candidate, config.EDITION_TW, client)

    assert record is None


# ---------------------------------------------------------------------------
# 类属性契约
# ---------------------------------------------------------------------------


def test_adapter_metadata(adapter: BooksComTwAdapter):
    """name / supported_editions 与 config 常量一致。"""
    assert adapter.name == config.SOURCE_BOOKS_COM_TW
    assert adapter.supported_editions == [config.EDITION_TW]
