"""前端静态断言测试（任务 15.4）。

用 Python 读取 web/index.html 与 web/app.js 源码，做静态结构断言，验证前端页面
与交互脚本满足需求，而不引入 Playwright / jsdom 等浏览器/DOM 运行时依赖。

断言范围（对应 tasks.md 15.4）：
- index.html：书名输入框、查询按钮、Loading 区、候选列表区、四版本表格容器、
  免责说明区、warnings/错误提示区存在；引用 app.js 与 style.css。
- app.js：包含 /api/search 与 /api/detail 调用、渲染四版本、从后端响应取
  placeholder（不硬编码整版占位文本）、渲染 N/A 字段值（不硬编码占位文本）、
  展示 disclaimer 与 warnings、请求失败/Loading 处理。

_Requirements: 4.5, 6.5, 8.4, 10.1, 10.4, 10.5, 11.1, 11.2, 11.3_
"""

from __future__ import annotations

from pathlib import Path

import pytest

from app.shared import config

_WEB_DIR = Path(__file__).resolve().parent.parent / "web"
_INDEX_HTML = _WEB_DIR / "index.html"
_APP_JS = _WEB_DIR / "app.js"
_STYLE_CSS = _WEB_DIR / "style.css"


@pytest.fixture(scope="module")
def index_html() -> str:
    return _INDEX_HTML.read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def app_js() -> str:
    return _APP_JS.read_text(encoding="utf-8")


# =============================================================================
# 前端文件存在性
# =============================================================================


def test_web_files_exist():
    """三个前端文件均存在。"""
    assert _INDEX_HTML.is_file(), "web/index.html 应存在"
    assert _APP_JS.is_file(), "web/app.js 应存在"
    assert _STYLE_CSS.is_file(), "web/style.css 应存在"


# =============================================================================
# index.html 结构断言
# =============================================================================


def test_index_has_title_input(index_html: str):
    """书名输入框存在（R10.1）。"""
    assert 'id="title-input"' in index_html
    assert "<input" in index_html


def test_index_has_search_button(index_html: str):
    """查询按钮存在（R10.1）。"""
    assert 'id="search-btn"' in index_html
    assert "<button" in index_html


def test_index_has_loading_area(index_html: str):
    """Loading 指示区存在（R10.4）。"""
    assert 'id="loading"' in index_html


def test_index_has_candidates_area(index_html: str):
    """候选列表区存在（R8.4 / R10.2）。"""
    assert 'id="candidates-area"' in index_html
    assert 'id="candidates-list"' in index_html


def test_index_has_editions_table_container(index_html: str):
    """四版本对照表格容器存在（R11.1 / R11.2）。"""
    assert 'id="editions-area"' in index_html
    assert 'id="editions-table"' in index_html
    assert 'id="editions-thead"' in index_html
    assert 'id="editions-tbody"' in index_html


def test_index_has_disclaimer_area(index_html: str):
    """免责说明区存在（R4.5）。"""
    assert 'id="disclaimer-area"' in index_html


def test_index_has_error_and_warnings_area(index_html: str):
    """错误提示区与 warnings 提示区存在（R6.5 / R10.5）。"""
    assert 'id="error-area"' in index_html
    assert 'id="warnings-area"' in index_html


def test_index_references_app_js_and_style_css(index_html: str):
    """index.html 引用 app.js 与 style.css。"""
    assert "app.js" in index_html
    assert "style.css" in index_html


# =============================================================================
# app.js 交互/渲染断言
# =============================================================================


def test_app_js_calls_search_api(app_js: str):
    """app.js 调用 /api/search（R10.2）。"""
    assert "/api/search" in app_js


def test_app_js_calls_detail_api(app_js: str):
    """app.js 调用 /api/detail（R10.3）。"""
    assert "/api/detail" in app_js


def test_app_js_uses_fetch(app_js: str):
    """app.js 使用 fetch 发起请求。"""
    assert "fetch(" in app_js


def test_app_js_renders_four_editions(app_js: str):
    """app.js 渲染四版本对照表格（遍历 editions 键构建表格）。"""
    assert "editions" in app_js
    # 渲染四版本表格的函数存在。
    assert "renderEditions" in app_js
    # 遍历 editions 的键构建列。
    assert "Object.keys(editions)" in app_js or "editionKeys" in app_js


def test_app_js_reads_placeholder_from_response(app_js: str):
    """整版缺失从后端响应的 placeholder 字段取值渲染（R11.4 / Property 20）。"""
    assert "placeholder" in app_js
    # 判定 present=false 后取 placeholder。
    assert "present" in app_js


def test_app_js_does_not_hardcode_placeholder_text(app_js: str):
    """app.js 不硬编码整版占位文本，保证前后端文案同源（R13.4 / Property 20）。"""
    assert config.MISSING_EDITION_PLACEHOLDER not in app_js
    # 也不应硬编码未知标记文本（应直接渲染后端返回的字段值）。
    # 允许注释性说明，但代码不应把 N/A 作为默认填充值；此处仅断言不含独立的
    # UNKNOWN_MARKER 字符串常量赋值。这里以"不出现该文本"作为最简约束。
    assert config.UNKNOWN_MARKER not in app_js


def test_app_js_shows_disclaimer(app_js: str):
    """app.js 展示后端返回的 disclaimer 免责说明（R4.5）。"""
    assert "disclaimer" in app_js


def test_app_js_shows_warnings(app_js: str):
    """app.js 渲染 warnings 提示（R6.5）。"""
    assert "warnings" in app_js
    assert "renderWarnings" in app_js


def test_app_js_handles_loading(app_js: str):
    """app.js 显示与移除 Loading（R10.4 / R10.5）。"""
    assert "showLoading" in app_js
    assert "hideLoading" in app_js


def test_app_js_handles_no_candidates(app_js: str):
    """无候选时提示"未找到匹配作品"（R8.4）。"""
    assert "未找到匹配作品" in app_js


def test_app_js_handles_request_failure(app_js: str):
    """请求失败时展示友好错误并移除 Loading（R6.5 / R10.5）。"""
    # 通过 try/catch 捕获异常并调用 showError；finally 中 hideLoading。
    assert "catch" in app_js
    assert "showError" in app_js
