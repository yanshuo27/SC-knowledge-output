"""Merger 合并去重层的 hypothesis 属性测试（Property 2/3/4/5/6/8/9/10/11/14）。

每条正确性属性用**单个** hypothesis 属性测试实现，`@settings(max_examples=100)`（≥100 迭代），
测试函数上方以注释标注对应设计属性，格式：
`# Feature: multi-edition-book-lookup, Property N: {property_text}`

生成器复用 tests/conftest.py 中定义的 strategies。
"""

from __future__ import annotations

from hypothesis import given, settings
from hypothesis import strategies as st

from app.shared import config
from app.modules.book_lookup.merger import Merger
from app.modules.book_lookup.models import (
    Candidate,
    EditionRecord,
    Price,
    RawEditionRecord,
    SerializationStatus,
)
from tests.conftest import (
    EDITIONS,
    KNOWN_SOURCES,
    ORDINARY_FIELDS,
    conflicting_field_raws,
    raw_edition_record,
    same_edition_raws,
)

_MERGER = Merger()

# 合并后连载状态的合法值域（枚举的字符串值）。
_STATUS_DOMAIN = {s.value for s in SerializationStatus}


def _all_ordinary_missing(raws: list[RawEditionRecord]) -> bool:
    """判断一组记录是否所有普通字段均缺失（用于预判整版占位）。"""
    for raw in raws:
        for attr in ORDINARY_FIELDS:
            if getattr(raw, attr) is not None:
                return False
    return True


# --- 任务 4.3 → Property 2 -----------------------------------------------------

# Feature: multi-edition-book-lookup, Property 2: 整版缺失恒为统一占位
@settings(max_examples=100)
@given(edition=st.sampled_from(EDITIONS), n=st.integers(min_value=1, max_value=5))
def test_property2_missing_edition_uses_uniform_placeholder(edition: str, n: int):
    """所有普通字段全缺失时 present=False 且 placeholder==MISSING_EDITION_PLACEHOLDER；
    且占位文本恒等于常量。"""
    # 构造一组"仅有 serialization_status 可能有值、普通字段全缺失"的记录。
    # 为了严格触发整版缺失，普通字段一律 None；状态字段也可能给值以验证其不影响判定。
    raws = [
        RawEditionRecord(
            edition=edition,
            source=KNOWN_SOURCES[i % len(KNOWN_SOURCES)],
            serialization_status=SerializationStatus.ONGOING if i % 2 == 0 else None,
        )
        for i in range(n)
    ]

    rec = _MERGER.merge(edition, raws)

    assert rec.present is False
    assert rec.placeholder == config.MISSING_EDITION_PLACEHOLDER
    # 占位文本恒为统一常量（同源）。
    assert rec.placeholder == "无此版本信息"


# --- 任务 4.4 → Property 3 -----------------------------------------------------

# Feature: multi-edition-book-lookup, Property 3: 缺失字段恒为统一 Unknown_Marker 而非报错
@settings(max_examples=100)
@given(raws=same_edition_raws())
def test_property3_missing_fields_uniform_unknown_marker(raws: list[RawEditionRecord]):
    """present=True 时，所有源都没提供的普通文本字段值恒==UNKNOWN_MARKER，
    绝不 None/缺键/异常。"""
    edition = raws[0].edition
    rec = _MERGER.merge(edition, raws)

    if not rec.present:
        # 全缺失场景由 Property 2 覆盖，这里只验证 present=True 分支。
        return

    # 检查纯文本普通字段（不含 price / total_volumes / latest_volume，它们有各自规则）。
    text_fields = ("title", "author", "publisher", "format", "isbn", "publish_date")
    for attr in text_fields:
        provided = any(getattr(r, attr) is not None for r in raws)
        value = getattr(rec, attr)
        # 恒不为 None（present=True 时字段必被落地）。
        assert value is not None, f"{attr} 不应为 None"
        if not provided:
            # 所有源都未提供 → 恒为统一 UNKNOWN_MARKER。
            assert value == config.UNKNOWN_MARKER == "N/A", (
                f"{attr} 缺失时应为统一标记 N/A，实际 {value!r}"
            )


# --- 任务 4.5 → Property 4 -----------------------------------------------------

# Feature: multi-edition-book-lookup, Property 4: 定价字段完整性
@settings(max_examples=100)
@given(raws=same_edition_raws())
def test_property4_price_completeness(raws: list[RawEditionRecord]):
    """price 要么是含 amount+currency 的完整 Price，要么==UNKNOWN_MARKER，无中间态。"""
    edition = raws[0].edition
    rec = _MERGER.merge(edition, raws)

    if not rec.present:
        return

    price = rec.price
    if isinstance(price, Price):
        # 完整 Price：amount 与 currency 均存在且类型正确。
        assert price.amount is not None
        assert isinstance(price.currency, str) and price.currency != ""
    else:
        # 否则只能是统一未知标记，不存在其他中间态。
        assert price == config.UNKNOWN_MARKER


# --- 任务 4.6 → Property 5 -----------------------------------------------------

# Feature: multi-edition-book-lookup, Property 5: 连载状态值域不变量
@settings(max_examples=100)
@given(raws=same_edition_raws())
def test_property5_serialization_status_domain(raws: list[RawEditionRecord]):
    """输出 serialization_status 恒 ∈ {完结,连载中,未知}；全缺失时为 未知。"""
    edition = raws[0].edition
    rec = _MERGER.merge(edition, raws)

    if not rec.present:
        return

    assert rec.serialization_status in _STATUS_DOMAIN

    # 当所有源均未提供状态时，恒为"未知"。
    no_status = all(r.serialization_status is None for r in raws)
    if no_status:
        assert rec.serialization_status == SerializationStatus.UNKNOWN.value


# --- 任务 4.7 → Property 6 -----------------------------------------------------

# Feature: multi-edition-book-lookup, Property 6: 连载中/未知则总卷数恒为 Unknown_Marker
@settings(max_examples=100)
@given(raws=same_edition_raws())
def test_property6_ongoing_or_unknown_total_volumes_is_unknown(
    raws: list[RawEditionRecord],
):
    """若最终状态 ∈ {连载中,未知} 则 total_volumes==UNKNOWN_MARKER，与源是否给数字无关。"""
    edition = raws[0].edition
    rec = _MERGER.merge(edition, raws)

    if not rec.present:
        return

    if rec.serialization_status in (
        SerializationStatus.ONGOING.value,
        SerializationStatus.UNKNOWN.value,
    ):
        assert rec.total_volumes == config.UNKNOWN_MARKER


# --- 任务 4.8 → Property 8 -----------------------------------------------------

# Feature: multi-edition-book-lookup, Property 8: 同一 Edition 多源合并为单条
@settings(max_examples=100)
@given(raws=same_edition_raws(min_size=1, max_size=6))
def test_property8_single_record_per_edition(raws: list[RawEditionRecord]):
    """输入≥1 条，输出恰好一个 EditionRecord。"""
    edition = raws[0].edition
    rec = _MERGER.merge(edition, raws)

    assert isinstance(rec, EditionRecord)
    assert rec.edition == edition


# --- 任务 4.9 → Property 9 -----------------------------------------------------

# Feature: multi-edition-book-lookup, Property 9: 合并字段取自各源的非缺失值
@settings(max_examples=100)
@given(raws=same_edition_raws())
def test_property9_merged_value_comes_from_some_source(raws: list[RawEditionRecord]):
    """若某字段至少一源非缺失，则输出值等于某源提供的那个非缺失值，
    不是 UNKNOWN_MARKER 也不凭空造。"""
    edition = raws[0].edition
    rec = _MERGER.merge(edition, raws)

    if not rec.present:
        return

    # 纯文本字段：输出值应等于某源提供的原始值。
    text_fields = ("title", "author", "publisher", "format", "isbn", "publish_date")
    for attr in text_fields:
        provided_values = [getattr(r, attr) for r in raws if getattr(r, attr) is not None]
        if provided_values:
            out = getattr(rec, attr)
            assert out in provided_values, (
                f"{attr} 输出 {out!r} 应取自源提供值 {provided_values!r}"
            )

    # price：若有源提供，输出应为其中某个 Price。
    provided_prices = [r.price for r in raws if r.price is not None]
    if provided_prices:
        assert rec.price in provided_prices

    # latest_volume：若有源提供数字，输出应为对应的数字字符串。
    provided_latest = [r.latest_volume for r in raws if r.latest_volume is not None]
    if provided_latest:
        assert rec.latest_volume in {str(v) for v in provided_latest}


# --- 任务 4.10 → Property 10 ---------------------------------------------------

# Feature: multi-edition-book-lookup, Property 10: 冲突按优先级选值并标注
@settings(max_examples=100)
@given(spec=conflicting_field_raws())
def test_property10_conflict_priority_and_annotation(
    spec: tuple[str, object, list[RawEditionRecord]],
):
    """同字段多源不同非缺失值时，输出==优先级最高源的值，且字段名 ∈ field_conflicts。"""
    field, expected_value, raws = spec
    edition = raws[0].edition
    rec = _MERGER.merge(edition, raws)

    # 冲突字段一定使 present=True（提供了非缺失普通字段）。
    assert rec.present is True

    # 输出值等于优先级最高源提供的值。
    assert getattr(rec, field) == expected_value

    # 字段名出现在 field_conflicts 中。
    assert field in rec.field_conflicts


# --- 任务 4.11 → Property 11 ---------------------------------------------------

# Feature: multi-edition-book-lookup, Property 11: 来源集合完整且去重
@settings(max_examples=100)
@given(raws=same_edition_raws())
def test_property11_sources_complete_and_deduped(raws: list[RawEditionRecord]):
    """sources==所有贡献过非缺失数据的源集合，去重、无遗漏无多余。"""
    edition = raws[0].edition
    rec = _MERGER.merge(edition, raws)

    if not rec.present:
        # 整版缺失时 sources 应为空。
        assert rec.sources == []
        return

    # 计算期望的贡献源集合：任一字段（普通字段 + serialization_status）非缺失即算贡献。
    contributing_attrs = list(ORDINARY_FIELDS) + ["serialization_status"]
    expected_sources: set[str] = set()
    for r in raws:
        if any(getattr(r, attr) is not None for attr in contributing_attrs):
            expected_sources.add(r.source)

    # 去重（无重复）。
    assert len(rec.sources) == len(set(rec.sources))
    # 集合相等（无遗漏、无多余）。
    assert set(rec.sources) == expected_sources


# --- 任务 4.12 → Property 14 ---------------------------------------------------

# Feature: multi-edition-book-lookup, Property 14: 部分字段缺失不触发整版占位
@settings(max_examples=100)
@given(raws=same_edition_raws())
def test_property14_partial_missing_no_edition_placeholder(
    raws: list[RawEditionRecord],
):
    """至少一非缺失普通字段 → present=True，缺失字段为 UNKNOWN_MARKER，不含整版占位。"""
    edition = raws[0].edition
    rec = _MERGER.merge(edition, raws)

    # 只考虑"确实有非缺失普通字段"的样本。
    if _all_ordinary_missing(raws):
        return

    assert rec.present is True
    # 不含整版占位。
    assert rec.placeholder is None

    # 缺失的纯文本普通字段恒为 UNKNOWN_MARKER。
    text_fields = ("title", "author", "publisher", "format", "isbn", "publish_date")
    for attr in text_fields:
        provided = any(getattr(r, attr) is not None for r in raws)
        if not provided:
            assert getattr(rec, attr) == config.UNKNOWN_MARKER


# =============================================================================
# Aggregator 编排层的 hypothesis 属性测试（Property 1/7/12/13）
# =============================================================================
#
# 这些测试用 fake adapter 在 asyncio 事件循环内验证并发/超时/失败隔离，不打真实网络。
# 采用"hypothesis 同步 @given 生成参数 + 函数体内 asyncio.run(协程)"的方式，
# 规避 hypothesis 与 async 测试的兼容问题（pytest-asyncio 的 event loop 与 hypothesis
# 多轮迭代复用不友好）。

import asyncio

from app.modules.book_lookup.aggregator import Aggregator
from app.modules.book_lookup.registry import AdapterRegistry
from tests.conftest import FakeAdapter, make_raw

# 一个占位候选，供 aggregate_editions 使用。
_CAND = Candidate(
    candidate_id="fake:1",
    title="葬送のフリーレン",
    source="fake",
    identifiers={"isbn13": "9784098501234"},
)


def _build_aggregator(adapters: list, timeout_s: float = 10.0) -> Aggregator:
    """用给定 fake adapters 组装一个 Aggregator（注册表按名注册）。"""
    reg = AdapterRegistry()
    for a in adapters:
        reg.register(a)
    return Aggregator(reg, timeout_s=timeout_s)


# --- 任务 7.3 → Property 1 -----------------------------------------------------

# Feature: multi-edition-book-lookup, Property 1: 四版本条目恒存在
@settings(max_examples=100)
@given(
    # 随机决定四类源分别有值/无结果的组合（含全空、部分空、全非空）。
    jp_has=st.booleans(),
    tw_has=st.booleans(),
    hk_has=st.booleans(),
    manga_has=st.booleans(),
)
def test_property1_four_editions_always_present(
    jp_has: bool, tw_has: bool, hk_has: bool, manga_has: bool
):
    """任意源结果组合下，aggregate_editions 的 editions 键集合恒 == 四类，各恰一条。"""

    # 按 config.EDITION_ADAPTER_MAP 的真实源名构造 fake adapter，
    # 每个源仅对其 supported edition 返回记录（受各 has_* 开关控制）。
    def _fetch_for(source: str, ed_flag: dict[str, bool]):
        def _fn(cand, edition):
            if ed_flag.get(edition):
                return make_raw(edition, source)
            return None

        return _fn

    openbd = FakeAdapter(
        config.SOURCE_OPENBD,
        supported_editions=[config.EDITION_JP],
        fetch_result=_fetch_for(config.SOURCE_OPENBD, {config.EDITION_JP: jp_has}),
    )
    gbooks = FakeAdapter(
        config.SOURCE_GOOGLE_BOOKS,
        supported_editions=[config.EDITION_JP, config.EDITION_MANGA],
        fetch_result=_fetch_for(
            config.SOURCE_GOOGLE_BOOKS,
            {config.EDITION_JP: jp_has, config.EDITION_MANGA: manga_has},
        ),
    )
    ndl = FakeAdapter(
        config.SOURCE_NDL,
        supported_editions=[config.EDITION_JP],
        fetch_result=_fetch_for(config.SOURCE_NDL, {config.EDITION_JP: jp_has}),
    )
    bkl = FakeAdapter(
        config.SOURCE_BOOKS_COM_TW,
        supported_editions=[config.EDITION_TW],
        fetch_result=_fetch_for(config.SOURCE_BOOKS_COM_TW, {config.EDITION_TW: tw_has}),
    )
    hk = FakeAdapter(
        config.SOURCE_HK_GENERIC,
        supported_editions=[config.EDITION_HK],
        fetch_result=_fetch_for(config.SOURCE_HK_GENERIC, {config.EDITION_HK: hk_has}),
    )

    agg = _build_aggregator([openbd, gbooks, ndl, bkl, hk])
    result = asyncio.run(agg.aggregate_editions(_CAND, client=None))

    # editions 键集合恒等于四类。
    assert set(result.editions.keys()) == set(config.ALL_EDITIONS)
    # 每类恰一条 EditionRecord，且 edition 字段自洽。
    for ed in config.ALL_EDITIONS:
        rec = result.editions[ed]
        assert isinstance(rec, EditionRecord)
        assert rec.edition == ed


# --- 任务 7.4 → Property 12 ----------------------------------------------------

# Feature: multi-edition-book-lookup, Property 12: 单源失败不影响其他版本结果（失败隔离）
@settings(max_examples=100, deadline=None)
@given(
    # 让"日版"的某一个源失败（超时或抛错），其余源正常。
    fail_mode=st.sampled_from(["timeout", "raise"]),
    which=st.sampled_from([config.SOURCE_OPENBD, config.SOURCE_NDL]),
)
def test_property12_single_source_failure_isolated(fail_mode: str, which: str):
    """恰一个源失败/超时：其余 Edition 结果与该源不参与时一致，失败记入 warnings，
    整体在超时上界内完成不挂起。"""
    # 小超时 + 大 delay 触发超时；raise 模拟抛错。
    timeout_s = 0.05
    if fail_mode == "timeout":
        bad_kwargs = {"delay": 1.0}
    else:
        bad_kwargs = {"raise_exc": RuntimeError("boom")}

    def build(include_bad: bool) -> Aggregator:
        adapters = []
        # 日版三源：openbd / google_books / ndl，其中 which 是"坏源"。
        for src in (config.SOURCE_OPENBD, config.SOURCE_GOOGLE_BOOKS, config.SOURCE_NDL):
            eds = (
                [config.EDITION_JP, config.EDITION_MANGA]
                if src == config.SOURCE_GOOGLE_BOOKS
                else [config.EDITION_JP]
            )
            if src == which:
                if not include_bad:
                    continue  # "该源不参与"的对照组：直接不注册坏源。
                adapters.append(
                    FakeAdapter(
                        src,
                        supported_editions=eds,
                        fetch_result={config.EDITION_JP: make_raw(config.EDITION_JP, src)},
                        **bad_kwargs,
                    )
                )
            else:
                fr = {ed: make_raw(ed, src) for ed in eds}
                adapters.append(FakeAdapter(src, supported_editions=eds, fetch_result=fr))
        # 台版正常源。
        adapters.append(
            FakeAdapter(
                config.SOURCE_BOOKS_COM_TW,
                supported_editions=[config.EDITION_TW],
                fetch_result={config.EDITION_TW: make_raw(config.EDITION_TW, config.SOURCE_BOOKS_COM_TW)},
            )
        )
        return _build_aggregator(adapters, timeout_s=timeout_s)

    # 实验组：包含坏源。
    agg_bad = build(include_bad=True)
    loop_start = asyncio.new_event_loop()
    try:
        asyncio.set_event_loop(loop_start)
        import time

        t0 = time.monotonic()
        res_bad = loop_start.run_until_complete(
            agg_bad.aggregate_editions(_CAND, client=None)
        )
        elapsed = time.monotonic() - t0
    finally:
        loop_start.close()
        asyncio.set_event_loop(None)

    # 对照组：坏源根本不参与。
    agg_ok = build(include_bad=False)
    res_ok = asyncio.run(agg_ok.aggregate_editions(_CAND, client=None))

    # (1) 其余各 Edition 的记录与"坏源不参与"时一致。
    #     日版：坏源提供的字段本就与好源相同（make_raw 同构），故合并结果应一致。
    #     台版/港版/漫画：与坏源无关，必然一致。
    for ed in config.ALL_EDITIONS:
        rb = res_bad.editions[ed]
        ro = res_ok.editions[ed]
        assert rb.present == ro.present, f"{ed} present 不一致"
        assert rb.title == ro.title, f"{ed} title 不一致"
        # 好源集合应一致（坏源不应出现在 sources 中，因为它没成功产出）。
        assert set(rb.sources) == set(ro.sources), f"{ed} sources 不一致：{rb.sources} vs {ro.sources}"

    # (2) 失败被记录到 warnings（含坏源名）。
    assert any(w.source == which for w in res_bad.warnings), (
        f"应有来自坏源 {which} 的 warning，实际 {res_bad.warnings}"
    )

    # (3) 整体在超时上界内完成，不被慢源挂起（给足并发调度余量）。
    #     单源超时 0.05s，四个 edition 顺序推进，合理上界远小于坏源 delay(1.0s)。
    assert elapsed < 0.9, f"聚合耗时 {elapsed:.3f}s 超出预期（疑似被慢源挂起）"


# --- 任务 7.5 → Property 13 ----------------------------------------------------

# Feature: multi-edition-book-lookup, Property 13: 全部源失败则四版本占位且标全局失败
@settings(max_examples=100, deadline=None)
@given(fail_mode=st.sampled_from(["timeout", "raise", "empty"]))
def test_property13_all_sources_failed_placeholder_and_global_flag(fail_mode: str):
    """所有源失败/超时/无结果 → 四版本 present=False、all_sources_failed=True、
    warnings 含全局提示。"""
    timeout_s = 0.05
    if fail_mode == "timeout":
        common = {"delay": 1.0, "fetch_result": None}
    elif fail_mode == "raise":
        common = {"raise_exc": RuntimeError("down"), "fetch_result": None}
    else:  # empty：源正常返回但无结果（None）。
        common = {"fetch_result": None}

    # 为四类 Edition 各注册对应源，全部按 common 配置为"失败/无结果"。
    adapters = [
        FakeAdapter(config.SOURCE_OPENBD, supported_editions=[config.EDITION_JP], **common),
        FakeAdapter(
            config.SOURCE_GOOGLE_BOOKS,
            supported_editions=[config.EDITION_JP, config.EDITION_MANGA],
            **common,
        ),
        FakeAdapter(config.SOURCE_NDL, supported_editions=[config.EDITION_JP], **common),
        FakeAdapter(
            config.SOURCE_BOOKS_COM_TW, supported_editions=[config.EDITION_TW], **common
        ),
        FakeAdapter(
            config.SOURCE_HK_GENERIC, supported_editions=[config.EDITION_HK], **common
        ),
    ]
    agg = _build_aggregator(adapters, timeout_s=timeout_s)
    result = asyncio.run(agg.aggregate_editions(_CAND, client=None))

    # 四版本全部占位。
    for ed in config.ALL_EDITIONS:
        rec = result.editions[ed]
        assert rec.present is False, f"{ed} 应为整版占位"
        assert rec.placeholder == config.MISSING_EDITION_PLACEHOLDER

    # 全局失败标志置真。
    assert result.all_sources_failed is True

    # warnings 含一条全局提示（edition 与 source 均为 None）。
    assert any(
        w.edition is None and w.source is None for w in result.warnings
    ), f"应含全局失败 warning，实际 {result.warnings}"


# --- 任务 7.6 → Property 7 -----------------------------------------------------

# Feature: multi-edition-book-lookup, Property 7: 免责说明恒存在
@settings(max_examples=100)
@given(
    # 覆盖有结果 / 无结果 / 混合等多种情形。
    jp_has=st.booleans(),
    tw_has=st.booleans(),
    all_fail=st.booleans(),
)
def test_property7_disclaimer_always_present(jp_has: bool, tw_has: bool, all_fail: bool):
    """任意聚合结果的 disclaimer 恒非空且 == SERIALIZATION_DISCLAIMER。"""
    if all_fail:
        adapters = [
            FakeAdapter(config.SOURCE_OPENBD, supported_editions=[config.EDITION_JP], fetch_result=None),
            FakeAdapter(config.SOURCE_BOOKS_COM_TW, supported_editions=[config.EDITION_TW], fetch_result=None),
        ]
    else:
        adapters = [
            FakeAdapter(
                config.SOURCE_OPENBD,
                supported_editions=[config.EDITION_JP],
                fetch_result=(
                    {config.EDITION_JP: make_raw(config.EDITION_JP, config.SOURCE_OPENBD)}
                    if jp_has
                    else None
                ),
            ),
            FakeAdapter(
                config.SOURCE_BOOKS_COM_TW,
                supported_editions=[config.EDITION_TW],
                fetch_result=(
                    {config.EDITION_TW: make_raw(config.EDITION_TW, config.SOURCE_BOOKS_COM_TW)}
                    if tw_has
                    else None
                ),
            ),
        ]

    agg = _build_aggregator(adapters, timeout_s=1.0)
    result = asyncio.run(agg.aggregate_editions(_CAND, client=None))

    assert result.disclaimer
    assert result.disclaimer == config.SERIALIZATION_DISCLAIMER


# =============================================================================
# CLI 层的 hypothesis 属性测试（Property 18/19）
# =============================================================================
#
# 这些测试针对 CLI 的纯逻辑函数（候选自动选优、输出格式校验），不打真实网络、
# 不启动服务，仅验证决策逻辑本身。

from app.modules.book_lookup.cli import (
    CliError,
    select_candidate,
    validate_format,
)

# 供 Property 18 生成候选列表的 strategy：每个候选带唯一 candidate_id，
# 顺序即排序结果（select_candidate 按列表顺序取首位）。


@st.composite
def _candidate_list(draw: st.DrawFn, min_size: int, max_size: int) -> list[Candidate]:
    """生成 min_size..max_size 个 Candidate（candidate_id 唯一，顺序即排序）。"""
    n = draw(st.integers(min_value=min_size, max_value=max_size))
    cands: list[Candidate] = []
    for i in range(n):
        cands.append(
            Candidate(
                candidate_id=f"src{i}:{draw(st.integers(min_value=0, max_value=9999))}",
                title=draw(st.text(min_size=1, max_size=8).filter(lambda s: s.strip())),
                source=draw(st.sampled_from(KNOWN_SOURCES)),
            )
        )
    return cands


# --- 任务 13.2 → Property 18 ---------------------------------------------------

# Feature: multi-edition-book-lookup, Property 18: 非交互多候选恒自动选排序首位
@settings(max_examples=100)
@given(candidates=_candidate_list(min_size=2, max_size=8))
def test_property18_non_interactive_auto_selects_first(candidates: list[Candidate]):
    """候选数 ≥2 时，非交互恒选排序首位（列表第 0 项）且 auto_selected==True。"""
    selected, auto_selected = select_candidate(candidates)

    # 恒选首位。
    assert selected is candidates[0]
    # 从多候选中自动挑选 → 标注自动选优。
    assert auto_selected is True


# --- 任务 13.3 → Property 19 ---------------------------------------------------

# 非法格式生成器：任意字符串，但排除恰好等于合法取值（json/table）的样本。
_INVALID_FORMAT = st.text(max_size=16).filter(lambda s: s not in ("json", "table"))


# Feature: multi-edition-book-lookup, Property 19: 非法输出格式恒被拒绝
@settings(max_examples=100)
@given(fmt=_INVALID_FORMAT)
def test_property19_invalid_format_always_rejected(fmt: str):
    """任意 != json/table 的格式取值 → validate_format 抛 CliError，
    消息含受支持取值列表，退出码非零。"""
    import pytest

    with pytest.raises(CliError) as excinfo:
        validate_format(fmt)

    err = excinfo.value
    # 错误消息包含受支持取值列表。
    assert "json" in err.message
    assert "table" in err.message
    # 退出码非零（R12.5）。
    assert err.exit_code != 0


# =============================================================================
# API 层属性测试（Property 15/16/17）—— 任务 12.2 / 12.3 / 12.4
#
# 用 fastapi.testclient.TestClient + FakeAdapter（来自 tests.conftest）避免真实网络。
# 每条属性用单个 hypothesis 属性测试实现，@settings(max_examples=100)。
# =============================================================================

from fastapi.testclient import TestClient  # noqa: E402

from app.modules.book_lookup.aggregator import Aggregator as _ApiAggregator  # noqa: E402
from app.main import create_app as _create_app  # noqa: E402
from app.modules.book_lookup.models import DetailResult, EditionRecord  # noqa: E402
from app.modules.book_lookup.registry import AdapterRegistry as _ApiRegistry  # noqa: E402
from tests.conftest import FakeAdapter  # noqa: E402


def _api_client_with_adapters(adapters: list) -> TestClient:
    """构造注入了给定 FakeAdapter 列表的 TestClient（不打真实网络）。"""
    registry = _ApiRegistry()
    for a in adapters:
        registry.register(a)
    app = _create_app()
    app.state.registry = registry
    app.state.aggregator = _ApiAggregator(registry, timeout_s=1.0)
    return TestClient(app)


# 纯空白/空书名生成器：由空白字符（空格、制表、换行、回车、垂直制表、换页）组成，含空串。
_WHITESPACE_ALPHABET = " \t\n\r\x0b\x0c\u3000"
_blank_title = st.text(alphabet=_WHITESPACE_ALPHABET, min_size=0, max_size=8)

# 合法字符集书名生成器：中/日/英/数字混合，且至少含一个非空白字符。
_valid_char_alphabet = (
    "葬送のフリーレン鋼錬金術師進撃巨人ワンピース"  # CJK（中/日汉字与假名）
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"  # 拉丁
    "0123456789"  # 数字
    " "  # 允许中间空格
)
_valid_title = st.text(alphabet=_valid_char_alphabet, min_size=1, max_size=20).filter(
    lambda s: s.strip() != ""
)


# Feature: multi-edition-book-lookup, Property 16: 空/纯空白书名恒被拒绝且不触发检索
@settings(max_examples=100, deadline=None)
@given(title=_blank_title)
def test_property16_blank_title_rejected_and_no_search(title: str):
    """对任意仅由空白字符组成或为空的书名，/api/search 恒返回 EMPTY_TITLE 校验错误，
    且恒不触发任何 Adapter 的检索调用（用 FakeAdapter.search_calls 断言）。

    Validates: Requirements 1.2
    """
    fake = FakeAdapter(
        name="fake_jp",
        search_results=[
            Candidate(candidate_id="fake:1", title="x", source="fake_jp")
        ],
    )
    with _api_client_with_adapters([fake]) as client:
        resp = client.post("/api/search", json={"title": title})
        assert resp.status_code == 400
        body = resp.json()
        assert body["code"] == "EMPTY_TITLE"
        # 恒不触发检索：FakeAdapter.search 从未被调用。
        assert fake.search_calls == []


# Feature: multi-edition-book-lookup, Property 17: 合法字符集书名恒被接受
@settings(max_examples=100, deadline=None)
@given(title=_valid_title)
def test_property17_valid_charset_title_accepted(title: str):
    """对任意由中/日/英/数字组合（含至少一个非空白字符）的书名，/api/search 恒正常
    进入检索流程（200），且不因字符集/编码抛出异常，FakeAdapter.search 被调用。

    Validates: Requirements 1.3
    """
    fake = FakeAdapter(name="fake_jp", search_results=[])
    with _api_client_with_adapters([fake]) as client:
        resp = client.post("/api/search", json={"title": title})
        # 合法书名恒进入检索：返回 200（而非 400 校验错误、非 500 内部错误）。
        assert resp.status_code == 200
        body = resp.json()
        assert body["query"] == title
        # 确实进入了检索流程：search 被调用，且入参即该书名。
        assert fake.search_calls == [title]


# Feature: multi-edition-book-lookup, Property 15: JSON 序列化 round-trip 保结构
@settings(max_examples=100, deadline=None)
@given(raws_map=st.fixed_dictionaries({ed: same_edition_raws() for ed in EDITIONS}))
def test_property15_detail_result_json_roundtrip(raws_map):
    """对任意合法 DetailResult（由各 Edition 的多源记录经 Merger 合并而成），序列化为
    JSON 再反序列化，结构等价：四类 Edition 齐全、字段保留、缺失普通字段仍为
    UNKNOWN_MARKER、整版缺失仍为 present=False + 占位。

    Validates: Requirements 12.2, 12.3
    """
    # 用 Merger 为每个 Edition 合并出一条 EditionRecord，组装成 DetailResult。
    editions: dict[str, EditionRecord] = {}
    for ed in EDITIONS:
        # same_edition_raws 固定同一 edition，但为对齐键名，用 ed 覆盖 edition 字段。
        raws = [r.model_copy(update={"edition": ed}) for r in raws_map[ed]]
        editions[ed] = _MERGER.merge(ed, raws)

    original = DetailResult(
        query_title="标题",
        editions=editions,
        disclaimer=config.SERIALIZATION_DISCLAIMER,
    )

    # 序列化 → JSON 文本 → 反序列化回模型。
    json_text = original.model_dump_json()
    restored = DetailResult.model_validate_json(json_text)

    # 四类 Edition 键齐全且一致。
    assert set(restored.editions.keys()) == set(EDITIONS)
    # disclaimer 保留。
    assert restored.disclaimer == config.SERIALIZATION_DISCLAIMER

    # 逐 Edition 结构等价。
    for ed in EDITIONS:
        orig_ed = original.editions[ed]
        rest_ed = restored.editions[ed]
        assert rest_ed.present == orig_ed.present
        if not orig_ed.present:
            # 整版缺失：占位文本保留为 MISSING_EDITION_PLACEHOLDER。
            assert rest_ed.placeholder == config.MISSING_EDITION_PLACEHOLDER
        else:
            # 有版本：逐普通字段等价；缺失字段仍为 UNKNOWN_MARKER，而非丢失或报错。
            for field in ORDINARY_FIELDS:
                assert getattr(rest_ed, field) == getattr(orig_ed, field)
            # 来源集合与冲突标注保留。
            assert rest_ed.sources == orig_ed.sources
            assert rest_ed.field_conflicts == orig_ed.field_conflicts
            # 连载状态值域不变（枚举字符串或 None）。
            assert rest_ed.serialization_status == orig_ed.serialization_status


# =============================================================================
# 前端占位/未知文本同源一致属性测试（Property 20）—— 任务 15.3
#
# 后端侧：用 hypothesis 生成各 Edition 的多源记录组合，经 Merger 合并成
# DetailResult 并序列化为 JSON，断言：
#   - 整版缺失的 placeholder 恒 == config.MISSING_EDITION_PLACEHOLDER；
#   - present=True 时缺失的普通文本字段恒 == config.UNKNOWN_MARKER。
# 前端侧：读取 web/app.js 源码，断言其不含硬编码的 "无此版本信息"
#   （即前端不独立硬编码占位文本，而是从后端响应取值渲染）。
# =============================================================================

from pathlib import Path  # noqa: E402

_WEB_DIR = Path(__file__).resolve().parent.parent / "web"
_APP_JS = _WEB_DIR / "app.js"


# Feature: multi-edition-book-lookup, Property 20: 前后端占位/未知文本同源一致
@settings(max_examples=100, deadline=None)
@given(raws_map=st.fixed_dictionaries({ed: same_edition_raws() for ed in EDITIONS}))
def test_property20_frontend_backend_placeholder_unknown_same_source(raws_map):
    """任意缺失情形下，后端 JSON 中整版缺失的 placeholder 恒 ==
    MISSING_EDITION_PLACEHOLDER、缺失普通字段恒 == UNKNOWN_MARKER；且前端 app.js
    不硬编码占位文本（从响应取值渲染），保证前后端文案同源一致。

    Validates: Requirements 13.4, 11.4
    """
    import json

    # 后端侧：用 Merger 为每个 Edition 合并出记录，组装 DetailResult 并序列化为 JSON。
    editions: dict[str, EditionRecord] = {}
    for ed in EDITIONS:
        raws = [r.model_copy(update={"edition": ed}) for r in raws_map[ed]]
        editions[ed] = _MERGER.merge(ed, raws)

    detail = DetailResult(
        query_title="标题",
        editions=editions,
        disclaimer=config.SERIALIZATION_DISCLAIMER,
    )
    payload = json.loads(detail.model_dump_json())

    text_fields = ("title", "author", "publisher", "format", "isbn", "publish_date")
    for ed in EDITIONS:
        ed_json = payload["editions"][ed]
        if ed_json["present"] is False:
            # 整版缺失：占位文本恒 == 后端常量。
            assert ed_json["placeholder"] == config.MISSING_EDITION_PLACEHOLDER
        else:
            # present=True 时，所有源都未提供的普通文本字段恒 == 后端 UNKNOWN_MARKER。
            raws = raws_map[ed]
            for attr in text_fields:
                provided = any(getattr(r, attr) is not None for r in raws)
                if not provided:
                    assert ed_json[attr] == config.UNKNOWN_MARKER

    # 前端侧：app.js 不得硬编码整版占位文本（应从后端响应的 placeholder 字段取值）。
    src = _APP_JS.read_text(encoding="utf-8")
    assert config.MISSING_EDITION_PLACEHOLDER not in src, (
        "前端 app.js 不应硬编码整版占位文本，应从后端响应的 placeholder 字段渲染"
    )
