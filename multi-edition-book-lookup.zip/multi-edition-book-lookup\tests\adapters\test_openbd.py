"""OpenBdAdapter 解析单测。

使用 `tests/adapters/fixtures/` 下录制的 openBD JSON 样例，配合 `pytest-httpx`
的 `httpx_mock` 拦截 httpx 请求（不打真实网络），断言字段映射正确。
异步测试由 pyproject 的 `asyncio_mode = "auto"` 自动驱动。
"""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from app.shared import config
from app.modules.book_lookup.adapters.openbd import OpenBdAdapter
from app.modules.book_lookup.models import Candidate, Price

_FIXTURES = Path(__file__).parent / "fixtures"


def _load(name: str) -> str:
    return (_FIXTURES / name).read_text(encoding="utf-8")


def _candidate(isbn13: str | None = "9784098501234", **ids) -> Candidate:
    identifiers = dict(ids)
    if isbn13 is not None:
        identifiers["isbn13"] = isbn13
    return Candidate(
        candidate_id="test:frieren",
        title="葬送のフリーレン",
        source="test",
        identifiers=identifiers,
    )


async def test_fetch_parses_all_fields(httpx_mock):
    """完整 fixture → 字段全部正确映射（书名/作者/出版社/ISBN/JPY 定价/出版日期/判型）。"""
    httpx_mock.add_response(
        url="https://api.openbd.jp/v1/get?isbn=9784098501234",
        text=_load("openbd_frieren.json"),
        headers={"content-type": "application/json"},
    )
    adapter = OpenBdAdapter()
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(_candidate(), config.EDITION_JP, client)

    assert rec is not None
    assert rec.edition == config.EDITION_JP
    assert rec.source == config.SOURCE_OPENBD
    assert rec.title == "葬送のフリーレン 1"
    assert rec.author == "山田鐘人／原作 アベツカサ／作画"
    assert rec.publisher == "小学館"
    assert rec.isbn == "9784098501234"
    assert rec.publish_date == "2020-08-18"
    assert rec.format == "新書判"
    assert isinstance(rec.price, Price)
    assert rec.price.amount == 550.0
    assert rec.price.currency == "JPY"
    # openBD 不提供连载状态/卷数
    assert rec.serialization_status is None
    assert rec.total_volumes is None
    assert rec.latest_volume is None


async def test_fetch_without_isbn_returns_none():
    """candidate 无 ISBN → fetch 直接返回 None（不发请求）。"""
    adapter = OpenBdAdapter()
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(_candidate(isbn13=None), config.EDITION_JP, client)
    assert rec is None


async def test_fetch_notfound_returns_none(httpx_mock):
    """openBD 返回 [null]（该 ISBN 查不到）→ fetch 返回 None。"""
    httpx_mock.add_response(
        url="https://api.openbd.jp/v1/get?isbn=9784098501234",
        text=_load("openbd_notfound.json"),
        headers={"content-type": "application/json"},
    )
    adapter = OpenBdAdapter()
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(_candidate(), config.EDITION_JP, client)
    assert rec is None


async def test_fetch_http_error_swallowed_returns_none(httpx_mock):
    """HTTP 5xx → 异常吞掉转 None，不外抛。"""
    httpx_mock.add_response(
        url="https://api.openbd.jp/v1/get?isbn=9784098501234",
        status_code=503,
    )
    adapter = OpenBdAdapter()
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(_candidate(), config.EDITION_JP, client)
    assert rec is None


async def test_fetch_network_error_swallowed_returns_none(httpx_mock):
    """网络异常 → 吞掉转 None。"""
    httpx_mock.add_exception(httpx.ConnectError("boom"))
    adapter = OpenBdAdapter()
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(_candidate(), config.EDITION_JP, client)
    assert rec is None


async def test_fetch_missing_price_yields_none_price(httpx_mock):
    """定价缺失（无 Price 节点）→ price 为 None，其余字段仍解析（缺失字段置 None）。"""
    data = json.loads(_load("openbd_frieren.json"))
    # 移除定价与判型，模拟部分字段缺失。
    data[0]["onix"]["ProductSupply"]["SupplyDetail"].pop("Price", None)
    data[0]["onix"]["DescriptiveDetail"].pop("ProductFormDetail", None)
    httpx_mock.add_response(
        url="https://api.openbd.jp/v1/get?isbn=9784098501234",
        text=json.dumps(data),
        headers={"content-type": "application/json"},
    )
    adapter = OpenBdAdapter()
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(_candidate(), config.EDITION_JP, client)

    assert rec is not None
    assert rec.price is None
    assert rec.format is None
    # 其余非缺失字段不受影响
    assert rec.title == "葬送のフリーレン 1"
    assert rec.publisher == "小学館"


async def test_search_returns_empty():
    """openBD 无书名检索能力 → search 恒返回 []。"""
    adapter = OpenBdAdapter()
    async with httpx.AsyncClient() as client:
        result = await adapter.search("葬送のフリーレン", client)
    assert result == []


def test_adapter_metadata():
    """name 用 config 常量，supported_editions 含日版。"""
    adapter = OpenBdAdapter()
    assert adapter.name == config.SOURCE_OPENBD
    assert config.EDITION_JP in adapter.supported_editions
