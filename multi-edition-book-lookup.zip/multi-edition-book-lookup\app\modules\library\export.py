"""library 图书管理模块的导出功能：把藏书清单导出为 CSV / JSON 字节流。

本模块只负责序列化，输入是调用方（通常是 router，经由 service.list_items）
已经算好计算字段的 LibraryItemOut 列表，输出为 bytes，可直接作为 HTTP 下载
响应体。

设计要点：
- CSV 用中文表头（对用户更友好），以 utf-8-sig（带 BOM）编码，确保 Excel 打开
  中文不乱码；空清单只写表头一行。
- JSON 键沿用英文字段名（LibraryItemOut 的字段名），ensure_ascii=False 保证中文
  不被转义；空清单输出 b"[]"。
- 计算字段（profit / profit_rate）一并导出。
- None 值在 CSV 中写为空字符串（不写字面量 "None"）；在 JSON 中保持为 null。
"""

from __future__ import annotations

import csv
import io
import json

from app.modules.library.models import LibraryItemOut


# 导出字段顺序（含计算字段），CSV 列顺序与 JSON 键顺序都以此为准。
EXPORT_FIELDS: list[str] = [
    "id",
    "title",
    "author",
    "publisher",
    "category",
    "edition",
    "is_completed",
    "total_volumes",
    "latest_volume",
    "ownership_status",
    "owned_count",
    "purchase_price",
    "sale_price",
    "purchase_channel",
    "profit",
    "profit_rate",
    "created_at",
    "updated_at",
]

# 英文字段名 → 中文表头映射，仅用于 CSV 表头（JSON 键仍用英文字段名）。
FIELD_HEADERS: dict[str, str] = {
    "id": "ID",
    "title": "书名",
    "author": "作者",
    "publisher": "出版社",
    "category": "种类",
    "edition": "版本",
    "is_completed": "是否完结",
    "total_volumes": "全套总卷数",
    "latest_volume": "最新册数",
    "ownership_status": "藏书状态",
    "owned_count": "拥有册数",
    "purchase_price": "买入价格",
    "sale_price": "卖出价格",
    "purchase_channel": "购入渠道",
    "profit": "利润",
    "profit_rate": "利润率(%)",
    "created_at": "创建时间",
    "updated_at": "更新时间",
}


def _csv_cell(field: str, value: object) -> str:
    """把单个字段值转换为 CSV 单元格字符串。

    - None → 空字符串（不写 "None"）。
    - is_completed 布尔 → 「是 / 否」（None 已在上面处理为空）。
    - 其余值 → str(value)。
    """
    if value is None:
        return ""
    if field == "is_completed":
        # 到这里 value 必为 True / False（None 已在上面返回空串）
        return "是" if value else "否"
    return str(value)


def to_csv(items: list[LibraryItemOut]) -> bytes:
    """把藏书条目列表导出为 CSV 字节流（utf-8-sig 带 BOM）。

    表头使用中文（FIELD_HEADERS），每条条目占一行。ownership_status 取枚举的
    字符串值；is_completed 转为「是 / 否」；None 值输出为空字符串。空清单只写
    表头一行。

    Args:
        items: 已带计算字段的藏书条目列表。

    Returns:
        CSV 内容的 bytes，以 utf-8-sig 编码（开头含 BOM，Excel 打开中文不乱码）。
    """
    output = io.StringIO()
    writer = csv.writer(output)

    # 中文表头行
    writer.writerow([FIELD_HEADERS[field] for field in EXPORT_FIELDS])

    for item in items:
        # 用 pydantic v2 的 model_dump(mode="json") 拿到可序列化的 dict：
        # ownership_status 已被转为其字符串值（.value），无需额外处理。
        data = item.model_dump(mode="json")
        row = [_csv_cell(field, data.get(field)) for field in EXPORT_FIELDS]
        writer.writerow(row)

    # utf-8-sig：写入 BOM，确保 Excel 正确识别 UTF-8 中文。
    return output.getvalue().encode("utf-8-sig")


def to_json(items: list[LibraryItemOut]) -> bytes:
    """把藏书条目列表导出为 JSON 字节流（UTF-8，中文不转义）。

    每条用 model_dump(mode="json") 得到 dict（键为英文字段名，计算字段一并
    包含，缺失的价格/计算字段为 null）。空清单输出 b"[]"。

    Args:
        items: 已带计算字段的藏书条目列表。

    Returns:
        JSON 内容的 bytes，以 UTF-8 编码；ensure_ascii=False 保证中文原样输出。
    """
    data = [item.model_dump(mode="json") for item in items]
    text = json.dumps(data, ensure_ascii=False, indent=2)
    return text.encode("utf-8")
