"""library 图书管理模块的数据库连接与 schema 初始化。

本模块封装 SQLite 的连接获取与建表逻辑：
- `get_connection()`：按需打开一条 SQLite 连接，设置 `row_factory=sqlite3.Row`
  以便按列名访问结果，并启用 WAL 日志模式提升并发读写安全。
- `init_db()`：幂等建立 `library_items` 表（`CREATE TABLE IF NOT EXISTS`）。

数据库文件路径默认取自 `config.LIBRARY_DB_PATH`（可被环境变量覆盖）；打开前会
自动创建其父目录（`:memory:` 内存库除外）。计算字段 profit / profit_rate 不落库，
读取时由 compute 现算，故不出现在表结构中。
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

from app.shared import config

# library_items 建表 DDL：与 design.md 表结构保持一致，幂等（IF NOT EXISTS）。
# profit / profit_rate 为读时现算的计算字段，不落库。
_CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS library_items (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    title            TEXT NOT NULL,
    author           TEXT,
    publisher        TEXT,
    category         TEXT,
    edition          TEXT,
    is_completed     INTEGER,
    total_volumes    INTEGER,
    latest_volume    INTEGER,
    ownership_status TEXT NOT NULL,
    owned_count      INTEGER,
    purchase_price   REAL,
    sale_price       REAL,
    purchase_channel TEXT,
    created_at       TEXT NOT NULL,
    updated_at       TEXT NOT NULL
);
"""


def get_connection(db_path: str | None = None) -> sqlite3.Connection:
    """打开并返回一条 SQLite 连接。

    Args:
        db_path: 数据库文件路径；为 None 时使用 `config.LIBRARY_DB_PATH`。

    Returns:
        已配置 `row_factory=sqlite3.Row`、已启用 WAL 模式的连接。

    说明：
        - 打开前确保父目录存在（`:memory:` 内存库特殊路径不建目录）。
        - `row_factory=sqlite3.Row` 允许结果按列名访问。
        - `PRAGMA journal_mode=WAL` 对内存库无害，对文件库提升并发安全。
    """
    if db_path is None:
        db_path = config.LIBRARY_DB_PATH

    # :memory: 是特殊内存库路径，不能当作文件路径去建目录。
    if db_path != ":memory:":
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    return conn


def init_db(db_path: str | None = None) -> None:
    """幂等初始化数据库：建立 `library_items` 表（若不存在）。

    Args:
        db_path: 数据库文件路径；为 None 时使用 `config.LIBRARY_DB_PATH`。

    连续多次调用不会报错（`CREATE TABLE IF NOT EXISTS`）。
    """
    conn = get_connection(db_path)
    try:
        conn.execute(_CREATE_TABLE_SQL)
        conn.commit()
    finally:
        conn.close()
