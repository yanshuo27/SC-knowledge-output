"""pytest 共享夹具与 hypothesis 基础设置。

包含：
- hypothesis 基础 profile（≥100 迭代）。
- 供 Merger 属性测试复用的生成器（strategies）：
  * `raw_edition_record()`：生成单条 RawEditionRecord，各字段随机缺失/有值。
  * `same_edition_raws()`：生成"同一 Edition 的多源记录列表"（变长 1..N）。
  * `conflicting_field_raws()`：针对"同字段多源冲突"生成 2+ 个互不相同的非缺失值，
    分别挂在不同 source 上（用于 Property 10）。

后续任务会在此追加 fake adapters、录制响应夹具等共享 fixtures。
"""

from __future__ import annotations

from hypothesis import HealthCheck, settings
from hypothesis import strategies as st

from app.shared import config
from app.modules.book_lookup.models import Price, RawEditionRecord, SerializationStatus

# 注册基础 profile：每个属性测试至少 100 次迭代（与设计文档 Testing Strategy 一致）。
settings.register_profile(
    "default",
    max_examples=100,
    suppress_health_check=[HealthCheck.too_slow],
)
settings.load_profile("default")


# --- 值域常量：供生成器与断言复用 ---------------------------------------------

# 四类 Edition（design.md：台版/港版/日版/漫画）。
EDITIONS = list(config.ALL_EDITIONS)

# 已知数据源名（config.SOURCE_PRIORITY 中登记的全部源）。
KNOWN_SOURCES = list(config.SOURCE_PRIORITY.keys())

# EditionRecord 中"普通字段"的模型属性名（不含 serialization_status）。
# 与 merger._ORDINARY_FIELDS 保持一致，供属性测试引用。
ORDINARY_FIELDS = (
    "title",
    "author",
    "publisher",
    "format",
    "price",
    "total_volumes",
    "latest_volume",
    "isbn",
    "publish_date",
)


# --- 基础字段值 strategies -----------------------------------------------------

def _text_value() -> st.SearchStrategy[str]:
    """非空的普通文本值（书名/作者等）。

    过滤掉纯空白，避免生成器产出的字符串被视作"看似有值实则空"的歧义样本；
    Merger 只按 `is not None` 判定，故只要非 None 即算有值，但用非空文本更贴近现实。
    """
    return st.text(min_size=1, max_size=12).filter(lambda s: s.strip() != "")


def _currency_value() -> st.SearchStrategy[str]:
    return st.sampled_from(["JPY", "TWD", "HKD", "USD"])


def _price_value() -> st.SearchStrategy[Price]:
    """完整 Price（amount + currency 成对）。

    amount 限定为有限浮点，避免 NaN/inf 让相等性判断与序列化出现不稳定。
    """
    return st.builds(
        Price,
        amount=st.floats(
            min_value=0,
            max_value=1_000_000,
            allow_nan=False,
            allow_infinity=False,
        ),
        currency=_currency_value(),
    )


def _volume_value() -> st.SearchStrategy[int]:
    return st.integers(min_value=1, max_value=999)


def _status_value() -> st.SearchStrategy[SerializationStatus]:
    return st.sampled_from(list(SerializationStatus))


def _isbn_value() -> st.SearchStrategy[str]:
    return st.text(alphabet="0123456789X", min_size=10, max_size=13).filter(
        lambda s: s.strip() != ""
    )


def _date_value() -> st.SearchStrategy[str]:
    """ISO 8601 风格日期字符串（简化生成，仅要求非空文本形态）。"""
    return st.dates().map(lambda d: d.isoformat())


# --- 单条 RawEditionRecord 生成器（任务 4.2 之一） -----------------------------

@st.composite
def raw_edition_record(
    draw: st.DrawFn,
    edition: str | None = None,
    source: str | None = None,
) -> RawEditionRecord:
    """生成单条 RawEditionRecord。

    各普通字段用 `st.none() | st.<value>()` 组合，随机产生缺失/有值：
    - edition：不指定时从四类中取。
    - source：不指定时从已知数据源名取。
    - price：`st.none() | builds(Price, ...)`。
    - serialization_status：`st.none() | st.sampled_from(list(SerializationStatus))`。
    - total_volumes / latest_volume：`st.none() | st.integers(1..999)`。
    """
    ed = edition if edition is not None else draw(st.sampled_from(EDITIONS))
    src = source if source is not None else draw(st.sampled_from(KNOWN_SOURCES))

    return RawEditionRecord(
        edition=ed,
        source=src,
        title=draw(st.none() | _text_value()),
        author=draw(st.none() | _text_value()),
        publisher=draw(st.none() | _text_value()),
        format=draw(st.none() | _text_value()),
        price=draw(st.none() | _price_value()),
        serialization_status=draw(st.none() | _status_value()),
        total_volumes=draw(st.none() | _volume_value()),
        latest_volume=draw(st.none() | _volume_value()),
        isbn=draw(st.none() | _isbn_value()),
        publish_date=draw(st.none() | _date_value()),
    )


# --- 多源记录列表生成器（任务 4.2 之二） ---------------------------------------

@st.composite
def same_edition_raws(
    draw: st.DrawFn,
    min_size: int = 1,
    max_size: int = 5,
) -> list[RawEditionRecord]:
    """生成"同一 Edition 的多源记录列表"（固定同一 edition，变长 1..N）。

    source 可重复或不同（从已知源随机取），用于覆盖合并/缺失/来源集合等属性。
    """
    edition = draw(st.sampled_from(EDITIONS))
    n = draw(st.integers(min_value=min_size, max_value=max_size))
    raws: list[RawEditionRecord] = []
    for _ in range(n):
        raws.append(draw(raw_edition_record(edition=edition)))
    return raws


# --- 同字段多源冲突生成器（任务 4.2 之三，用于 Property 10） --------------------

# 可用于冲突测试的字段名 → 对应"两个互不相同非缺失值"的 strategy。
# 只选相等性判断稳定、易生成互异值的字段。
_CONFLICT_FIELD_SPECS: dict[str, st.SearchStrategy] = {
    "title": _text_value(),
    "author": _text_value(),
    "publisher": _text_value(),
    "isbn": _isbn_value(),
}


@st.composite
def conflicting_field_raws(
    draw: st.DrawFn,
) -> tuple[str, str, list[RawEditionRecord]]:
    """针对"同字段多源冲突"生成记录列表。

    对某一字段生成 2+ 个互不相同的非缺失值，分别挂在**不同** source 上；
    其余字段一律置 None，以隔离出该字段的冲突行为（Property 10）。

    返回：`(field_name, expected_value, raws)`
      - field_name：发生冲突的字段名（EditionRecord 属性名）。
      - expected_value：按 SOURCE_PRIORITY 应当胜出的值（优先级数值最小的源提供的值）。
      - raws：至少 2 条、source 互不相同、该字段值互不相同的记录。
    """
    edition = draw(st.sampled_from(EDITIONS))
    field = draw(st.sampled_from(list(_CONFLICT_FIELD_SPECS.keys())))
    value_strategy = _CONFLICT_FIELD_SPECS[field]

    # 选 2..len(KNOWN_SOURCES) 个互不相同的 source。
    n = draw(st.integers(min_value=2, max_value=len(KNOWN_SOURCES)))
    sources = draw(
        st.lists(
            st.sampled_from(KNOWN_SOURCES),
            min_size=n,
            max_size=n,
            unique=True,
        )
    )

    # 为每个 source 生成互不相同的非缺失值。
    values = draw(
        st.lists(
            value_strategy,
            min_size=len(sources),
            max_size=len(sources),
            unique=True,
        )
    )

    raws: list[RawEditionRecord] = []
    for src, val in zip(sources, values):
        raws.append(RawEditionRecord(edition=edition, source=src, **{field: val}))

    # 计算优先级最高（数值最小）的源；同优先级时取输入顺序中的首个（与 Merger 的 min 稳定选择一致）。
    fallback = 10**9
    best_idx = min(
        range(len(sources)),
        key=lambda i: config.SOURCE_PRIORITY.get(sources[i], fallback),
    )
    expected_value = values[best_idx]

    return field, expected_value, raws


# =============================================================================
# 任务 7.2：带可控延迟/抛错的 fake Adapter（供 Aggregator 隔离/超时/编排属性复用）
# =============================================================================
#
# FakeAdapter 实现 DataSourceAdapter 抽象契约，可配置：
#   - name：数据源名。
#   - supported_editions：可服务的 Edition 列表。
#   - search 返回的候选（固定列表）。
#   - fetch 返回的 RawEditionRecord（按 edition 映射，或统一一条，或 None）。
#   - delay：可选，用 asyncio.sleep 模拟慢响应（配合小 timeout_s 触发超时）。
#   - raise_exc：可选，调用 search/fetch 时抛出该异常（模拟源抛错）。
#
# 绝不打真实网络：search/fetch 全在内存里返回预置数据。

import asyncio as _asyncio  # 局部别名，避免与测试文件里的 import 冲突

from app.modules.book_lookup.adapters.base import DataSourceAdapter
from app.modules.book_lookup.models import Candidate as _Candidate
from app.modules.book_lookup.models import RawEditionRecord as _RawEditionRecord


class FakeAdapter(DataSourceAdapter):
    """内存版可控 Adapter，用于编排层测试（不打真实网络）。

    构造参数：
        name: 数据源唯一名。
        supported_editions: 可服务的 Edition 列表（默认全部四类）。
        search_results: search() 返回的候选列表（默认 []）。
        fetch_result: fetch() 返回值的配置，支持三种形态：
            * None：任意 edition 都返回 None（该源对所有版本无结果）。
            * RawEditionRecord：任意 edition 都返回这一条（source/edition 会被规整）。
            * dict[str, RawEditionRecord | None]：按 edition 名映射返回；未命中键返回 None。
            * callable(candidate, edition) -> RawEditionRecord | None：动态生成。
        delay: 可选浮点秒数，search/fetch 前 asyncio.sleep(delay) 模拟慢响应。
        raise_exc: 可选异常实例/类，调用时抛出以模拟源抛错（在 delay 之后抛）。
        record_calls: 是否记录调用（默认 True），便于断言"失败源未污染其他任务"。
    """

    def __init__(
        self,
        name: str,
        supported_editions: list[str] | None = None,
        search_results: list[_Candidate] | None = None,
        fetch_result=None,
        delay: float | None = None,
        raise_exc: BaseException | type[BaseException] | None = None,
        record_calls: bool = True,
    ) -> None:
        self.name = name
        self.supported_editions = (
            list(supported_editions)
            if supported_editions is not None
            else list(config.ALL_EDITIONS)
        )
        self._search_results = list(search_results) if search_results else []
        self._fetch_result = fetch_result
        self._delay = delay
        self._raise_exc = raise_exc
        self._record_calls = record_calls
        # 调用记录（供测试断言）。
        self.search_calls: list[str] = []
        self.fetch_calls: list[tuple[str, str]] = []  # (candidate_id, edition)

    async def _maybe_delay_and_raise(self) -> None:
        """先按配置 sleep（模拟慢响应），再按配置抛错（模拟源抛错）。"""
        if self._delay is not None:
            await _asyncio.sleep(self._delay)
        if self._raise_exc is not None:
            exc = self._raise_exc
            if isinstance(exc, type):
                raise exc()
            raise exc

    async def search(self, title: str, client) -> list[_Candidate]:  # noqa: ANN001
        if self._record_calls:
            self.search_calls.append(title)
        await self._maybe_delay_and_raise()
        return list(self._search_results)

    async def fetch(  # noqa: ANN001
        self, candidate: _Candidate, edition: str, client
    ) -> _RawEditionRecord | None:
        if self._record_calls:
            self.fetch_calls.append((getattr(candidate, "candidate_id", ""), edition))
        await self._maybe_delay_and_raise()

        fr = self._fetch_result
        result: _RawEditionRecord | None
        if fr is None:
            result = None
        elif callable(fr) and not isinstance(fr, _RawEditionRecord):
            result = fr(candidate, edition)
        elif isinstance(fr, dict):
            result = fr.get(edition)
        elif isinstance(fr, _RawEditionRecord):
            result = fr
        else:
            result = None

        # 规整 source/edition 与本 Adapter 一致，避免测试构造时忘记设置。
        if isinstance(result, _RawEditionRecord):
            result = result.model_copy(update={"source": self.name, "edition": edition})
        return result


def make_raw(
    edition: str,
    source: str,
    *,
    title: str | None = "标题",
    **fields,
) -> _RawEditionRecord:
    """便捷构造一条带最小非缺失字段的 RawEditionRecord（供 fake fetch 返回）。

    默认给 title 一个非空值，确保 Merger 判定该 Edition present=True。
    可通过 **fields 覆盖/补充其他字段。
    """
    data = {"edition": edition, "source": source, "title": title}
    data.update(fields)
    return _RawEditionRecord(**data)
