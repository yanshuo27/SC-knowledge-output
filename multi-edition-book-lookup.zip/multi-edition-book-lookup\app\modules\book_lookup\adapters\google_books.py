"""GoogleBooksAdapter：Google Books API（日版 / 漫画）数据源适配器。

Google Books 提供 volumes 检索与取详情 API：

    检索：GET https://www.googleapis.com/books/v1/volumes?q=<query>
    取详情：GET https://www.googleapis.com/books/v1/volumes/<volumeId>

检索返回 JSON ``{"totalItems": N, "items": [ {volume}, ... ]}``；每个 volume 形如
``{"id": "...", "volumeInfo": {"title","authors","publisher","publishedDate",
"industryIdentifiers":[{"type":"ISBN_13","identifier":"..."}], ...}, "saleInfo": {...}}``。

字段现实性（参见 design.md 的字段对照表）：书名/作者/ISBN/出版日期较好；出版社
与定价不稳定（best-effort）；判型无。适合作为漫画系列候选来源与日版补充。

设计约定：
- ``search`` 按书名检索，解析 items 为 ``list[Candidate]``，candidate_id 用
  ``"google_books:<volumeId>"``，identifiers 放 isbn13 / gb_id。
- ``fetch`` 优先按 identifiers 中的 gb_id 取详情；无 gb_id 时按书名检索取首条。
  漫画 edition 的 ``latest_volume`` best-effort（拿不到置 None）。
- 缺失字段一律置 ``None``；所有异常内部捕获转空结果（``search`` → ``[]`` /
  ``fetch`` → ``None``），绝不外抛。
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from app.shared import config
from app.modules.book_lookup.adapters.base import DataSourceAdapter
from app.modules.book_lookup.models import Candidate, Price, RawEditionRecord

if TYPE_CHECKING:
    import httpx

_GB_VOLUMES_URL = "https://www.googleapis.com/books/v1/volumes"


class GoogleBooksAdapter(DataSourceAdapter):
    """Google Books 适配器，服务日版与漫画两类 Edition。"""

    name = config.SOURCE_GOOGLE_BOOKS
    supported_editions = [config.EDITION_JP, config.EDITION_MANGA]

    async def search(self, title: str, client: "httpx.AsyncClient") -> list[Candidate]:
        """按书名检索 Google Books volumes，解析 items 为候选列表。

        查不到或异常时返回 ``[]``。
        """
        try:
            resp = await client.get(_GB_VOLUMES_URL, params={"q": title})
            resp.raise_for_status()
            data = resp.json()
        except Exception:
            return []

        return self._parse_candidates(data)

    async def fetch(
        self, candidate: Candidate, edition: str, client: "httpx.AsyncClient"
    ) -> RawEditionRecord | None:
        """按 candidate 抓取对应 volume，解析为该 Edition 的原始记录。

        取 volume 的策略：优先用 identifiers.gb_id 直接取详情；否则退化为按书名检索取首条。
        网络/解析异常吞掉转 ``None``。
        """
        volume = await self._resolve_volume(candidate, client)
        if volume is None:
            return None
        return self._parse_volume(volume, edition)

    # --- volume 获取 ----------------------------------------------------------

    async def _resolve_volume(
        self, candidate: Candidate, client: "httpx.AsyncClient"
    ) -> dict | None:
        """解析出用于取字段的 volume dict。"""
        ids = candidate.identifiers or {}
        gb_id = ids.get("gb_id")

        # 策略一：有 gb_id → 直接取详情。
        if gb_id:
            try:
                resp = await client.get(f"{_GB_VOLUMES_URL}/{gb_id}")
                resp.raise_for_status()
                vol = resp.json()
                if isinstance(vol, dict) and vol.get("volumeInfo"):
                    return vol
            except Exception:
                pass  # 落到策略二

        # 策略二：按书名（或 ISBN）检索取首条。
        query = None
        isbn = ids.get("isbn13") or ids.get("isbn")
        if isbn:
            query = f"isbn:{isbn}"
        elif candidate.title:
            query = candidate.title
        if not query:
            return None

        try:
            resp = await client.get(_GB_VOLUMES_URL, params={"q": query})
            resp.raise_for_status()
            data = resp.json()
        except Exception:
            return None

        items = data.get("items") if isinstance(data, dict) else None
        if not items or not isinstance(items, list):
            return None
        first = items[0]
        return first if isinstance(first, dict) else None

    # --- 解析：候选列表 -------------------------------------------------------

    def _parse_candidates(self, data: Any) -> list[Candidate]:
        """把检索响应的 items 解析为 Candidate 列表。"""
        if not isinstance(data, dict):
            return []
        items = data.get("items")
        if not items or not isinstance(items, list):
            return []

        candidates: list[Candidate] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            vol_id = item.get("id")
            info = item.get("volumeInfo") or {}
            if not vol_id or not isinstance(info, dict):
                continue
            title = info.get("title")
            if not title:
                continue

            identifiers: dict[str, str] = {"gb_id": str(vol_id)}
            isbn13 = self._extract_isbn13(info)
            if isbn13:
                identifiers["isbn13"] = isbn13

            candidates.append(
                Candidate(
                    candidate_id=f"{self.name}:{vol_id}",
                    title=str(title),
                    author=self._join_authors(info),
                    publisher=(str(info["publisher"]) if info.get("publisher") else None),
                    source=self.name,
                    identifiers=identifiers,
                )
            )
        return candidates

    # --- 解析：单条 volume → RawEditionRecord --------------------------------

    def _parse_volume(self, volume: dict, edition: str) -> RawEditionRecord | None:
        """把单个 volume 解析为 RawEditionRecord。"""
        info = volume.get("volumeInfo") or {}
        if not isinstance(info, dict):
            info = {}
        sale = volume.get("saleInfo") or {}
        if not isinstance(sale, dict):
            sale = {}

        title = info.get("title")
        latest_volume = None
        if edition == config.EDITION_MANGA:
            latest_volume = self._guess_latest_volume(info)

        return RawEditionRecord(
            edition=edition,
            source=self.name,
            title=(str(title) if title else None),
            author=self._join_authors(info),
            publisher=(str(info["publisher"]) if info.get("publisher") else None),
            format=None,  # Google Books 无判型信息
            price=self._get_price(sale),
            serialization_status=None,
            total_volumes=None,
            latest_volume=latest_volume,
            isbn=self._extract_isbn13(info),
            publish_date=self._normalize_date(info.get("publishedDate")),
        )

    # --- 字段辅助 -------------------------------------------------------------

    @staticmethod
    def _join_authors(info: dict) -> str | None:
        authors = info.get("authors")
        if isinstance(authors, list) and authors:
            return " / ".join(str(a) for a in authors)
        if isinstance(authors, str) and authors:
            return authors
        return None

    @staticmethod
    def _extract_isbn13(info: dict) -> str | None:
        """从 industryIdentifiers 取 ISBN_13（优先），否则取 ISBN_10。"""
        ids = info.get("industryIdentifiers")
        if not isinstance(ids, list):
            return None
        isbn10 = None
        for entry in ids:
            if not isinstance(entry, dict):
                continue
            t = entry.get("type")
            val = entry.get("identifier")
            if not val:
                continue
            if t == "ISBN_13":
                return str(val)
            if t == "ISBN_10" and isbn10 is None:
                isbn10 = str(val)
        return isbn10

    @staticmethod
    def _get_price(sale: dict) -> Price | None:
        """定价：从 saleInfo.retailPrice / listPrice 取（best-effort）。

        金额与币种必须成对；任一缺失返回 None。
        """
        for key in ("retailPrice", "listPrice"):
            p = sale.get(key)
            if isinstance(p, dict):
                amount = p.get("amount")
                currency = p.get("currencyCode")
                if amount is not None and currency:
                    try:
                        return Price(amount=float(amount), currency=str(currency))
                    except Exception:
                        return None
        return None

    @staticmethod
    def _normalize_date(raw: Any) -> str | None:
        """规整出版日期：Google Books 可能给 "YYYY" / "YYYY-MM" / "YYYY-MM-DD"，原样返回非空值。"""
        if not raw:
            return None
        return str(raw)

    @staticmethod
    def _guess_latest_volume(info: dict) -> int | None:
        """漫画 best-effort：从标题末尾数字推断最新册数（如 "葬送のフリーレン 13" → 13）。

        拿不到（无末尾数字）时返回 None。
        """
        title = info.get("title")
        if not title:
            return None
        m = re.search(r"(\d+)\s*$", str(title))
        if m:
            try:
                return int(m.group(1))
            except Exception:
                return None
        return None
