"""查询编排层 Aggregator。

负责两阶段查询的并发调度、单源超时与失败隔离，并将各源原始记录交给 Merger 合并：

- ``search_candidates(title, client)``：对所有具备 search 能力的 Adapter 并发检索
  候选，跨源去重合并为 ``Candidate`` 列表，失败源记入 warnings。
- ``aggregate_editions(candidate, client)``：对四类 Edition 各自并发调用其映射的
  Adapter.fetch，单源超时/失败隔离，收集非 None 原始记录交 Merger 合并，恒产出四条
  ``EditionRecord``（editions 键恒为四类，Property 1），恒附免责说明（Property 7）。

设计要点（参见 design.md 的 Aggregator 编排层 / 两阶段查询时序 / Error Handling）：

- **单源超时**：用 ``asyncio.wait_for(coro, timeout_s)`` 包裹每个 Adapter 调用，超时
  触发 ``TimeoutError`` 被本层捕获，视为空结果 + 一条 warning（R6.1）。
- **失败隔离**：对每个 Adapter 任务包 ``try/except`` 并用 ``asyncio.gather(...,
  return_exceptions=True)`` 收集，确保单任务异常/超时不取消同批其他任务，也不影响
  其他 Edition（Property 12，R6.2）。
- **全源失败**：若所有 Edition 的所有源都失败/无结果，则四版本 present=False 占位、
  ``all_sources_failed=True``、追加一条全局 warning（Property 13，R6.3）。
- **恒四版本**：无论各源返回何种组合，``editions`` 键集合恒为 ``config.ALL_EDITIONS``，
  每类恰一条（Property 1，R2.2）。

所有超时、占位、映射常量均从 ``app.config`` 引用，不硬编码。
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from app.shared import config
from app.modules.book_lookup.merger import Merger
from app.modules.book_lookup.models import (
    Candidate,
    DetailResult,
    EditionRecord,
    RawEditionRecord,
    SearchResult,
    Warning,
)
from app.modules.book_lookup.registry import AdapterRegistry

if TYPE_CHECKING:  # 仅类型检查期引入，运行期不强依赖 httpx。
    import httpx
    from app.modules.book_lookup.adapters.base import DataSourceAdapter


class Aggregator:
    """跨源并发编排器：施加单源超时与失败隔离，聚合结果交 Merger 合并。"""

    def __init__(
        self,
        registry: AdapterRegistry,
        merger: Merger | None = None,
        timeout_s: float = config.DEFAULT_TIMEOUT_S,
    ) -> None:
        """构造编排器。

        Args:
            registry: 适配器注册表，用于解析 Edition→Adapter 与 search 能力集合。
            merger: 合并去重器；默认新建一个 ``Merger()``（无状态，可安全复用）。
            timeout_s: 单数据源请求超时上界（秒），默认 ``config.DEFAULT_TIMEOUT_S``。
        """
        self._registry = registry
        self._merger = merger if merger is not None else Merger()
        self._timeout_s = timeout_s

    # ------------------------------------------------------------------ #
    # 第一阶段：候选检索                                                  #
    # ------------------------------------------------------------------ #
    async def search_candidates(
        self, title: str, client: "httpx.AsyncClient"
    ) -> SearchResult:
        """对所有具备 search 能力的 Adapter 并发检索候选，跨源去重合并。

        单源用 ``asyncio.wait_for(timeout_s)`` 包裹，异常/超时被隔离（不取消其他任务），
        失败源记入 ``warnings``。跨源候选按 ``candidate_id``（缺失时退化为 ``title+isbn``）
        去重。

        Args:
            title: 用户输入的书名（已由上层校验非空）。
            client: 由上层注入并复用的异步 HTTP 客户端（无代理直连）。

        Returns:
            ``SearchResult(query=title, candidates=去重合并后列表, warnings=失败源提示)``。
        """
        adapters = self._registry.search_adapters()
        warnings: list[Warning] = []

        # 为每个 Adapter 构造一个"带超时 + 失败隔离"的子任务协程。
        async def _one(adapter: "DataSourceAdapter") -> list[Candidate]:
            try:
                return await asyncio.wait_for(
                    adapter.search(title, client), timeout=self._timeout_s
                )
            except asyncio.TimeoutError:
                warnings.append(
                    Warning(
                        source=getattr(adapter, "name", None),
                        message=f"数据源 {getattr(adapter, 'name', '未知')} 检索超时",
                    )
                )
                return []
            except Exception as exc:  # noqa: BLE001 —— 失败隔离：任何源特有异常都不外泄。
                warnings.append(
                    Warning(
                        source=getattr(adapter, "name", None),
                        message=f"数据源 {getattr(adapter, 'name', '未知')} 检索失败：{exc}",
                    )
                )
                return []

        # 并发执行；return_exceptions=True 兜底（正常情况下 _one 已吞掉所有异常）。
        results = await asyncio.gather(
            *(_one(a) for a in adapters), return_exceptions=True
        )

        # 跨源去重合并。
        candidates: list[Candidate] = []
        seen: set[str] = set()
        for res in results:
            if isinstance(res, BaseException) or res is None:
                # 兜底：gather 层面若仍捕获到异常，忽略该源结果（已在 _one 记 warning）。
                continue
            for cand in res:
                key = self._candidate_key(cand)
                if key in seen:
                    continue
                seen.add(key)
                candidates.append(cand)

        return SearchResult(query=title, candidates=candidates, warnings=warnings)

    @staticmethod
    def _candidate_key(cand: Candidate) -> str:
        """候选去重键：优先用 candidate_id；缺失时退化为 title + isbn 组合。"""
        cid = getattr(cand, "candidate_id", None)
        if cid:
            return f"id::{cid}"
        isbn = ""
        identifiers = getattr(cand, "identifiers", None) or {}
        # 常见 isbn 键。
        for k in ("isbn13", "isbn", "isbn10"):
            if identifiers.get(k):
                isbn = identifiers[k]
                break
        return f"ti::{getattr(cand, 'title', '')}::{isbn}"

    # ------------------------------------------------------------------ #
    # 第二阶段：四版本聚合                                                #
    # ------------------------------------------------------------------ #
    async def aggregate_editions(
        self, candidate: Candidate, client: "httpx.AsyncClient"
    ) -> DetailResult:
        """对四类 Edition 各并发调用其映射 Adapter.fetch，合并为四条 EditionRecord。

        - 每个源用 ``asyncio.wait_for(timeout_s)`` 包裹，超时/异常隔离（不取消其他任务，
          不影响其他 Edition，Property 12）。
        - 某 Edition 收到的非 None ``RawEditionRecord`` 交 ``merger.merge`` 得到
          ``EditionRecord``；无任何记录时 merge 返回 present=False 占位。
        - ``editions`` 键恒为 ``config.ALL_EDITIONS`` 四类（Property 1）。
        - 每个失败源记一条 warning。
        - 所有 Edition 的所有源都失败/无结果 → 四版本 present=False + ``all_sources_failed
          =True`` + 一条全局 warning（Property 13）。
        - 恒附 ``disclaimer=config.SERIALIZATION_DISCLAIMER``（Property 7）。

        Args:
            candidate: search 阶段选定并回传的候选作品。
            client: 由上层注入并复用的异步 HTTP 客户端（无代理直连）。

        Returns:
            ``DetailResult``（恒四版本 + disclaimer + warnings + all_sources_failed）。
        """
        warnings: list[Warning] = []
        editions: dict[str, EditionRecord] = {}

        # 统计"是否存在任一源成功产出了非 None 记录"，用于全源失败判定（Property 13）。
        any_source_succeeded = False
        # 统计"是否存在任一源被实际调度"（用于区分"无源可调度"与"有源但全失败"）。
        any_source_dispatched = False

        for edition in config.ALL_EDITIONS:
            adapters = self._registry.adapters_for_edition(edition)

            # 单源 fetch：带超时 + 失败隔离；成功返回 RawEditionRecord|None，失败返回 None。
            async def _fetch_one(
                adapter: "DataSourceAdapter", ed: str = edition
            ) -> RawEditionRecord | None:
                try:
                    return await asyncio.wait_for(
                        adapter.fetch(candidate, ed, client), timeout=self._timeout_s
                    )
                except asyncio.TimeoutError:
                    warnings.append(
                        Warning(
                            edition=ed,
                            source=getattr(adapter, "name", None),
                            message=(
                                f"数据源 {getattr(adapter, 'name', '未知')} "
                                f"抓取 {ed} 超时"
                            ),
                        )
                    )
                    return None
                except Exception as exc:  # noqa: BLE001 —— 失败隔离。
                    warnings.append(
                        Warning(
                            edition=ed,
                            source=getattr(adapter, "name", None),
                            message=(
                                f"数据源 {getattr(adapter, 'name', '未知')} "
                                f"抓取 {ed} 失败：{exc}"
                            ),
                        )
                    )
                    return None

            if adapters:
                any_source_dispatched = True

            # 该 Edition 内并发调度其所有映射 Adapter。
            fetched = await asyncio.gather(
                *(_fetch_one(a) for a in adapters), return_exceptions=True
            )

            # 收集非 None 的 RawEditionRecord。
            raws: list[RawEditionRecord] = []
            for item in fetched:
                if isinstance(item, BaseException) or item is None:
                    continue
                raws.append(item)

            if raws:
                any_source_succeeded = True

            # 交 Merger 合并（空列表 → present=False 占位）。
            editions[edition] = self._merger.merge(edition, raws)

        # ---- 全源失败判定（Property 13） ----
        # 仅当"确有源被调度、但没有任何源成功产出记录"时，判定为全源失败。
        # （若根本无源可调度——例如所有 Edition 都无映射，则四版本本就占位，
        #  但不追加"所有数据源不可用"的全局提示，因为并非源不可用而是无源。）
        all_sources_failed = any_source_dispatched and not any_source_succeeded

        if all_sources_failed:
            warnings.append(
                Warning(
                    edition=None,
                    source=None,
                    message="所有数据源均不可用，暂时无法获取任何版本信息。",
                )
            )

        return DetailResult(
            query_title=candidate.title,
            editions=editions,
            disclaimer=config.SERIALIZATION_DISCLAIMER,  # 恒附免责说明（Property 7）
            warnings=warnings,
            all_sources_failed=all_sources_failed,
        )
