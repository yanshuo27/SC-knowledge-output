"""共享配置层：集中定义端口、超时、占位常量、Edition→Adapter 映射、数据源优先级，
以及图书管理模块（library）专属配置。

本模块是平台级文案与调度映射的唯一权威来源，book_lookup、library 及前端启动配置
均应从此处引用常量，避免硬编码导致文案漂移。
"""

import os
from pathlib import Path

# --- 服务启动 ---
DEFAULT_PORT = 8000          # uvicorn 默认绑定端口（R9.3）
DEFAULT_TIMEOUT_S = 8.0     # 单数据源请求超时上界，单位秒（R6.1 / R6.4）

# --- 缺失呈现占位常量（前后端同源，R13.1 / R13.2） ---
UNKNOWN_MARKER = "N/A"                        # 普通字段缺失标记（R3.3 / R13.2）
MISSING_EDITION_PLACEHOLDER = "无此版本信息"   # 整版缺失占位（R2.3 / R13.1）

# 连载状态免责说明，detail 响应恒携带此文本（R4.4 / R4.5）
SERIALIZATION_DISCLAIMER = (
    "连载状态、总卷数及最新册数为尽力而为数据，可能为「未知」，不保证准确或齐全。"
)

# --- Edition 名称常量（供其他模块引用，避免硬编码字符串） ---
EDITION_JP = "日版"      # 日版原版
EDITION_TW = "台版"      # 台版繁中
EDITION_HK = "港版"      # 港版繁中
EDITION_MANGA = "漫画"   # 漫画系列信息

# 四类 Edition 的固定顺序集合（editions 键恒为这四个，R2.2）
ALL_EDITIONS = [EDITION_TW, EDITION_HK, EDITION_JP, EDITION_MANGA]

# --- 数据源名称常量 ---
SOURCE_OPENBD = "openbd"
SOURCE_GOOGLE_BOOKS = "google_books"
SOURCE_NDL = "ndl"
SOURCE_BOOKS_COM_TW = "books_com_tw"
SOURCE_HK_GENERIC = "hk_generic"

# Edition → 该 Edition 启用的 Adapter 名称列表（R5.5 可配置映射）
EDITION_ADAPTER_MAP = {
    EDITION_JP: [SOURCE_OPENBD, SOURCE_GOOGLE_BOOKS, SOURCE_NDL],
    EDITION_TW: [SOURCE_BOOKS_COM_TW],
    EDITION_HK: [SOURCE_HK_GENERIC],
    EDITION_MANGA: [SOURCE_GOOGLE_BOOKS],
}

# 数据源优先级（数字越小越优先，用于冲突选值 R7.3）
SOURCE_PRIORITY = {
    SOURCE_OPENBD: 1,
    SOURCE_BOOKS_COM_TW: 1,
    SOURCE_NDL: 2,
    SOURCE_GOOGLE_BOOKS: 3,
    SOURCE_HK_GENERIC: 4,
}

# --- 图书管理模块（library）专属配置 ---
# SQLite 数据库文件路径：默认 <项目根>/data/library.db，允许环境变量 LIBRARY_DB_PATH 覆盖。
# 本文件位于 app/shared/config.py，parents[2] 即项目根目录。
_DEFAULT_LIBRARY_DB_PATH = str(
    Path(__file__).resolve().parents[2] / "data" / "library.db"
)
LIBRARY_DB_PATH = os.environ.get("LIBRARY_DB_PATH", _DEFAULT_LIBRARY_DB_PATH)

# Ownership_Status（藏书状态）合法取值（R2.5 / R3.2）
OWNERSHIP_STATUSES = ["想要", "已购", "已售"]
