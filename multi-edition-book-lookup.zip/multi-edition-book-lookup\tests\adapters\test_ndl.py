"""NdlAdapter 解析单测。

使用录制的 NDL OpenSearch XML 样例，配合 `pytest-httpx` 的 `httpx_mock` 拦截请求
（不打真实网络），断言 XML → RawEditionRecord 的字段映射。
"""

from __future__ import annotations

from pathlib import Path

import httpx
import pytest

from app.shared import config
from app.modules.book_lookup.adapters.ndl import NdlAdapter
from app.modules.book_lookup.models import Candidate

_FIXTURES = Path(__file__).parent / "fixtures"


def _load_bytes(name: str) -> bytes:
    return (_FIXTURES / name).read_bytes()


def _candidate(title: str = "葬送のフリーレン") -> Candidate:
    return Candidate(candidate_id="test:frieren", title=title, source="test")


async def test_fetch_parses_first_item(httpx_mock):
    """完整 XML → 取首个 item，映射书名/作者/出版社/ISBN/出版日期；无定价。"""
    httpx_mock.add_response(
        content=_load_bytes("ndl_frieren.xml"),
        headers={"content-type": "application/xml"},
    )
    adapter = NdlAdapter()
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(_candidate(), config.EDITION_JP, client)

    assert rec is not None
    assert rec.edition == config.EDITION_JP
    assert rec.source == config.SOURCE_NDL
    assert rec.title == "葬送のフリーレン 1"
    # author 优先取 <author>，其次 dc:creator
    assert rec.author == "山田鐘人 原作 / アベツカサ 作画"
    assert rec.publisher == "小学館"
    assert rec.publish_date == "2020-08"
    assert rec.isbn == "9784098501234"
    # NDL 无定价
    assert rec.price is None
    assert rec.serialization_status is None


async def test_fetch_empty_result_returns_none(httpx_mock):
    """无 item 的空结果 XML → fetch 返回 None。"""
    httpx_mock.add_response(
        content=_load_bytes("ndl_empty.xml"),
        headers={"content-type": "application/xml"},
    )
    adapter = NdlAdapter()
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(_candidate(), config.EDITION_JP, client)
    assert rec is None


async def test_fetch_without_title_returns_none():
    """candidate 无书名 → 直接返回 None（不发请求）。"""
    adapter = NdlAdapter()
    cand = Candidate(candidate_id="test:x", title="   ", source="test")
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(cand, config.EDITION_JP, client)
    assert rec is None


async def test_fetch_http_error_returns_none(httpx_mock):
    """HTTP 错误 → 吞掉转 None。"""
    httpx_mock.add_response(status_code=500)
    adapter = NdlAdapter()
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(_candidate(), config.EDITION_JP, client)
    assert rec is None


async def test_fetch_malformed_xml_returns_none(httpx_mock):
    """XML 解析失败 → 吞掉转 None，不外抛。"""
    httpx_mock.add_response(
        content=b"<rss><channel><item><title>unclosed",
        headers={"content-type": "application/xml"},
    )
    adapter = NdlAdapter()
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(_candidate(), config.EDITION_JP, client)
    assert rec is None


async def test_fetch_network_error_returns_none(httpx_mock):
    """网络异常 → 吞掉转 None。"""
    httpx_mock.add_exception(httpx.ConnectError("boom"))
    adapter = NdlAdapter()
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(_candidate(), config.EDITION_JP, client)
    assert rec is None


async def test_search_returns_empty():
    """NDL 作为交叉校验源，search 恒返回 []。"""
    adapter = NdlAdapter()
    async with httpx.AsyncClient() as client:
        result = await adapter.search("葬送のフリーレン", client)
    assert result == []


def test_adapter_metadata():
    """name 用 config 常量，supported_editions 含日版。"""
    adapter = NdlAdapter()
    assert adapter.name == config.SOURCE_NDL
    assert config.EDITION_JP in adapter.supported_editions
