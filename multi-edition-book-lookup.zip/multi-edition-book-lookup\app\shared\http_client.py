"""共享 HTTP 客户端构造层：提供无代理的 httpx.AsyncClient 公共构造函数。

从旧 app/main.py 的 `_build_async_client()` 抽出为公共函数，供 book_lookup 模块
（并发抓取数据源）复用，确保并发请求走直连而非环境代理（R5.6）。
"""

from __future__ import annotations

import httpx

from app.shared import config


def build_async_client() -> httpx.AsyncClient:
    """构造**无代理**的异步 HTTP 客户端（R5.6）。

    - ``trust_env=False``：忽略 ``HTTP_PROXY`` / ``HTTPS_PROXY`` 等环境变量，
      避免继承系统代理。
    - 不传 ``proxy`` / ``proxies`` 参数：不设置任何代理，走直连。
    - 设置合理的连接超时，实际单源超时由 Aggregator 用 ``asyncio.wait_for`` 施加。
    """
    return httpx.AsyncClient(
        trust_env=False,
        timeout=httpx.Timeout(config.DEFAULT_TIMEOUT_S),
        follow_redirects=True,
    )
