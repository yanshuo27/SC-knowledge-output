"""统一数据模型（跨层契约）。

包含 search / detail 两阶段 API 的请求与响应模型，以及 Adapter 层产出的
单源原始记录 `RawEditionRecord` 与 Merger 合并后的对外记录 `EditionRecord`。

设计约定（参见 design.md 的 Data Models 章节）：
- 缺失字段在 Adapter 层一律置 `None`，由 Merger 统一转为 `Unknown_Marker`("N/A")。
- 连载状态严格限定为 `完结 / 连载中 / 未知` 三者之一。
- 使用 pydantic v2 语法（`BaseModel` + 字段默认值 / `default_factory`）。
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class SerializationStatus(str, Enum):
    """连载状态枚举。

    取值严格限定为三者之一（R3.4）。注意：连载状态即使"未知"也不是
    `Unknown_Marker`，而是枚举值 `"未知"`；`Unknown_Marker`("N/A") 用于其他普通字段。
    """

    COMPLETED = "完结"
    ONGOING = "连载中"
    UNKNOWN = "未知"  # 默认值；任何源都拿不到时落此（R4.1）


class Price(BaseModel):
    """定价。金额与币种必须成对出现，不存在只有其一的中间态（R3.2 / Property 4）。"""

    amount: float
    currency: str  # ISO 4217，如 "JPY" / "TWD"


class Candidate(BaseModel):
    """候选作品（search 阶段产出，detail 阶段回传）。"""

    candidate_id: str  # {source}:{源内ID} 或派生哈希，稳定可回传
    title: str
    author: str | None = None
    publisher: str | None = None
    source: str  # 产出该候选的数据源名
    identifiers: dict[str, str] = Field(default_factory=dict)  # 如 {"isbn13": "...", "gb_id": "..."}


class RawEditionRecord(BaseModel):
    """Adapter 产出的单源原始记录（内部用）。

    各字段可为 `None` 表示该源未提供；缺失字段不在 Adapter 层填占位，
    交由 Merger 统一处理。
    """

    edition: str  # 台版 / 港版 / 日版 / 漫画
    source: str  # 数据源名
    title: str | None = None
    author: str | None = None
    publisher: str | None = None
    format: str | None = None  # 开本 / 判型
    price: Price | None = None
    serialization_status: SerializationStatus | None = None
    total_volumes: int | None = None
    latest_volume: int | None = None
    isbn: str | None = None
    publish_date: str | None = None  # ISO 8601 字符串


class EditionRecord(BaseModel):
    """合并后的对外版本记录。

    序列化为 API 响应中 `editions[<edition>]`。缺失字段以 `Unknown_Marker` 字符串
    呈现，整版缺失以 `present=False` + `placeholder` 呈现。
    """

    edition: str
    present: bool  # False → 整版缺失（R2.3 / R13.1）
    placeholder: str | None = None  # present=False 时为 MISSING_EDITION_PLACEHOLDER
    # 以下字段：present=True 时为实际值或 Unknown_Marker("N/A")；present=False 时省略
    title: str | None = None
    author: str | None = None
    publisher: str | None = None
    format: str | None = None
    price: Price | str | None = None  # 缺失时为 "N/A"
    serialization_status: str | None = None  # 枚举值 完结 / 连载中 / 未知
    total_volumes: str | None = None  # "N/A" 或数字字符串（连载中/未知恒为 N/A，R4.2）
    latest_volume: str | None = None  # "N/A" 或数字字符串
    isbn: str | None = None
    publish_date: str | None = None
    sources: list[str] = Field(default_factory=list)  # 来源数据源集合（R7.4）
    field_conflicts: list[str] = Field(default_factory=list)  # 存在来源冲突的字段名（R7.3）


class Warning(BaseModel):
    """告警条目。`edition` / `source` 为 None 表示全局。"""

    edition: str | None = None
    source: str | None = None
    message: str


class SearchResult(BaseModel):
    """search 响应模型。"""

    query: str
    candidates: list[Candidate]
    auto_selected: bool = False  # CLI 非交互自动选优时为 True（R8.5）
    warnings: list[Warning] = Field(default_factory=list)


class DetailResult(BaseModel):
    """detail 响应模型。"""

    query_title: str
    editions: dict[str, EditionRecord]  # 键恒为 台版 / 港版 / 日版 / 漫画（R2.2）
    disclaimer: str  # SERIALIZATION_DISCLAIMER（R4.4）
    warnings: list[Warning] = Field(default_factory=list)
    all_sources_failed: bool = False  # R6.3
