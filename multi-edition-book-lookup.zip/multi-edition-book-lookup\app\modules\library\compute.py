"""library 计算字段纯函数：利润（Profit）与利润率（Profit_Rate）。

这两个函数是无副作用的纯函数，不依赖数据库或网络，便于单元测试与属性测试。
设计约定：任一价格缺失（None）时，计算字段留空（返回 None），而不是显示为 0；
买入价为 0 时利润率留空（避免除零）。
"""

from __future__ import annotations


def compute_profit(purchase: float | None, sale: float | None) -> float | None:
    """计算利润 = 卖出价 - 买入价。

    买入价或卖出价任一为 None 时返回 None（留空而非 0）。
    """
    if purchase is None or sale is None:
        return None
    return sale - purchase


def compute_profit_rate(purchase: float | None, sale: float | None) -> float | None:
    """计算利润率(%) = (卖出价 - 买入价) / 买入价 * 100。

    买入价为 None 或 0、或卖出价为 None 时返回 None（不发生除零、留空而非 0）。
    """
    if purchase is None or sale is None or purchase == 0:
        return None
    return (sale - purchase) / purchase * 100.0
