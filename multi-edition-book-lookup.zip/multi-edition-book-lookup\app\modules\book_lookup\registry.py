"""适配器注册表 AdapterRegistry。

负责集中管理已注册的 `DataSourceAdapter` 实例，并提供两类查询能力，供编排层
（Aggregator）在两阶段查询中调度：

- **按 Edition 解析 Adapter 列表**：依据 `config.EDITION_ADAPTER_MAP` 声明的
  ``Edition → adapter 名称列表`` 映射，返回该 Edition 对应且**已注册**的 Adapter
  实例（保持映射中声明的顺序）。某 Edition 无映射、映射为空、或映射的名字未注册，
  则返回空列表——港版因通常无稳定源而稳定落空即由此保证（R5.4）。
- **具备 search 能力的全部 Adapter**：search 阶段需对所有数据源并发检索候选，
  故返回全部已注册 Adapter（按注册顺序、去重）。

设计约定（参见 design.md 的 Aggregator 编排层与配置层章节）：
- 注册以 ``adapter.name`` 为索引键；同名重复注册以后者覆盖前者。
- 映射的唯一权威来源是 `app.config.EDITION_ADAPTER_MAP`，本类不硬编码 Edition。
"""

from __future__ import annotations

from app.shared import config
from app.modules.book_lookup.adapters.base import DataSourceAdapter


class AdapterRegistry:
    """按名注册 Adapter，并按 `EDITION_ADAPTER_MAP` 解析 Edition→Adapter。"""

    def __init__(self) -> None:
        # 以 adapter.name 为键的有序索引（dict 在 3.7+ 保持插入顺序）。
        self._adapters: dict[str, DataSourceAdapter] = {}

    def register(self, adapter: DataSourceAdapter) -> None:
        """注册一个 Adapter 实例，按其 ``name`` 建索引。

        同名重复注册时，后注册者覆盖先注册者（便于测试替换/覆盖默认源）。
        """
        self._adapters[adapter.name] = adapter

    def get(self, name: str) -> DataSourceAdapter | None:
        """按名称取回已注册的 Adapter；未注册返回 ``None``。"""
        return self._adapters.get(name)

    def adapters_for_edition(self, edition: str) -> list[DataSourceAdapter]:
        """解析某 Edition 映射的、且已注册的 Adapter 列表。

        依据 `config.EDITION_ADAPTER_MAP` 中该 Edition 声明的名称顺序返回对应的
        已注册实例。以下情形均返回空列表：
        - 该 Edition 不在映射中（未声明）；
        - 该 Edition 映射为空列表；
        - 映射声明的名字均未注册（如港版的 ``hk_generic`` 未注册，R5.4）。

        Args:
            edition: 目标 Edition（台版 / 港版 / 日版 / 漫画之一）。

        Returns:
            按映射顺序排列的已注册 Adapter 实例列表；无匹配时为空列表。
        """
        names = config.EDITION_ADAPTER_MAP.get(edition, [])
        return [self._adapters[name] for name in names if name in self._adapters]

    def search_adapters(self) -> list[DataSourceAdapter]:
        """返回具备 search 能力的全部 Adapter（即全部已注册 Adapter）。

        search 阶段需对所有数据源并发检索候选，故此处汇总所有已注册 Adapter，
        按注册顺序返回（键索引天然去重）。

        Returns:
            全部已注册 Adapter 实例列表（去重、保持注册顺序）。
        """
        return list(self._adapters.values())
