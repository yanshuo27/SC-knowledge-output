@echo off
REM ============================================================
REM shu ji gong ju ping tai (cha shu + tu shu guan li) -- one-click launcher (Windows)
REM first run: create .venv with Python 3.11, install deps, start service and open browser.
REM later runs: reuse existing .venv and start directly.
REM requires: Python 3.11 installed (py -3.11 available).
REM ============================================================
setlocal
cd /d "%~dp0"

py -3.11 --version >nul 2>&1
if errorlevel 1 (
    echo [error] Python 3.11 not found. Please install Python 3.11 with py launcher.
    echo Download: https://www.python.org/downloads/
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo [init] creating virtual env .venv ...
    py -3.11 -m venv .venv
    if errorlevel 1 ( echo [error] create venv failed. & pause & exit /b 1 )
    echo [init] installing dependencies, first run may be slow ...
    REM slow network: append  -i https://pypi.tuna.tsinghua.edu.cn/simple  to the pip install line
    ".venv\Scripts\python.exe" -m pip install --upgrade pip
    ".venv\Scripts\python.exe" -m pip install -e .
    if errorlevel 1 ( echo [error] dependency install failed; try a mirror index. & pause & exit /b 1 )
)

set PORT=8000
echo [start] local service: http://127.0.0.1:%PORT%   (close this window to stop)
start "" "http://127.0.0.1:%PORT%"
".venv\Scripts\python.exe" -m uvicorn app.main:app --port %PORT%
endlocal
