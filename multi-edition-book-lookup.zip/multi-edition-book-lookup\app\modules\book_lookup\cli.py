"""命令行入口（CLI）。

支持两类用法：

1. **查询模式**：``python -m app.cli "书名" [--format json|table]``
   跨源检索候选 → 非交互自动选排序首位候选（``auto_selected=True``，R8.5）→ 四版本聚合 →
   以 ``table``（纯文本四版本对照表格，默认）或 ``json``（DetailResult 的 JSON）输出。

2. **启动模式**：``python -m app.cli --serve [--port N]``
   用 uvicorn 启动本地 Web 服务（``app.main:app``）。端口占用（EADDRINUSE）→ 提示 + 非零退出（R9.4）。

设计与错误处理约定（参见 design.md 的 Error Handling「CLI / 启动层」）：

- 未提供书名且非 ``--serve`` → 打印用法提示到 stderr，``sys.exit(2)``（R1.4）。
- 不支持的 ``--format`` 取值 → 打印"支持的取值：json, table"，非零退出（R12.5）。
- 端口被占用（``OSError`` / ``errno EADDRINUSE``）→ 打印端口不可用提示，非零退出（R9.4）。
- 非交互多候选 → 自动选排序首位并标注 ``auto_selected=True``（R8.5）。
- 查询用**无代理** ``httpx.AsyncClient`` + ``Aggregator`` + 默认 registry，``asyncio.run`` 驱动。
- ``app.main`` 在 ``serve`` 函数内**延迟 import**，避免导入期对 FastAPI 应用的耦合。

_Requirements: 1.4, 8.5, 9.3, 9.4, 12.4, 12.5_
"""

from __future__ import annotations

import argparse
import asyncio
import errno
import sys
from typing import TYPE_CHECKING

from app.shared import config
from app.modules.book_lookup.models import Candidate, DetailResult, EditionRecord, Price

if TYPE_CHECKING:  # 仅类型检查期引入，运行期避免强依赖。
    from app.modules.book_lookup.aggregator import Aggregator

# --- 输出格式常量 ---
FORMAT_JSON = "json"
FORMAT_TABLE = "table"
SUPPORTED_FORMATS = (FORMAT_JSON, FORMAT_TABLE)

# 退出码
EXIT_OK = 0
EXIT_USAGE = 2  # 无书名参数（argparse 惯例：用法错误用 2）
EXIT_ERROR = 1  # 非法 format / 端口占用等一般性错误


class CliError(Exception):
    """CLI 层可预期错误：携带面向用户的消息与退出码。

    由 ``main`` 统一捕获：把 ``message`` 打到 stderr，并以 ``exit_code`` 退出。
    这样便于对 ``run``/``serve`` 等纯逻辑做单元测试（断言异常而非进程退出）。
    """

    def __init__(self, message: str, exit_code: int = EXIT_ERROR) -> None:
        super().__init__(message)
        self.message = message
        self.exit_code = exit_code


# ------------------------------------------------------------------------- #
# 纯逻辑：格式校验                                                           #
# ------------------------------------------------------------------------- #
def validate_format(fmt: str) -> str:
    """校验输出格式取值；非法则抛 ``CliError``（含受支持取值列表，R12.5 / Property 19）。

    Args:
        fmt: 待校验的格式字符串。

    Returns:
        校验通过的格式字符串（原样返回）。

    Raises:
        CliError: 当 ``fmt`` 不属于 ``SUPPORTED_FORMATS`` 时，消息形如
            "不支持的输出格式：{fmt}。支持的取值：json, table"，退出码为 ``EXIT_ERROR``（非零）。
    """
    if fmt not in SUPPORTED_FORMATS:
        supported = ", ".join(SUPPORTED_FORMATS)
        raise CliError(
            f"不支持的输出格式：{fmt}。支持的取值：{supported}",
            exit_code=EXIT_ERROR,
        )
    return fmt


# ------------------------------------------------------------------------- #
# 纯逻辑：非交互候选自动选优                                                 #
# ------------------------------------------------------------------------- #
def select_candidate(
    candidates: list[Candidate],
) -> tuple[Candidate | None, bool]:
    """非交互模式的候选选择逻辑（R8.5 / Property 18）。

    - 无候选 → 返回 ``(None, False)``。
    - 恰一个候选 → 返回 ``(该候选, False)``（无需消歧，不算自动选优）。
    - 多于一个候选 → 恒选取排序**首位**（列表第 0 项）并返回 ``(首位, True)``。

    Args:
        candidates: search 阶段产出的候选列表（顺序即为排序结果）。

    Returns:
        ``(选中的候选或 None, auto_selected 标志)``。仅当从 ≥2 个候选中自动挑选首位时
        ``auto_selected`` 为 ``True``。
    """
    if not candidates:
        return None, False
    if len(candidates) == 1:
        return candidates[0], False
    # ≥2 个候选：非交互下恒选排序首位，并标注自动选优。
    return candidates[0], True


# ------------------------------------------------------------------------- #
# 渲染：JSON / table                                                        #
# ------------------------------------------------------------------------- #
def _price_to_text(value: object) -> str:
    """把 EditionRecord.price 渲染为纯文本：完整 Price → "金额 币种"；否则原样字符串。"""
    if isinstance(value, Price):
        # amount 可能是整数金额的浮点表示，去掉多余的 .0。
        amount = value.amount
        if isinstance(amount, float) and amount.is_integer():
            amount_text = str(int(amount))
        else:
            amount_text = str(amount)
        return f"{amount_text} {value.currency}"
    if value is None:
        return config.UNKNOWN_MARKER
    return str(value)


def _cell_text(value: object) -> str:
    """把任意单元格值渲染为纯文本；None 归一为 UNKNOWN_MARKER。"""
    if value is None:
        return config.UNKNOWN_MARKER
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value) if value else config.UNKNOWN_MARKER
    return str(value)


# table 输出的字段行定义：(表头标签, EditionRecord 属性名)。
_TABLE_ROWS: list[tuple[str, str]] = [
    ("书名", "title"),
    ("作者", "author"),
    ("出版社", "publisher"),
    ("判型", "format"),
    ("定价", "price"),
    ("连载状态", "serialization_status"),
    ("总卷数", "total_volumes"),
    ("最新册数", "latest_volume"),
    ("ISBN", "isbn"),
    ("出版日期", "publish_date"),
    ("来源", "sources"),
]


def _display_width(text: str) -> int:
    """估算字符串的显示宽度：CJK/全角字符按 2 计，其余按 1 计。

    用于纯文本表格的列宽对齐，避免中日文与 ASCII 混排时错位。
    """
    width = 0
    for ch in text:
        code = ord(ch)
        # 常见 CJK / 全角区间粗略判定。
        if (
            0x1100 <= code <= 0x115F  # Hangul Jamo
            or 0x2E80 <= code <= 0xA4CF  # CJK 及部首等
            or 0xAC00 <= code <= 0xD7A3  # Hangul 音节
            or 0xF900 <= code <= 0xFAFF  # CJK 兼容
            or 0xFE30 <= code <= 0xFE4F  # CJK 兼容形式
            or 0xFF00 <= code <= 0xFF60  # 全角 ASCII
            or 0xFFE0 <= code <= 0xFFE6  # 全角符号
        ):
            width += 2
        else:
            width += 1
    return width


def _pad(text: str, target_width: int) -> str:
    """按显示宽度右侧补空格，使 ``text`` 占满 ``target_width``。"""
    pad = target_width - _display_width(text)
    return text + (" " * pad if pad > 0 else "")


def render_table(result: DetailResult) -> str:
    """把四版本 EditionRecord 渲染为纯文本对照表格（R12.4）。

    - 首列为字段标签，其后每列对应一个 Edition（顺序为 ``config.ALL_EDITIONS``）。
    - 整版缺失（``present is False``）的列，各字段格统一显示 ``placeholder``（无此版本信息）。
    - 字段缺失显示后端给的 ``N/A``（不硬编码，从 EditionRecord 取值）。

    Args:
        result: detail 聚合结果（恒含四类 Edition）。

    Returns:
        多行纯文本表格字符串（含表头行、分隔行、免责说明与 warnings）。
    """
    editions = config.ALL_EDITIONS
    # 表头：首列 + 四个 Edition 名。
    header = ["字段", *editions]

    # 逐行构造单元格文本矩阵。
    rows: list[list[str]] = [header]
    for label, attr in _TABLE_ROWS:
        row = [label]
        for ed in editions:
            rec: EditionRecord = result.editions[ed]
            if rec.present is False:
                # 整版缺失：整列以 placeholder 呈现（取后端值，不硬编码）。
                row.append(_cell_text(rec.placeholder))
                continue
            value = getattr(rec, attr, None)
            if attr == "price":
                row.append(_price_to_text(value))
            else:
                row.append(_cell_text(value))
        rows.append(row)

    # 计算每列宽度（按显示宽度）。
    col_count = len(header)
    widths = [0] * col_count
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], _display_width(cell))

    def _fmt_row(row: list[str]) -> str:
        return " | ".join(_pad(cell, widths[i]) for i, cell in enumerate(row))

    lines: list[str] = []
    lines.append(f"作品：{result.query_title}")
    lines.append("")
    lines.append(_fmt_row(rows[0]))  # 表头
    # 分隔线。
    sep = "-+-".join("-" * widths[i] for i in range(col_count))
    lines.append(sep)
    for row in rows[1:]:
        lines.append(_fmt_row(row))

    # 免责说明。
    lines.append("")
    lines.append(f"免责：{result.disclaimer}")

    # warnings（若有）。
    if result.warnings:
        lines.append("")
        lines.append("提示：")
        for w in result.warnings:
            scope = w.edition or "全局"
            lines.append(f"  - [{scope}] {w.message}")

    return "\n".join(lines)


def render_json(result: DetailResult) -> str:
    """把 DetailResult 序列化为 JSON 字符串（R12.4，保留非 ASCII 原文）。"""
    return result.model_dump_json(indent=2)


def render_result(result: DetailResult, fmt: str) -> str:
    """按格式渲染 detail 结果。``fmt`` 已由 ``validate_format`` 校验。"""
    if fmt == FORMAT_JSON:
        return render_json(result)
    return render_table(result)


# ------------------------------------------------------------------------- #
# 查询执行                                                                   #
# ------------------------------------------------------------------------- #
def build_default_aggregator() -> "Aggregator":
    """构造默认注册表 + Aggregator（注册全部真实 Adapter）。

    延迟 import 各 Adapter 与 Aggregator，避免 CLI 模块导入期强依赖 httpx/解析库。
    某个 Adapter 导入失败时跳过该源（best-effort），不影响其余源可用。
    """
    from app.modules.book_lookup.aggregator import Aggregator
    from app.modules.book_lookup.registry import AdapterRegistry

    registry = AdapterRegistry()

    # 按名注册可用的真实 Adapter；导入失败的源跳过（保持 best-effort）。
    _adapter_specs = [
        ("app.adapters.openbd", "OpenBdAdapter"),
        ("app.adapters.google_books", "GoogleBooksAdapter"),
        ("app.adapters.ndl", "NdlAdapter"),
        ("app.adapters.books_com_tw", "BooksComTwAdapter"),
        ("app.adapters.hk_generic", "HkGenericAdapter"),
    ]
    import importlib

    for module_path, class_name in _adapter_specs:
        try:
            module = importlib.import_module(module_path)
            adapter_cls = getattr(module, class_name)
            registry.register(adapter_cls())
        except Exception:  # noqa: BLE001 —— 单个源不可用不影响其余源。
            continue

    return Aggregator(registry)


async def _run_query_async(title: str, aggregator: "Aggregator") -> DetailResult:
    """执行"检索候选 → 非交互自动选优 → 四版本聚合"的异步查询主流程。

    用无代理 ``httpx.AsyncClient`` 复用连接；无候选时抛 ``CliError``。
    """
    import httpx

    async with httpx.AsyncClient() as client:
        search_result = await aggregator.search_candidates(title, client)
        candidate, _auto = select_candidate(search_result.candidates)
        if candidate is None:
            raise CliError("未找到匹配作品。", exit_code=EXIT_OK)
        return await aggregator.aggregate_editions(candidate, client)


def run(
    title: str,
    fmt: str = FORMAT_TABLE,
    aggregator: "Aggregator | None" = None,
) -> str:
    """查询模式主逻辑：校验格式 → 执行查询 → 渲染输出（不直接退出进程，便于测试）。

    Args:
        title: 书名（非空）。
        fmt: 输出格式（``json`` / ``table``），会先经 ``validate_format`` 校验。
        aggregator: 可注入的 Aggregator（测试用 fake）；缺省时构造默认真实 Aggregator。

    Returns:
        渲染后的输出字符串。

    Raises:
        CliError: 非法格式（R12.5）或无候选。
    """
    validate_format(fmt)
    agg = aggregator if aggregator is not None else build_default_aggregator()
    result = asyncio.run(_run_query_async(title, agg))
    return render_result(result, fmt)


# ------------------------------------------------------------------------- #
# 启动模式                                                                   #
# ------------------------------------------------------------------------- #
def serve(port: int = config.DEFAULT_PORT, host: str = "127.0.0.1") -> None:
    """启动本地 Web 服务（uvicorn 承载 ``app.main:app``）。

    端口被占用（``OSError`` / ``errno EADDRINUSE``）→ 抛 ``CliError``（非零退出，R9.4）。
    ``app.main`` 在此**延迟 import**，避免 CLI 导入期对 FastAPI 应用产生耦合。

    Args:
        port: 监听端口，默认 ``config.DEFAULT_PORT``（R9.3）。
        host: 监听地址，默认本地回环。

    Raises:
        CliError: 端口被占用时。
    """
    import uvicorn

    # 延迟 import 应用，避免导入期耦合。
    from app.main import app as fastapi_app

    try:
        uvicorn.run(fastapi_app, host=host, port=port)
    except OSError as exc:
        # 端口占用：不同平台 errno 可能为 EADDRINUSE 或 WSAEADDRINUSE(10048)。
        winsock_eaddrinuse = 10048
        if exc.errno in (errno.EADDRINUSE, winsock_eaddrinuse):
            raise CliError(
                f"端口 {port} 已被占用，无法启动服务。请更换 --port 后重试。",
                exit_code=EXIT_ERROR,
            ) from exc
        # 其他 OSError 一并转为 CLI 错误提示（非零退出）。
        raise CliError(
            f"启动服务失败：{exc}",
            exit_code=EXIT_ERROR,
        ) from exc


# ------------------------------------------------------------------------- #
# argparse 与入口                                                            #
# ------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    """构造 argparse 解析器。

    - 位置参数 ``title``：书名，可选（缺失且非 ``--serve`` 时由 ``main`` 报用法错误）。
    - ``--format``：输出格式，默认 ``table``。非法值不在此处用 argparse ``choices`` 拦截，
      而是交由 ``validate_format`` 产生"支持的取值：json, table"提示（R12.5）。
    - ``--serve`` / ``--port``：启动模式与端口。
    """
    parser = argparse.ArgumentParser(
        prog="multi-edition-book-lookup",
        description="跨源查询书籍台版/港版/日版/漫画四版本对照信息。",
    )
    parser.add_argument(
        "title",
        nargs="?",
        default=None,
        help="要查询的书名。查询模式下必填。",
    )
    parser.add_argument(
        "--format",
        "-f",
        dest="format",
        default=FORMAT_TABLE,
        help="输出格式：json 或 table（默认 table）。",
    )
    parser.add_argument(
        "--serve",
        action="store_true",
        help="启动本地 Web 服务而非执行一次性查询。",
    )
    parser.add_argument(
        "--port",
        "-p",
        type=int,
        default=config.DEFAULT_PORT,
        help=f"Web 服务监听端口（默认 {config.DEFAULT_PORT}）。",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    """CLI 入口。解析参数并分派到查询 / 启动模式，统一处理 ``CliError``。

    Args:
        argv: 参数列表（不含程序名）；缺省时用 ``sys.argv[1:]``，便于测试注入。

    Returns:
        进程退出码（``0`` 成功；``2`` 用法错误；``1`` 一般性错误）。
    """
    parser = build_parser()
    args = parser.parse_args(argv)

    # 启动模式。
    if args.serve:
        try:
            serve(port=args.port)
        except CliError as exc:
            print(exc.message, file=sys.stderr)
            return exc.exit_code
        return EXIT_OK

    # 查询模式：必须提供书名（R1.4）。
    if args.title is None or args.title.strip() == "":
        parser.print_usage(sys.stderr)
        print("错误：请提供要查询的书名。", file=sys.stderr)
        return EXIT_USAGE

    try:
        output = run(args.title, fmt=args.format)
    except CliError as exc:
        # 无候选属正常结束（exit_code=0）：打到 stdout；其余错误打 stderr。
        if exc.exit_code == EXIT_OK:
            print(exc.message)
        else:
            print(exc.message, file=sys.stderr)
        return exc.exit_code

    print(output)
    return EXIT_OK


if __name__ == "__main__":  # pragma: no cover —— 由 python -m app.cli 调用。
    sys.exit(main())
