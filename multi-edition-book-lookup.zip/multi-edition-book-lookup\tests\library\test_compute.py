"""library 计算字段纯函数 compute 的单元测试与 hypothesis 属性测试。

覆盖设计文档 Correctness Properties 中的 Property 1~5：
- Property 1 利润恒等
- Property 2 利润符号
- Property 3 缺价留空
- Property 4 零买入率留空
- Property 5 利润率一致性
"""

from __future__ import annotations

import math

import pytest
from hypothesis import assume, given, settings
from hypothesis import strategies as st

from app.modules.library.compute import compute_profit, compute_profit_rate

# 有效价格生成器：排除 nan/inf，限定合理范围避免浮点误差放大。
_PRICES = st.floats(allow_nan=False, allow_infinity=False, min_value=-1e6, max_value=1e6)


# ==================== 单元测试 ====================

def test_positive_profit():
    """正利润：买入 100、卖出 150 → 利润 50、利润率 50%。"""
    assert compute_profit(100, 150) == 50
    assert compute_profit_rate(100, 150) == pytest.approx(50.0)


def test_negative_profit():
    """负利润：买入 200、卖出 150 → 利润 -50、利润率 -25%。"""
    assert compute_profit(200, 150) == -50
    assert compute_profit_rate(200, 150) == pytest.approx(-25.0)


def test_missing_sale():
    """缺卖出价：sale=None → 利润与利润率均为 None。"""
    assert compute_profit(100, None) is None
    assert compute_profit_rate(100, None) is None


def test_missing_purchase():
    """缺买入价：purchase=None → 利润与利润率均为 None。"""
    assert compute_profit(None, 150) is None
    assert compute_profit_rate(None, 150) is None


def test_zero_purchase():
    """零买入价：买入 0、卖出 100 → 利润仍算(100)，利润率留空(不除零)。"""
    assert compute_profit(0, 100) == 100
    assert compute_profit_rate(0, 100) is None


def test_break_even():
    """不赚不赔：买入 100、卖出 100 → 利润 0.0（非 None，因两价都有效）、利润率 0.0。"""
    assert compute_profit(100, 100) == 0.0
    assert compute_profit_rate(100, 100) == pytest.approx(0.0)


# ==================== 属性测试 ====================

# Feature: library, Property 1: 利润恒等——任意有效价格，compute_profit == sale - purchase
@settings(max_examples=100)
@given(purchase=_PRICES, sale=_PRICES)
def test_property_profit_identity(purchase: float, sale: float):
    assert compute_profit(purchase, sale) == pytest.approx(sale - purchase)


# Feature: library, Property 2: 利润符号——sale>=purchase ⇒ profit>=0；sale<purchase ⇒ profit<0
@settings(max_examples=100)
@given(purchase=_PRICES, sale=_PRICES)
def test_property_profit_sign(purchase: float, sale: float):
    profit = compute_profit(purchase, sale)
    assert profit is not None
    if sale >= purchase:
        assert profit >= 0
    else:
        assert profit < 0


# Feature: library, Property 3: 缺价留空——purchase 或 sale 为 None ⇒ profit 与 rate 均为 None
@settings(max_examples=100)
@given(value=_PRICES)
def test_property_missing_price_is_none(value: float):
    assert compute_profit(None, value) is None
    assert compute_profit(value, None) is None
    assert compute_profit(None, None) is None
    assert compute_profit_rate(None, value) is None
    assert compute_profit_rate(value, None) is None
    assert compute_profit_rate(None, None) is None


# Feature: library, Property 4: 零买入率留空——purchase==0 或 None ⇒ rate is None（不除零）
@settings(max_examples=100)
@given(sale=st.one_of(_PRICES, st.none()))
def test_property_zero_purchase_rate_is_none(sale: float | None):
    assert compute_profit_rate(0, sale) is None
    assert compute_profit_rate(None, sale) is None


# Feature: library, Property 5: 利润率一致性——purchase 非 0 且有效、sale 有效 ⇒ rate == profit/purchase*100
@settings(max_examples=100)
@given(purchase=_PRICES, sale=_PRICES)
def test_property_profit_rate_consistency(purchase: float, sale: float):
    assume(purchase != 0)
    rate = compute_profit_rate(purchase, sale)
    profit = compute_profit(purchase, sale)
    assert rate is not None
    assert profit is not None
    expected = profit / purchase * 100.0
    assert math.isclose(rate, expected, rel_tol=1e-9, abs_tol=1e-9)
