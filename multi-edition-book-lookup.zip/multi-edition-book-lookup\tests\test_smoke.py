"""启动/健康检查冒烟测试与真实数据源连通性冒烟（任务 16.1、16.3）。

本模块覆盖两类冒烟：

- **任务 16.1 启动/健康检查冒烟**（离线、恒运行）：用 ``TestClient(create_app())``
  验证服务可装配启动，``GET /`` 返回 HTML(200)、``GET /api/health`` 返回
  ``{"status":"ok"}``。不打真实网络，不依赖任何 Adapter 结果。
  _Requirements: 9.1, 9.2_

- **任务 16.3 真实数据源连通性冒烟**（默认跳过）：以 ``@pytest.mark.network`` 标记，
  对真实 Adapter 发一次真实查询，验证外部数据源可连通。默认通过两道闸门跳过：
    1. ``pyproject.toml`` 的 ``addopts = '-m "not network"'`` 在收集阶段 deselect。
    2. 测试内 ``skipif``（``RUN_NETWORK_TESTS`` 未设置时跳过），即便有人用
       ``-m network`` 强制选中，缺少环境变量时也会 skip 而非因外网不可达而失败。
  _Requirements: 5.1, 5.2, 5.6_
"""

from __future__ import annotations

import os

import pytest
from fastapi.testclient import TestClient

from app.shared import config
from app.main import create_app


# =============================================================================
# 任务 16.1：启动 / 健康检查冒烟（离线、恒运行）
# =============================================================================

def test_root_returns_html():
    """GET / 返回 HTML(200)。

    兼容两种情形：``web/index.html`` 已就绪时返回真实页面，未就绪时返回占位 HTML。
    只断言状态码 200 且响应体是 HTML（content-type 含 text/html，且含 ``<html``）。
    """
    with TestClient(create_app()) as client:
        resp = client.get("/")
        assert resp.status_code == 200
        assert "text/html" in resp.headers.get("content-type", "").lower()
        assert "<html" in resp.text.lower()


def test_health_returns_ok():
    """GET /api/health 返回 {"status":"ok"}。"""
    with TestClient(create_app()) as client:
        resp = client.get("/api/health")
        assert resp.status_code == 200
        assert resp.json() == {"status": "ok"}


# =============================================================================
# 任务 16.3：真实数据源连通性冒烟（默认跳过）
# =============================================================================
#
# 双闸门确保离线默认不失败：
#   - 收集阶段：addopts = '-m "not network"' 直接 deselect（不进入执行）。
#   - 执行阶段：skipif 在未设置 RUN_NETWORK_TESTS 时 skip（-m network 强制选中时兜底）。

_RUN_NETWORK = os.environ.get("RUN_NETWORK_TESTS", "").strip().lower() in {
    "1",
    "true",
    "yes",
    "on",
}


@pytest.mark.network
@pytest.mark.skipif(
    not _RUN_NETWORK,
    reason="真实数据源连通性冒烟默认跳过；设置环境变量 RUN_NETWORK_TESTS=1 才运行。",
)
async def test_real_adapter_connectivity():
    """对真实 Adapter 发一次真实查询，验证外部数据源可连通（默认跳过）。

    仅在显式 ``RUN_NETWORK_TESTS=1`` 且用 ``-m network`` 选中时运行。
    用无代理 client 对 openBD 真实 Adapter 发一次检索，只断言调用不抛未捕获异常、
    返回类型正确（连不上时 Adapter 会吞异常返回 []，属可接受的 best-effort 行为）。
    """
    import httpx

    from app.modules.book_lookup.adapters.openbd import OpenBdAdapter

    adapter = OpenBdAdapter()
    async with httpx.AsyncClient(
        trust_env=False, timeout=httpx.Timeout(config.DEFAULT_TIMEOUT_S)
    ) as client:
        candidates = await adapter.search("葬送のフリーレン", client)
        # Adapter 契约：查不到/连不上返回 []（吞异常），连通且有结果返回候选列表。
        assert isinstance(candidates, list)
