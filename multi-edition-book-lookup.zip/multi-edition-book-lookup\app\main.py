"""FastAPI 平台装配入口。

本模块是整个平台的组装层，不再内联任何路由。职责收敛为「装配」：

- `create_app()`：创建 FastAPI 实例 → 安装全局异常兜底 → 注册各模块 router
  （book_lookup 必装；library 优雅占位，存在才装）→ 触发 library 建表（优雅占位）。
- `lifespan`：管理无代理 `httpx.AsyncClient` 的生命周期，并把 registry / aggregator /
  client 挂到 `app.state`，供各模块路由从 `request.app.state` 取用。
- `build_registry()`：装配注册全部 5 个真实 Adapter 的默认注册表（供 lifespan 使用）。

原查书路由已搬至 `app.modules.book_lookup.router`；无代理 client 工厂已搬至
`app.shared.http_client`；全局 500 兜底已搬至 `app.shared.errors`。
"""

from __future__ import annotations

from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI

from app.shared.errors import install_exception_handlers
from app.shared.http_client import build_async_client
from app.modules.book_lookup import router as book_lookup_router
from app.modules.book_lookup.adapters.books_com_tw import BooksComTwAdapter
from app.modules.book_lookup.adapters.google_books import GoogleBooksAdapter
from app.modules.book_lookup.adapters.hk_generic import HkGenericAdapter
from app.modules.book_lookup.adapters.ndl import NdlAdapter
from app.modules.book_lookup.adapters.openbd import OpenBdAdapter
from app.modules.book_lookup.aggregator import Aggregator
from app.modules.book_lookup.registry import AdapterRegistry


def build_registry() -> AdapterRegistry:
    """装配并返回注册了全部 5 个真实 Adapter 的默认注册表。

    注册顺序不影响 Edition→Adapter 解析（解析按 `config.EDITION_ADAPTER_MAP`
    声明的顺序），但影响 search 阶段的并发调度顺序（仅影响候选去重时的先后）。
    """
    registry = AdapterRegistry()
    registry.register(OpenBdAdapter())
    registry.register(GoogleBooksAdapter())
    registry.register(NdlAdapter())
    registry.register(BooksComTwAdapter())
    registry.register(HkGenericAdapter())
    return registry


@asynccontextmanager
async def lifespan(app: FastAPI):
    """FastAPI lifespan：启动时创建无代理 client，关闭时释放。

    将 registry / aggregator / client 挂到 ``app.state`` 上，供路由处理函数取用；
    便于测试通过覆盖 ``app.state`` 注入 fake 依赖。
    """
    registry: AdapterRegistry = getattr(app.state, "registry", None) or build_registry()
    aggregator: Aggregator = getattr(app.state, "aggregator", None) or Aggregator(
        registry
    )
    client = build_async_client()

    app.state.registry = registry
    app.state.aggregator = aggregator
    app.state.client = client
    try:
        yield
    finally:
        await client.aclose()


def create_app() -> FastAPI:
    """工厂函数：组装 FastAPI 平台（异常兜底 + 各模块 router + library 建表 + lifespan）。"""
    app = FastAPI(title="multi-edition-book-lookup", lifespan=lifespan)

    # --- 全局异常兜底：未捕获异常 → 500 INTERNAL，不泄露堆栈 ---
    install_exception_handlers(app)

    # --- 查书模块路由（必装）---
    book_lookup_router.register(app)

    # --- 图书管理模块路由（优雅占位：library.router 可能尚未建，存在才装）---
    try:
        from app.modules.library import router as library_router

        library_router.register(app)
    except ImportError:
        pass

    # --- 图书管理模块建表（优雅占位：library.db 可能尚未建）---
    try:
        from app.modules.library import db as library_db

        library_db.init_db()
    except ImportError:
        pass

    return app


# 模块级 app 实例，供 ``uvicorn app.main:app`` 直接启动。
app = create_app()
