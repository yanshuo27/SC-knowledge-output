# multi-edition-book-lookup（书籍工具平台）

本地 Web 应用，包含两个并列功能模块：

- **查书（book_lookup）**：在浏览器输入书名，后端跨多个公开数据源查询该作品的四类版本
  （台版繁中、港版繁中、日版原版、漫画系列信息），合并去重后以四版本对照表格展示。
- **图书管理 / 书架（library）**：管理你自己的藏书清单，记录藏书状态与买卖交易，
  自动核算收藏投资的利润与利润率，并支持导出与从查书结果一键收藏。

两个模块跑在同一个本地 Web 应用上，通过页面顶部的「查书 / 书架」页签切换。

## 技术栈

- 后端：Python 3.11 + FastAPI + uvicorn，`httpx.AsyncClient` 异步抓取，`asyncio` 并发编排，
  `beautifulsoup4` + `lxml` 解析页面型数据源；图书管理持久化用标准库 `sqlite3`（零额外依赖）。
- 前端：原生 HTML/CSS/JS 单页，由 FastAPI 静态托管，零构建。

## 环境要求

- Python >= 3.11（本机通过 `py -3.11` 调用）。

## 安装

```bash
# 使用清华镜像安装（含开发依赖）
py -3.11 -m pip install -e ".[dev]" -i https://pypi.tuna.tsinghua.edu.cn/simple
```

## 启动

```bash
py -3.11 -m uvicorn app.main:app
# 或双击 run.bat 一键启动（Windows）
```

启动后浏览器访问 `http://127.0.0.1:8000/`。

## 功能说明

### 查书

在「查书」页签输入书名 → 检索候选 → 选中某个作品 → 展示台版/港版/日版/漫画四版本对照
（书名、作者、出版社、开本/判型、定价、连载状态、总卷数、最新册数、ISBN、出版日期）。
查不到的版本以占位说明表示，查不到的字段以「N/A」标注。

### 图书管理 / 书架

在「书架」页签管理你的藏书。每条藏书条目包含三类字段：

- **书目字段**：书名、作者、出版社、种类（漫画/小说/画集…自由填写）、版本（台版/港版/日版/漫画）、
  是否完结、全套总卷数、最新册数。
- **交易字段**：藏书状态（想要 / 已购 / 已售）、拥有册数、买入价格、卖出价格、购入渠道。
- **计算字段**（系统自动算，不用填）：
  - 利润 = 卖出价格 − 买入价格
  - 利润率 = 利润 ÷ 买入价格 × 100%
  - 未卖出或无买入价时留空（不显示为 0）。

支持的操作：

- **新增 / 编辑 / 删除**藏书条目。
- **筛选**（按藏书状态 / 种类 / 版本）、**书名搜索**（不区分大小写）、**排序**（按更新时间 / 买入价 / 卖出价 / 书名 / 创建时间）。
- **导出**：CSV（带 BOM，Excel 打开中文不乱码）或 JSON，导出范围与当前筛选一致。
- **一键收藏**：在查书结果页，点某个版本的「收藏到书架」，把该版本书目字段预填进一条新藏书
  （交易字段可稍后在书架里补填）。

### 数据存储

图书管理数据保存在本地 SQLite 文件 `data/library.db`（首次运行自动创建）。
数据库路径可通过环境变量 `LIBRARY_DB_PATH` 覆盖。该文件不随分发包打包（属于用户个人数据）。

## 目录结构

```
multi-edition-book-lookup/
├── pyproject.toml               # 依赖与项目元数据
├── README.md
├── run.bat                      # Windows 一键启动脚本
├── app/                         # 后端应用包（多模块平台）
│   ├── main.py                  # 平台装配入口（create_app 组装各模块 + lifespan）
│   ├── shared/                  # 共享基础设施
│   │   ├── config.py            # 常量、Edition/藏书状态、DB 路径
│   │   ├── http_client.py       # 无代理 httpx.AsyncClient 工厂
│   │   └── errors.py            # 全局异常兜底 + 统一错误响应
│   └── modules/
│       ├── book_lookup/         # 查书模块（router/aggregator/merger/registry/adapters…）
│       └── library/             # 图书管理模块（router/service/repository/db/compute/export/models）
├── web/                         # 前端静态资源（查书 + 书架双页签）
└── tests/                       # 测试
    ├── library/                 # 图书管理模块测试
    └── adapters/fixtures/       # 录制的样例响应夹具
```

## 测试

```bash
py -3.11 -m pytest                    # 全部测试
py -3.11 -m pytest -m "not network"   # 排除真实数据源连通性冒烟（本机无外网时用）
```
