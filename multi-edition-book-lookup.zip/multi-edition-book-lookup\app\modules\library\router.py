"""library 图书管理模块的 HTTP 路由层（router）。

本模块通过 `register(app)` 约定，把图书管理相关端点挂载到共享的 FastAPI 实例上。
路由风格与 book_lookup.router 一致：手动读取请求体（``await request.json()``），
用 pydantic 的 model_validate 校验，从而能自行捕获 ValidationError 并转换为
统一的 400 校验错误（若交由 FastAPI 自动注入模型，则会返回 422，与本平台约定的
400 VALIDATION_ERROR 不一致）。

端点清单：

- ``GET    /api/library/items``              列表（支持筛选/搜索/排序 query 参数）。
- ``POST   /api/library/items``              新增（手动录入与一键收藏共用同一入口）。
- ``GET    /api/library/items/{item_id}``    详情。
- ``PUT    /api/library/items/{item_id}``    全量更新。
- ``DELETE /api/library/items/{item_id}``    删除。
- ``GET    /api/library/export?format=csv|json``  导出（沿用列表筛选参数）。

错误处理约定（复用 shared.errors.error_response）：

- pydantic ``ValidationError`` → 400 ``VALIDATION_ERROR``（附首条可读校验信息）。
- 领域异常 ``ItemNotFoundError`` → 404 ``NOT_FOUND``。

router 调用 service 时不传 db_path，走 service/repository 的默认库
（config.LIBRARY_DB_PATH），保证与平台其余部分同源。
"""

from __future__ import annotations

from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
from pydantic import ValidationError

from app.modules.library import export, service
from app.modules.library.models import LibraryItemCreate, LibraryItemUpdate
from app.modules.library.service import ItemNotFoundError
from app.shared.errors import error_response


def _validation_error_response(exc: ValidationError) -> JSONResponse:
    """把 pydantic ValidationError 转为统一的 400 VALIDATION_ERROR 响应。

    取首条错误组装可读信息（字段定位 + 错误说明），避免把冗长的原始
    error 列表直接抛给前端。
    """
    errors = exc.errors()
    if errors:
        first = errors[0]
        loc = ".".join(str(x) for x in first.get("loc", ())) or "(根)"
        msg = first.get("msg", "校验失败")
        message = f"校验失败：{loc} {msg}"
    else:
        message = "校验失败"
    return error_response("VALIDATION_ERROR", message, 400)


def _build_filters(params) -> dict:
    """从 query 参数构造 service.list_items 所需的 filters dict。

    仅把非 None 的筛选/搜索/排序参数纳入，键名与 repository.list 约定一致。
    """
    keys = (
        "ownership_status",
        "category",
        "edition",
        "title_search",
        "sort_by",
        "sort_dir",
    )
    filters: dict = {}
    for key in keys:
        value = params.get(key)
        if value is not None:
            filters[key] = value
    return filters


def register(app: FastAPI) -> None:
    """把图书管理模块的路由注册到传入的 FastAPI 实例上。

    所有处理函数调用 service 时不传 db_path，走默认库
    （config.LIBRARY_DB_PATH），与平台其余部分同源。
    """

    # --- 列表：支持筛选/搜索/排序 ---
    @app.get("/api/library/items")
    async def list_items(request: Request) -> JSONResponse:
        filters = _build_filters(request.query_params)
        items = service.list_items(filters)
        return JSONResponse(
            content=[o.model_dump(mode="json") for o in items]
        )

    # --- 新增条目 ---
    @app.post("/api/library/items")
    async def create_item(request: Request) -> JSONResponse:
        payload = await request.json()
        try:
            item = LibraryItemCreate.model_validate(payload)
        except ValidationError as exc:
            return _validation_error_response(exc)
        out = service.create_item(item)
        return JSONResponse(status_code=201, content=out.model_dump(mode="json"))

    # --- 详情 ---
    @app.get("/api/library/items/{item_id}")
    async def get_item(item_id: int) -> JSONResponse:
        try:
            out = service.get_item(item_id)
        except ItemNotFoundError:
            return error_response("NOT_FOUND", "条目不存在", 404)
        return JSONResponse(content=out.model_dump(mode="json"))

    # --- 全量更新 ---
    @app.put("/api/library/items/{item_id}")
    async def update_item(item_id: int, request: Request) -> JSONResponse:
        payload = await request.json()
        try:
            item = LibraryItemUpdate.model_validate(payload)
        except ValidationError as exc:
            return _validation_error_response(exc)
        try:
            out = service.update_item(item_id, item)
        except ItemNotFoundError:
            return error_response("NOT_FOUND", "条目不存在", 404)
        return JSONResponse(content=out.model_dump(mode="json"))

    # --- 删除 ---
    @app.delete("/api/library/items/{item_id}")
    async def delete_item(item_id: int) -> JSONResponse:
        try:
            service.delete_item(item_id)
        except ItemNotFoundError:
            return error_response("NOT_FOUND", "条目不存在", 404)
        return JSONResponse(content={"deleted": True})

    # --- 导出（CSV / JSON），沿用列表筛选参数 ---
    @app.get("/api/library/export")
    async def export_items(request: Request) -> Response:
        params = request.query_params
        fmt = params.get("format") or "csv"
        filters = _build_filters(params)
        items = service.list_items(filters)

        if fmt == "json":
            return Response(
                content=export.to_json(items),
                media_type="application/json",
                headers={
                    "Content-Disposition": "attachment; filename=library.json"
                },
            )
        # 默认与显式 csv 都走 CSV 分支
        return Response(
            content=export.to_csv(items),
            media_type="text/csv; charset=utf-8",
            headers={"Content-Disposition": "attachment; filename=library.csv"},
        )
