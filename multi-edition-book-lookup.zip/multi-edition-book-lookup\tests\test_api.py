"""HTTP API 层示例/集成测试（任务 12.5）。

用 ``fastapi.testclient.TestClient`` + ``FakeAdapter``（来自 tests.conftest）走通
search→detail 两阶段，全程不打真实网络。覆盖：

- 无候选（``candidates: []``）。
- 单候选直通（``candidates`` 含 1 项）。
- warnings 透传（search / detail 两阶段的 warning 均出现在响应里）。
- ``GET /api/health`` → ``{"status":"ok"}``。
- 装配的 ``httpx.AsyncClient`` 未设置代理（R5.6）。

_Requirements: 5.6, 8.2, 8.3, 8.4, 10.2, 10.3_
"""

from __future__ import annotations

import httpx
import pytest
from fastapi.testclient import TestClient

from app.shared import config
from app.modules.book_lookup.aggregator import Aggregator
from app.main import build_registry, create_app
from app.shared.http_client import build_async_client
from app.modules.book_lookup.models import Candidate
from app.modules.book_lookup.registry import AdapterRegistry
from tests.conftest import FakeAdapter, make_raw


def _make_client(registry: AdapterRegistry) -> TestClient:
    """构造一个注入了指定 registry/aggregator 的 TestClient。

    通过在 lifespan 启动前预置 ``app.state.registry`` / ``app.state.aggregator``，
    使 lifespan 复用它们（而非装配真实 Adapter），从而全程走 FakeAdapter。
    lifespan 仍会创建真实（无代理）client，但 FakeAdapter 不会用到它。
    """
    app = create_app()
    app.state.registry = registry
    app.state.aggregator = Aggregator(registry, timeout_s=1.0)
    return TestClient(app)


def _single_candidate() -> Candidate:
    return Candidate(
        candidate_id="fake:1",
        title="葬送のフリーレン",
        author="山田鐘人",
        source="fake_jp",
    )


def test_health_ok():
    """GET /api/health 返回 {"status":"ok"}。"""
    registry = AdapterRegistry()
    with _make_client(registry) as client:
        resp = client.get("/api/health")
        assert resp.status_code == 200
        assert resp.json() == {"status": "ok"}


def test_search_empty_title_rejected():
    """空/纯空白书名 → 400 EMPTY_TITLE，且不触发任何 Adapter 检索。"""
    fake = FakeAdapter(name="fake_jp", search_results=[_single_candidate()])
    registry = AdapterRegistry()
    registry.register(fake)
    with _make_client(registry) as client:
        for bad in ["", "   ", "\t\n"]:
            resp = client.post("/api/search", json={"title": bad})
            assert resp.status_code == 400
            body = resp.json()
            assert body["code"] == "EMPTY_TITLE"
            assert body["error"] == "书名不可为空"
        # 校验发生在检索之前：FakeAdapter.search 从未被调用。
        assert fake.search_calls == []


def test_search_no_candidates_returns_empty_list():
    """无任何候选 → 200，candidates 为空列表（前端据此提示"未找到匹配作品"）。"""
    # 所有 adapter 都返回空候选。
    registry = AdapterRegistry()
    registry.register(FakeAdapter(name="fake_jp", search_results=[]))
    with _make_client(registry) as client:
        resp = client.post("/api/search", json={"title": "不存在的书"})
        assert resp.status_code == 200
        body = resp.json()
        assert body["query"] == "不存在的书"
        assert body["candidates"] == []


def test_search_single_candidate_passthrough():
    """单候选 → candidates 含恰 1 项（前端可直接进入 detail）。"""
    cand = _single_candidate()
    registry = AdapterRegistry()
    registry.register(FakeAdapter(name="fake_jp", search_results=[cand]))
    with _make_client(registry) as client:
        resp = client.post("/api/search", json={"title": "葬送のフリーレン"})
        assert resp.status_code == 200
        body = resp.json()
        assert len(body["candidates"]) == 1
        assert body["candidates"][0]["candidate_id"] == "fake:1"
        assert body["candidates"][0]["title"] == "葬送のフリーレン"


def test_search_warnings_passthrough():
    """search 阶段失败源的 warning 透传到响应。"""
    good = FakeAdapter(name="fake_good", search_results=[_single_candidate()])
    bad = FakeAdapter(name="fake_bad", raise_exc=RuntimeError("boom"))
    registry = AdapterRegistry()
    registry.register(good)
    registry.register(bad)
    with _make_client(registry) as client:
        resp = client.post("/api/search", json={"title": "葬送のフリーレン"})
        assert resp.status_code == 200
        body = resp.json()
        # 好源产出候选。
        assert len(body["candidates"]) == 1
        # 坏源产生一条 warning 并透传。
        assert len(body["warnings"]) >= 1
        assert any(w.get("source") == "fake_bad" for w in body["warnings"])


def test_detail_missing_candidate_rejected():
    """detail 缺少 candidate → 400 MISSING_CANDIDATE。"""
    registry = AdapterRegistry()
    with _make_client(registry) as client:
        resp = client.post("/api/detail", json={})
        assert resp.status_code == 400
        body = resp.json()
        assert body["code"] == "MISSING_CANDIDATE"
        assert body["error"] == "缺少候选"


def test_detail_always_four_editions_with_disclaimer():
    """detail 恒返回四版本 + disclaimer；有结果的版本 present=True，其余占位。"""
    # 日版有结果，其余（台/港/漫画）无结果 → 占位。
    jp_adapter = FakeAdapter(
        name=config.SOURCE_OPENBD,
        supported_editions=[config.EDITION_JP],
        fetch_result=make_raw(config.EDITION_JP, config.SOURCE_OPENBD, title="日版书名"),
    )
    registry = build_registry()
    # 用带结果的 fake 覆盖同名 openbd（registry.register 同名覆盖）。
    registry.register(jp_adapter)
    with _make_client(registry) as client:
        resp = client.post(
            "/api/detail", json={"candidate": _single_candidate().model_dump()}
        )
        assert resp.status_code == 200
        body = resp.json()
        # 四版本键恒存在。
        assert set(body["editions"].keys()) == set(config.ALL_EDITIONS)
        # disclaimer 恒存在且为配置文本。
        assert body["disclaimer"] == config.SERIALIZATION_DISCLAIMER
        # 日版 present=True。
        assert body["editions"][config.EDITION_JP]["present"] is True
        # 港版无源 → present=False + 占位。
        assert body["editions"][config.EDITION_HK]["present"] is False
        assert (
            body["editions"][config.EDITION_HK]["placeholder"]
            == config.MISSING_EDITION_PLACEHOLDER
        )


def test_detail_warnings_passthrough():
    """detail 阶段失败源的 warning 透传到响应。"""
    # 日版一个源抛错 → 产生 warning。
    bad_jp = FakeAdapter(
        name=config.SOURCE_OPENBD,
        supported_editions=[config.EDITION_JP],
        raise_exc=RuntimeError("jp boom"),
    )
    registry = build_registry()
    registry.register(bad_jp)
    with _make_client(registry) as client:
        resp = client.post(
            "/api/detail", json={"candidate": _single_candidate().model_dump()}
        )
        assert resp.status_code == 200
        body = resp.json()
        assert any(w.get("source") == config.SOURCE_OPENBD for w in body["warnings"])


def test_end_to_end_search_then_detail():
    """走通 search→detail 两阶段：先检索候选，再用候选取四版本详情。"""
    cand = _single_candidate()
    jp_adapter = FakeAdapter(
        name=config.SOURCE_OPENBD,
        supported_editions=[config.EDITION_JP],
        search_results=[cand],
        fetch_result=make_raw(config.EDITION_JP, config.SOURCE_OPENBD, title="日版书名"),
    )
    registry = build_registry()
    registry.register(jp_adapter)
    with _make_client(registry) as client:
        # 阶段一：search。
        s = client.post("/api/search", json={"title": "葬送のフリーレン"})
        assert s.status_code == 200
        candidates = s.json()["candidates"]
        assert len(candidates) >= 1
        # 阶段二：detail，回传阶段一的候选。
        d = client.post("/api/detail", json={"candidate": candidates[0]})
        assert d.status_code == 200
        editions = d.json()["editions"]
        assert set(editions.keys()) == set(config.ALL_EDITIONS)


def test_build_async_client_has_no_proxy():
    """R5.6：装配的 httpx.AsyncClient 未设置代理（trust_env=False 且无 proxy mounts）。"""
    client = build_async_client()
    try:
        # trust_env=False：不继承环境变量代理。
        assert client.trust_env is False
        # 无任何代理挂载：httpx 在设置 proxy 时会在 _mounts 中登记非默认传输。
        # 未设置代理时，_mounts 为空（或不含 proxy transport）。
        mounts = getattr(client, "_mounts", {})
        for transport in mounts.values():
            # 代理传输会持有 _pool 且带 proxy 信息；此处断言不存在 proxy 属性。
            assert not hasattr(transport, "_proxy_url")
    finally:
        # TestClient 之外单独构造的 client 需手动关闭（同步上下文）。
        import anyio

        anyio.run(client.aclose)
