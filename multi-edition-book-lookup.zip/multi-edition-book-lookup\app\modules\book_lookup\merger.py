"""合并去重层 Merger。

把同一 Edition 的多条单源原始记录（`RawEditionRecord`）合并为单条对外记录
（`EditionRecord`），实现设计文档中由本模块保证的一系列正确性属性：

- Property 8  (R7.1)：同一 Edition 的多源记录（数量≥1）恒合并为恰好一条。
- Property 2  (R2.3/R13.1)：全部源均无任何有效普通字段 → present=False + 统一整版占位。
- Property 14 (R13.3)：只要有任一非缺失普通字段 → present=True，缺失字段用 Unknown_Marker，不触发整版占位。
- Property 3  (R3.3/R4.3)：present=True 时所有缺失普通字段恒为 UNKNOWN_MARKER，绝不为 None/缺键/异常。
- Property 9  (R7.2)：字段值恒取自某源提供的非缺失值，不凭空造值。
- Property 10 (R7.3)：同一字段多源给出不同非缺失值 → 取优先级最高（SOURCE_PRIORITY 数值最小）源的值，并记入 field_conflicts。
- Property 11 (R7.4)：sources 恒为所有贡献过非缺失数据的源集合，去重、无遗漏无多余。
- Property 5  (R3.4/R4.1)：serialization_status 恒落在 完结/连载中/未知；全缺失时为 未知。
- Property 6  (R4.2)：serialization_status ∈ {连载中, 未知} 时 total_volumes 恒为 UNKNOWN_MARKER。
- Property 4  (R3.2)：price 要么完整 Price（amount+currency），要么 UNKNOWN_MARKER，无中间态。

所有占位/优先级常量均从 `app.config` 引用，不硬编码。
"""

from __future__ import annotations

from app.shared import config
from app.modules.book_lookup.models import (
    EditionRecord,
    Price,
    RawEditionRecord,
    SerializationStatus,
)

# 参与"整版是否缺失"判定的普通字段名（不含 serialization_status，
# 因为状态默认恒有"未知"值，不能据此判定整版存在）。
# 对应设计中「书名/作者/出版社/判型/定价/最新册数/ISBN/出版日期/总卷数」。
_ORDINARY_FIELDS = (
    "title",
    "author",
    "publisher",
    "format",
    "price",
    "total_volumes",
    "latest_volume",
    "isbn",
    "publish_date",
)

# 兜底优先级：priority 中未登记的 source 视为最低优先（数值极大），避免 KeyError。
_FALLBACK_PRIORITY = 10**9


def _priority_of(source: str, priority: dict[str, int]) -> int:
    """取某数据源的优先级数值；未登记则给最低优先兜底（不抛 KeyError）。"""
    return priority.get(source, _FALLBACK_PRIORITY)


class _FieldResolution:
    """单个字段跨多源合并的结果载体。

    - value：选定的非缺失值（若全缺失则为 None）
    - has_value：是否存在任一非缺失取值
    - conflict：是否存在多源给出互不相同的非缺失值（冲突）
    - contributors：贡献过该字段非缺失值的数据源名列表
    """

    __slots__ = ("value", "has_value", "conflict", "contributors")

    def __init__(self) -> None:
        self.value = None
        self.has_value = False
        self.conflict = False
        self.contributors: list[str] = []


def _resolve_field(
    raws: list[RawEditionRecord],
    attr: str,
    priority: dict[str, int],
) -> _FieldResolution:
    """通用字段合并 helper：收集各源对某字段的非缺失值 → 按优先级选值 → 判断冲突。

    普通字段与状态字段复用本函数（Property 9/10/11 的公共落点）。

    - 非缺失优先：仅纳入 value 非 None 的源（Property 9）。
    - 冲突选值：多源值互不相同（按相等性判断）时，取 priority 最小者的值，
      并标记 conflict=True（Property 10）。
    - 贡献者集合：所有提供过非缺失值的源都计入 contributors（供 Property 11 汇总）。
    """
    res = _FieldResolution()

    # 收集 (源名, 值)，仅保留非缺失取值。
    provided: list[tuple[str, object]] = []
    for raw in raws:
        v = getattr(raw, attr)
        if v is not None:
            provided.append((raw.source, v))
            res.contributors.append(raw.source)

    if not provided:
        # 全部源均缺失该字段。
        return res

    res.has_value = True

    # 选值：优先级数值最小的源胜出；同优先级时保持输入顺序（稳定选择首个）。
    best_source, best_value = min(
        provided, key=lambda sv: _priority_of(sv[0], priority)
    )
    res.value = best_value

    # 冲突判定：存在任一非缺失值与选定值不相等，即视为冲突（Property 10）。
    for _src, val in provided:
        if val != best_value:
            res.conflict = True
            break

    return res


def _normalize_status(value: object | None) -> SerializationStatus:
    """把任意状态取值规整到 SerializationStatus 三值域（Property 5）。

    - None / 非法值 → 未知（UNKNOWN）。
    - 已是 SerializationStatus → 原样返回。
    - 是字符串（如 "完结"）→ 尝试映射到枚举，失败则未知。
    """
    if isinstance(value, SerializationStatus):
        return value
    if isinstance(value, str):
        try:
            return SerializationStatus(value)
        except ValueError:
            return SerializationStatus.UNKNOWN
    return SerializationStatus.UNKNOWN


def _num_to_str_or_unknown(value: object | None) -> str:
    """把数字型字段（total_volumes / latest_volume）转为数字字符串；缺失填 UNKNOWN_MARKER。

    EditionRecord 中这两个字段是 str|None：有值时为数字字符串，缺失时为 "N/A"（规范第11条）。
    """
    if value is None:
        return config.UNKNOWN_MARKER
    return str(value)


class Merger:
    """合并去重器。无状态，可安全复用单例。"""

    def merge(
        self,
        edition: str,
        raws: list[RawEditionRecord],
        priority: dict[str, int] | None = None,
    ) -> EditionRecord:
        """把同一 Edition 的多源原始记录合并为单条 EditionRecord。

        参数：
            edition：版本名（台版/港版/日版/漫画）。
            raws：该 Edition 的多源原始记录（可能为空列表）。
            priority：数据源优先级映射，数字越小越优先；默认用 config.SOURCE_PRIORITY。

        返回：恰好一条 EditionRecord（Property 8）。
        """
        if priority is None:
            priority = config.SOURCE_PRIORITY

        # ---- 逐普通字段做跨源合并（非缺失优先 + 冲突选值 + 贡献者收集） ----
        resolutions: dict[str, _FieldResolution] = {
            attr: _resolve_field(raws, attr, priority) for attr in _ORDINARY_FIELDS
        }

        # ---- 状态字段单独合并：先按优先级选值，再规整到三值域 ----
        status_res = _resolve_field(raws, "serialization_status", priority)
        final_status = _normalize_status(status_res.value)  # 全缺失 → 未知（Property 5）

        # ---- 整版缺失判定（Property 2 / Property 14） ----
        # 标准：没有任何一个源提供任何一个非缺失的普通字段，则视为整版缺失。
        # 注意：serialization_status 不参与此判定（它默认恒有"未知"），
        # 否则会导致"仅有默认状态"被误判为存在。
        any_ordinary_present = any(r.has_value for r in resolutions.values())

        if not any_ordinary_present:
            # 全空 → 返回整版占位记录（present=False），不填充其余字段（R2.3/R13.1）。
            return EditionRecord(
                edition=edition,
                present=False,
                placeholder=config.MISSING_EDITION_PLACEHOLDER,
            )

        # ---- present=True：逐字段落地，缺失填 UNKNOWN_MARKER（Property 3/14） ----

        def _text(attr: str) -> str:
            """普通文本字段落地：有值取选定值，缺失填 UNKNOWN_MARKER。"""
            r = resolutions[attr]
            return r.value if r.has_value else config.UNKNOWN_MARKER

        # 定价字段完整性（Property 4）：
        # RawEditionRecord.price 本身是 Price|None，天然保证 amount+currency 成对；
        # 合并选出的 value 要么是完整 Price，要么全缺失 → 填 UNKNOWN_MARKER。无中间态。
        price_res = resolutions["price"]
        if price_res.has_value and isinstance(price_res.value, Price):
            price_out: Price | str = price_res.value
        else:
            price_out = config.UNKNOWN_MARKER

        # 卷数字段：状态联动（Property 6）。
        # 若最终状态 ∈ {连载中, 未知}，total_volumes 恒为 UNKNOWN_MARKER，
        # 无论源是否给了具体数字；仅"完结"时才可能输出具体总卷数。
        if final_status is SerializationStatus.COMPLETED:
            total_res = resolutions["total_volumes"]
            total_volumes_out = _num_to_str_or_unknown(
                total_res.value if total_res.has_value else None
            )
        else:
            total_volumes_out = config.UNKNOWN_MARKER

        latest_res = resolutions["latest_volume"]
        latest_volume_out = _num_to_str_or_unknown(
            latest_res.value if latest_res.has_value else None
        )

        # ---- 来源集合（Property 11）：所有贡献过非缺失数据的源，去重、保序 ----
        sources: list[str] = []
        seen: set[str] = set()
        # 纳入普通字段贡献者 + 状态字段贡献者。
        all_res = list(resolutions.values()) + [status_res]
        for r in all_res:
            for src in r.contributors:
                if src not in seen:
                    seen.add(src)
                    sources.append(src)

        # ---- 冲突字段集合（Property 10）：记录出现多源不同非缺失值的字段名 ----
        field_conflicts: list[str] = [
            attr for attr in _ORDINARY_FIELDS if resolutions[attr].conflict
        ]
        # 状态字段冲突也计入（字段名用模型属性名 serialization_status）。
        if status_res.conflict:
            field_conflicts.append("serialization_status")

        return EditionRecord(
            edition=edition,
            present=True,
            placeholder=None,
            title=_text("title"),
            author=_text("author"),
            publisher=_text("publisher"),
            format=_text("format"),
            price=price_out,
            serialization_status=final_status.value,  # 恒为三值域字符串（Property 5）
            total_volumes=total_volumes_out,
            latest_volume=latest_volume_out,
            isbn=_text("isbn"),
            publish_date=_text("publish_date"),
            sources=sources,
            field_conflicts=field_conflicts,
        )
