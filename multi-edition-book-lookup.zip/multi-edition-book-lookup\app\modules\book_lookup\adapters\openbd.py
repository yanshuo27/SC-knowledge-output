"""OpenBdAdapter：openBD API（日版）数据源适配器。

openBD（https://openbd.jp/）是日本图书出版信息的开放数据库，提供按 ISBN 取书目
信息的 API：

    GET https://api.openbd.jp/v1/get?isbn=<isbn>

返回 JSON 数组，每个元素形如 ``{"onix": {...}, "summary": {...}, "hanmoto": {...}}``，
当某个 ISBN 查不到时，数组对应位置为 ``null``。

字段现实性（参见 design.md 的字段对照表）：书名/作者/出版社/ISBN/定价(JPY)/出版
日期稳定可得，判型偶尔可从 ONIX 推断；不提供连载状态与总卷数。

设计约定（务必遵守 base.py 的实现方约定）：
- openBD 是按 ISBN 取书目，**无书名检索能力**，故 ``search`` 恒返回 ``[]``。
- ``fetch`` 使用 candidate 的 ``isbn13`` 标识查询；candidate 无 ISBN 时返回 ``None``。
- 缺失字段一律置 ``None``，交由 Merger 统一转 Unknown_Marker。
- 所有网络/HTTP/解析异常在内部捕获并转空结果（``search`` → ``[]`` / ``fetch`` → ``None``），
  绝不外抛。
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from app.shared import config
from app.modules.book_lookup.adapters.base import DataSourceAdapter
from app.modules.book_lookup.models import Candidate, Price, RawEditionRecord

if TYPE_CHECKING:
    import httpx

# openBD 取书目 API 端点。
_OPENBD_GET_URL = "https://api.openbd.jp/v1/get"


class OpenBdAdapter(DataSourceAdapter):
    """openBD 日版适配器。按 ISBN 取书目并解析为 RawEditionRecord。"""

    name = config.SOURCE_OPENBD
    supported_editions = [config.EDITION_JP]

    async def search(self, title: str, client: "httpx.AsyncClient") -> list[Candidate]:
        """openBD 无书名检索能力，恒返回空候选列表。"""
        return []

    async def fetch(
        self, candidate: Candidate, edition: str, client: "httpx.AsyncClient"
    ) -> RawEditionRecord | None:
        """按 candidate 的 ISBN 查询 openBD，解析为单条日版原始记录。

        candidate 无 ISBN 时返回 ``None``；网络/解析异常吞掉转 ``None``。
        """
        isbn = self._extract_isbn(candidate)
        if not isbn:
            return None

        try:
            resp = await client.get(_OPENBD_GET_URL, params={"isbn": isbn})
            resp.raise_for_status()
            data = resp.json()
        except Exception:
            # 网络错误、HTTP 4xx/5xx、JSON 解析失败等：best-effort 降级为空结果。
            return None

        return self._parse(data, edition, fallback_isbn=isbn)

    # --- 内部解析辅助 ---------------------------------------------------------

    @staticmethod
    def _extract_isbn(candidate: Candidate) -> str | None:
        """从 candidate 的 identifiers 中取 ISBN（优先 isbn13，其次 isbn）。"""
        ids = candidate.identifiers or {}
        return ids.get("isbn13") or ids.get("isbn") or None

    def _parse(
        self, data: Any, edition: str, fallback_isbn: str | None
    ) -> RawEditionRecord | None:
        """把 openBD 返回的 JSON 解析为 RawEditionRecord。

        openBD 返回一个数组，元素为 ``{"onix":..., "summary":...}`` 或 ``null``。
        任一子字段解析失败都置 None，不影响其余字段。
        """
        if not isinstance(data, list) or not data:
            return None
        entry = data[0]
        if not isinstance(entry, dict):
            return None

        onix = entry.get("onix") or {}
        summary = entry.get("summary") or {}
        if not isinstance(onix, dict):
            onix = {}
        if not isinstance(summary, dict):
            summary = {}

        title = self._get_title(summary, onix)
        author = self._get_author(summary, onix)
        publisher = self._get_publisher(summary, onix)
        isbn = summary.get("isbn") or fallback_isbn
        publish_date = self._get_publish_date(summary, onix)
        price = self._get_price(onix)
        fmt = self._get_format(onix)

        return RawEditionRecord(
            edition=edition,
            source=self.name,
            title=title,
            author=author,
            publisher=publisher,
            format=fmt,
            price=price,
            serialization_status=None,  # openBD 不提供连载状态
            total_volumes=None,
            latest_volume=None,
            isbn=isbn or None,
            publish_date=publish_date,
        )

    @staticmethod
    def _get_title(summary: dict, onix: dict) -> str | None:
        """书名：优先 summary.title，其次 ONIX DescriptiveDetail.TitleDetail。"""
        title = summary.get("title")
        if title:
            return str(title)
        try:
            elems = onix["DescriptiveDetail"]["TitleDetail"]["TitleElement"]
            if isinstance(elems, list):
                elems = elems[0]
            text = elems.get("TitleText")
            if isinstance(text, dict):
                text = text.get("content")
            return str(text) if text else None
        except Exception:
            return None

    @staticmethod
    def _get_author(summary: dict, onix: dict) -> str | None:
        """作者：优先 summary.author，其次 ONIX Contributor.PersonName。"""
        author = summary.get("author")
        if author:
            return str(author)
        try:
            contribs = onix["DescriptiveDetail"]["Contributor"]
            if isinstance(contribs, dict):
                contribs = [contribs]
            names = []
            for c in contribs:
                name = c.get("PersonName")
                if isinstance(name, dict):
                    name = name.get("content")
                if name:
                    names.append(str(name))
            return " / ".join(names) if names else None
        except Exception:
            return None

    @staticmethod
    def _get_publisher(summary: dict, onix: dict) -> str | None:
        """出版社：优先 summary.publisher，其次 ONIX PublishingDetail.Publisher.PublisherName。"""
        publisher = summary.get("publisher")
        if publisher:
            return str(publisher)
        try:
            pub = onix["PublishingDetail"]["Publisher"]
            if isinstance(pub, list):
                pub = pub[0]
            name = pub.get("PublisherName")
            return str(name) if name else None
        except Exception:
            return None

    @staticmethod
    def _get_publish_date(summary: dict, onix: dict) -> str | None:
        """出版日期：优先 summary.pubdate（如 "20200818"），规整为 ISO 8601。"""
        pubdate = summary.get("pubdate")
        if pubdate:
            s = str(pubdate).strip()
            # openBD 常见形态 "YYYYMMDD" → "YYYY-MM-DD"；已含分隔符则原样返回。
            digits = s.replace("-", "")
            if len(digits) == 8 and digits.isdigit():
                return f"{digits[0:4]}-{digits[4:6]}-{digits[6:8]}"
            return s
        try:
            date = onix["PublishingDetail"]["PublishingDate"]
            if isinstance(date, list):
                date = date[0]
            d = str(date.get("Date"))
            if len(d) == 8 and d.isdigit():
                return f"{d[0:4]}-{d[4:6]}-{d[6:8]}"
            return d if d and d != "None" else None
        except Exception:
            return None

    @staticmethod
    def _get_price(onix: dict) -> Price | None:
        """定价：从 ONIX ProductSupply.SupplyDetail.Price 取金额与币种（JPY）。

        金额与币种必须成对；任一缺失则返回 None（不产出半价态）。
        """
        try:
            supply = onix["ProductSupply"]["SupplyDetail"]["Price"]
            if isinstance(supply, list):
                supply = supply[0]
            amount = supply.get("PriceAmount")
            currency = supply.get("CurrencyCode")
            if amount is None or not currency:
                return None
            return Price(amount=float(amount), currency=str(currency))
        except Exception:
            return None

    @staticmethod
    def _get_format(onix: dict) -> str | None:
        """判型：best-effort 从 ONIX DescriptiveDetail.EpubType/ProductFormDetail 推断。

        openBD 判型信息不稳定，拿不到即置 None。
        """
        try:
            detail = onix["DescriptiveDetail"]
            fmt = detail.get("ProductFormDetail")
            if isinstance(fmt, list):
                fmt = fmt[0]
            return str(fmt) if fmt else None
        except Exception:
            return None
