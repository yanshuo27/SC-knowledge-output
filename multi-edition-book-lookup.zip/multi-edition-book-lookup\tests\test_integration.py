"""端到端两阶段集成测试（任务 16.2）。

用 ``TestClient(create_app())`` + ``FakeAdapter``（来自 tests.conftest，不打真实网络）
注入 ``app.state.registry`` / ``app.state.aggregator``，走通两阶段：

    POST /api/search  →  用返回的候选  →  POST /api/detail

断言 detail 结果的 ``editions`` 四键齐全（台版/港版/日版/漫画）且 ``disclaimer`` 存在。

_Requirements: 8.2, 10.2, 10.3_
"""

from __future__ import annotations

from fastapi.testclient import TestClient

from app.shared import config
from app.modules.book_lookup.aggregator import Aggregator
from app.main import build_registry, create_app
from app.modules.book_lookup.models import Candidate
from app.modules.book_lookup.registry import AdapterRegistry
from tests.conftest import FakeAdapter, make_raw


def _make_client(registry: AdapterRegistry) -> TestClient:
    """构造注入了指定 registry/aggregator 的 TestClient（走 FakeAdapter，不打网络）。

    lifespan 会复用预置的 ``app.state.registry`` / ``app.state.aggregator``，
    并仍创建一个真实（无代理）client，但 FakeAdapter 不会用到它。
    """
    app = create_app()
    app.state.registry = registry
    app.state.aggregator = Aggregator(registry, timeout_s=1.0)
    return TestClient(app)


def _candidate() -> Candidate:
    return Candidate(
        candidate_id="fake:1",
        title="葬送のフリーレン",
        author="山田鐘人",
        source=config.SOURCE_OPENBD,
    )


def test_end_to_end_two_phase_search_then_detail():
    """端到端：/api/search 得到候选 → /api/detail 聚合四版本 + disclaimer。

    构造一个既能 search（产出候选）又能 fetch（产出日版记录）的 FakeAdapter，
    覆盖到 build_registry 中同名的真实 openbd Adapter；其余版本无源 → 稳定占位。
    """
    cand = _candidate()
    jp_adapter = FakeAdapter(
        name=config.SOURCE_OPENBD,
        supported_editions=[config.EDITION_JP],
        search_results=[cand],
        fetch_result=make_raw(
            config.EDITION_JP, config.SOURCE_OPENBD, title="葬送のフリーレン 1"
        ),
    )
    registry = build_registry()
    registry.register(jp_adapter)  # 同名覆盖真实 openbd

    with _make_client(registry) as client:
        # --- 阶段一：search ---
        s = client.post("/api/search", json={"title": "葬送のフリーレン"})
        assert s.status_code == 200
        candidates = s.json()["candidates"]
        assert len(candidates) >= 1

        # --- 阶段二：detail（回传阶段一的候选对象） ---
        d = client.post("/api/detail", json={"candidate": candidates[0]})
        assert d.status_code == 200
        body = d.json()

        # editions 四键齐全。
        assert set(body["editions"].keys()) == set(config.ALL_EDITIONS)
        # disclaimer 存在且为配置文本。
        assert body["disclaimer"] == config.SERIALIZATION_DISCLAIMER
        # 日版有结果 present=True；无源版本占位 present=False。
        assert body["editions"][config.EDITION_JP]["present"] is True
        assert body["editions"][config.EDITION_HK]["present"] is False
        assert (
            body["editions"][config.EDITION_HK]["placeholder"]
            == config.MISSING_EDITION_PLACEHOLDER
        )


def test_end_to_end_all_four_editions_present_with_fake_sources():
    """四版本各配一个产出记录的 FakeAdapter → detail 四版本全部 present=True。

    注意：``adapters_for_edition`` 严格按 ``config.EDITION_ADAPTER_MAP`` 声明的**源名**
    解析 Adapter，因此 fake 源必须以映射中的真实源名注册（每类 Edition 取其映射的首个源名）。
    """
    cand = _candidate()
    registry = AdapterRegistry()
    # 每类 Edition 取其 EDITION_ADAPTER_MAP 映射的首个源名注册 fake，确保能被解析到。
    edition_source = {
        edition: config.EDITION_ADAPTER_MAP[edition][0]
        for edition in config.ALL_EDITIONS
    }
    for edition, src in edition_source.items():
        registry.register(
            FakeAdapter(
                name=src,
                supported_editions=[edition],
                search_results=[cand] if edition == config.EDITION_JP else [],
                fetch_result=make_raw(edition, src, title=f"{edition}书名"),
            )
        )

    with _make_client(registry) as client:
        s = client.post("/api/search", json={"title": "葬送のフリーレン"})
        assert s.status_code == 200
        candidates = s.json()["candidates"]
        assert len(candidates) >= 1

        d = client.post("/api/detail", json={"candidate": candidates[0]})
        assert d.status_code == 200
        body = d.json()
        assert set(body["editions"].keys()) == set(config.ALL_EDITIONS)
        assert body["disclaimer"] == config.SERIALIZATION_DISCLAIMER
        for edition in config.ALL_EDITIONS:
            assert body["editions"][edition]["present"] is True
