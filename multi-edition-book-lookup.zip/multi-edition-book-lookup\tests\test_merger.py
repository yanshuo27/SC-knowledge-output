"""Merger 合并去重层的示例/边界单元测试（任务 4.13，非属性、具体案例）。

覆盖：
- 单源直填
- 部分字段缺失（缺失填 N/A，不触发整版占位）
- 全缺失（含空列表）→ 整版占位
- 冲突标注（按优先级选值 + field_conflicts）
- 连载中 → 总卷数 N/A（即便源给了数字）
- 完结 → 输出具体总卷数
- priority 缺 source 兜底不报错

_Requirements: 7.1, 7.2, 7.3, 13.3_
"""

from __future__ import annotations

from app.shared import config
from app.modules.book_lookup.merger import Merger
from app.modules.book_lookup.models import Price, RawEditionRecord, SerializationStatus

_MERGER = Merger()


def test_single_source_direct_fill():
    """单源直填：各字段原样落地，sources 恰含该源。"""
    raw = RawEditionRecord(
        edition="日版",
        source="openbd",
        title="葬送のフリーレン 1",
        author="山田鐘人",
        publisher="小学館",
        price=Price(amount=550.0, currency="JPY"),
        serialization_status=SerializationStatus.COMPLETED,
        total_volumes=12,
        latest_volume=12,
        isbn="9784098501234",
        publish_date="2020-08-18",
    )
    rec = _MERGER.merge("日版", [raw])

    assert rec.present is True
    assert rec.placeholder is None
    assert rec.title == "葬送のフリーレン 1"
    assert rec.author == "山田鐘人"
    assert rec.publisher == "小学館"
    assert isinstance(rec.price, Price)
    assert rec.price.amount == 550.0
    assert rec.price.currency == "JPY"
    assert rec.serialization_status == "完结"
    assert rec.isbn == "9784098501234"
    assert rec.sources == ["openbd"]
    assert rec.field_conflicts == []


def test_partial_missing_fills_unknown_marker():
    """部分字段缺失：present=True，缺失字段填 N/A，不触发整版占位。"""
    raw = RawEditionRecord(
        edition="台版",
        source="books_com_tw",
        title="葬送的芙莉莲 1",
        # author / publisher / format / price / isbn / publish_date 均缺失
    )
    rec = _MERGER.merge("台版", [raw])

    assert rec.present is True
    assert rec.placeholder is None
    assert rec.title == "葬送的芙莉莲 1"
    assert rec.author == config.UNKNOWN_MARKER
    assert rec.publisher == config.UNKNOWN_MARKER
    assert rec.format == config.UNKNOWN_MARKER
    assert rec.price == config.UNKNOWN_MARKER
    assert rec.isbn == config.UNKNOWN_MARKER
    assert rec.publish_date == config.UNKNOWN_MARKER
    # 未提供状态 → 未知
    assert rec.serialization_status == "未知"


def test_all_missing_returns_edition_placeholder():
    """全字段缺失（仅有 source）→ 整版占位 present=False。"""
    raw = RawEditionRecord(edition="港版", source="hk_generic")
    rec = _MERGER.merge("港版", [raw])

    assert rec.present is False
    assert rec.placeholder == config.MISSING_EDITION_PLACEHOLDER
    assert rec.sources == []


def test_empty_list_returns_edition_placeholder():
    """空列表 → 整版占位 present=False，不报错。"""
    rec = _MERGER.merge("港版", [])

    assert rec.present is False
    assert rec.placeholder == config.MISSING_EDITION_PLACEHOLDER
    assert rec.sources == []


def test_conflict_priority_selection_and_annotation():
    """冲突标注：同字段不同非缺失值 → 取优先级最高源的值，字段名入 field_conflicts。

    openbd(优先级1) vs google_books(优先级3) 对 publisher 冲突 → 取 openbd 的值。
    """
    raw_high = RawEditionRecord(
        edition="日版", source="openbd", publisher="小学館"
    )
    raw_low = RawEditionRecord(
        edition="日版", source="google_books", publisher="Shogakukan"
    )
    rec = _MERGER.merge("日版", [raw_low, raw_high])  # 故意乱序输入

    assert rec.present is True
    assert rec.publisher == "小学館"  # openbd 优先级更高（数值 1 < 3）
    assert "publisher" in rec.field_conflicts
    # 两个源都贡献了非缺失数据，均计入 sources。
    assert set(rec.sources) == {"openbd", "google_books"}


def test_ongoing_forces_total_volumes_unknown():
    """连载中 → total_volumes 强制 N/A，即便源给了具体数字。"""
    raw = RawEditionRecord(
        edition="漫画",
        source="google_books",
        title="葬送のフリーレン",
        serialization_status=SerializationStatus.ONGOING,
        total_volumes=13,  # 源给了数字，但连载中应被强制为 N/A
    )
    rec = _MERGER.merge("漫画", [raw])

    assert rec.present is True
    assert rec.serialization_status == "连载中"
    assert rec.total_volumes == config.UNKNOWN_MARKER


def test_completed_outputs_concrete_total_volumes():
    """完结 → 输出具体总卷数（数字字符串）。"""
    raw = RawEditionRecord(
        edition="日版",
        source="openbd",
        title="鋼の錬金術師",
        serialization_status=SerializationStatus.COMPLETED,
        total_volumes=27,
    )
    rec = _MERGER.merge("日版", [raw])

    assert rec.present is True
    assert rec.serialization_status == "完结"
    assert rec.total_volumes == "27"


def test_priority_missing_source_fallback_no_error():
    """priority 缺 source 兜底：使用不在 SOURCE_PRIORITY 中的源名，不报错。"""
    raw_known = RawEditionRecord(
        edition="日版", source="openbd", title="已知源标题"
    )
    raw_unknown = RawEditionRecord(
        edition="日版", source="mystery_source", title="未知源标题"
    )
    # 不传 priority，使用默认 config.SOURCE_PRIORITY；mystery_source 不在其中。
    rec = _MERGER.merge("日版", [raw_unknown, raw_known])

    assert rec.present is True
    # 已知源 openbd(1) 优先级高于未登记源(兜底极大值) → 取 openbd 的值。
    assert rec.title == "已知源标题"
    assert "title" in rec.field_conflicts
    assert set(rec.sources) == {"openbd", "mystery_source"}


def test_completed_without_total_volumes_is_unknown():
    """完结但源未给总卷数 → total_volumes 为 N/A（边界）。"""
    raw = RawEditionRecord(
        edition="日版",
        source="openbd",
        title="某完结作",
        serialization_status=SerializationStatus.COMPLETED,
        # total_volumes 缺失
    )
    rec = _MERGER.merge("日版", [raw])

    assert rec.serialization_status == "完结"
    assert rec.total_volumes == config.UNKNOWN_MARKER


def test_latest_volume_number_to_string():
    """latest_volume 为数字时输出数字字符串；缺失时为 N/A。"""
    raw = RawEditionRecord(
        edition="台版",
        source="books_com_tw",
        title="某作",
        latest_volume=13,
    )
    rec = _MERGER.merge("台版", [raw])

    assert rec.latest_volume == "13"


def test_status_only_record_still_missing_edition():
    """仅提供 serialization_status（无任何普通字段）→ 仍判定整版缺失。"""
    raw = RawEditionRecord(
        edition="港版",
        source="hk_generic",
        serialization_status=SerializationStatus.ONGOING,
    )
    rec = _MERGER.merge("港版", [raw])

    # serialization_status 不参与整版存在判定，故仍为整版缺失。
    assert rec.present is False
    assert rec.placeholder == config.MISSING_EDITION_PLACEHOLDER
