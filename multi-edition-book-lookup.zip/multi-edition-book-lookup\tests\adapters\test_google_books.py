"""GoogleBooksAdapter 解析单测。

使用录制的 Google Books JSON 样例，配合 `pytest-httpx` 的 `httpx_mock` 拦截请求
（不打真实网络），断言 search 候选解析、日版与漫画两种 fetch 的字段映射。
"""

from __future__ import annotations

from pathlib import Path

import httpx
import pytest

from app.shared import config
from app.modules.book_lookup.adapters.google_books import GoogleBooksAdapter
from app.modules.book_lookup.models import Candidate, Price

_FIXTURES = Path(__file__).parent / "fixtures"
_VOLUMES_URL = "https://www.googleapis.com/books/v1/volumes"


def _load(name: str) -> str:
    return (_FIXTURES / name).read_text(encoding="utf-8")


async def test_search_parses_candidates(httpx_mock):
    """search → 解析 items 为 Candidate 列表；candidate_id 与 identifiers 正确。"""
    httpx_mock.add_response(
        url=f"{_VOLUMES_URL}?q=%E8%91%AC%E9%80%81%E3%81%AE%E3%83%95%E3%83%AA%E3%83%BC%E3%83%AC%E3%83%B3",
        text=_load("google_books_search.json"),
        headers={"content-type": "application/json"},
    )
    adapter = GoogleBooksAdapter()
    async with httpx.AsyncClient() as client:
        cands = await adapter.search("葬送のフリーレン", client)

    assert len(cands) == 2
    first = cands[0]
    assert isinstance(first, Candidate)
    assert first.candidate_id == "google_books:zZ1kEAAAQBAJ"
    assert first.title == "葬送のフリーレン"
    assert first.author == "山田鐘人 / アベツカサ"
    assert first.publisher == "小学館"
    assert first.source == config.SOURCE_GOOGLE_BOOKS
    assert first.identifiers["gb_id"] == "zZ1kEAAAQBAJ"
    assert first.identifiers["isbn13"] == "9784098501234"
    # 第二条无出版社/无 saleInfo 价格，identifiers 仍有 gb_id + isbn13
    assert cands[1].publisher is None
    assert cands[1].identifiers["gb_id"] == "aB2lEAAAQBAJ"


async def test_fetch_by_gb_id_parses_volume(httpx_mock):
    """fetch 有 gb_id → 直接取 volume 详情，字段映射正确（日版）。"""
    httpx_mock.add_response(
        url=f"{_VOLUMES_URL}/zZ1kEAAAQBAJ",
        text=_load("google_books_volume.json"),
        headers={"content-type": "application/json"},
    )
    adapter = GoogleBooksAdapter()
    cand = Candidate(
        candidate_id="google_books:zZ1kEAAAQBAJ",
        title="葬送のフリーレン",
        source=config.SOURCE_GOOGLE_BOOKS,
        identifiers={"gb_id": "zZ1kEAAAQBAJ"},
    )
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(cand, config.EDITION_JP, client)

    assert rec is not None
    assert rec.edition == config.EDITION_JP
    assert rec.source == config.SOURCE_GOOGLE_BOOKS
    assert rec.title == "葬送のフリーレン 1"
    assert rec.author == "山田鐘人 / アベツカサ"
    assert rec.publisher == "小学館"
    assert rec.isbn == "9784098501234"
    assert rec.publish_date == "2020-08-18"
    assert rec.format is None  # Google Books 无判型
    assert isinstance(rec.price, Price)
    assert rec.price.amount == 550.0
    assert rec.price.currency == "JPY"
    # 日版不推断 latest_volume
    assert rec.latest_volume is None


async def test_fetch_manga_infers_latest_volume(httpx_mock):
    """漫画 edition → 从标题末尾数字 best-effort 推断 latest_volume。"""
    httpx_mock.add_response(
        url=f"{_VOLUMES_URL}/aB2lEAAAQBAJ",
        text=_load("google_books_manga_volume.json"),
        headers={"content-type": "application/json"},
    )
    adapter = GoogleBooksAdapter()
    cand = Candidate(
        candidate_id="google_books:aB2lEAAAQBAJ",
        title="葬送のフリーレン 13",
        source=config.SOURCE_GOOGLE_BOOKS,
        identifiers={"gb_id": "aB2lEAAAQBAJ"},
    )
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(cand, config.EDITION_MANGA, client)

    assert rec is not None
    assert rec.edition == config.EDITION_MANGA
    assert rec.latest_volume == 13
    assert rec.isbn == "9784098531301"
    # 无 saleInfo 价格 → price 为 None
    assert rec.price is None
    # 无出版社 → None
    assert rec.publisher is None


async def test_fetch_by_isbn_query_fallback(httpx_mock):
    """无 gb_id 但有 isbn13 → 退化为 isbn: 检索取首条。"""
    httpx_mock.add_response(
        url=f"{_VOLUMES_URL}?q=isbn%3A9784098501234",
        text=_load("google_books_search.json"),
        headers={"content-type": "application/json"},
    )
    adapter = GoogleBooksAdapter()
    cand = Candidate(
        candidate_id="test:frieren",
        title="葬送のフリーレン",
        source="test",
        identifiers={"isbn13": "9784098501234"},
    )
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(cand, config.EDITION_JP, client)

    assert rec is not None
    assert rec.title == "葬送のフリーレン"
    assert rec.isbn == "9784098501234"


async def test_search_http_error_returns_empty(httpx_mock):
    """search HTTP 错误 → 吞掉转 []。"""
    httpx_mock.add_response(
        url=f"{_VOLUMES_URL}?q=x",
        status_code=500,
    )
    adapter = GoogleBooksAdapter()
    async with httpx.AsyncClient() as client:
        result = await adapter.search("x", client)
    assert result == []


async def test_fetch_network_error_returns_none(httpx_mock):
    """fetch 网络异常 → 吞掉转 None。

    candidate 仅有 gb_id（无 isbn/title），fetch 只发起一次取详情请求；
    该请求抛网络异常被内部捕获，随后无候选可退化 → 返回 None。
    """
    httpx_mock.add_exception(httpx.ConnectError("boom"))
    adapter = GoogleBooksAdapter()
    cand = Candidate(
        candidate_id="google_books:zZ1kEAAAQBAJ",
        title="",  # 无书名 → 策略二无 query 可用，不再发第二次请求
        source=config.SOURCE_GOOGLE_BOOKS,
        identifiers={"gb_id": "zZ1kEAAAQBAJ"},
    )
    async with httpx.AsyncClient() as client:
        rec = await adapter.fetch(cand, config.EDITION_JP, client)
    assert rec is None


def test_adapter_metadata():
    """name 用 config 常量，supported_editions 含日版与漫画。"""
    adapter = GoogleBooksAdapter()
    assert adapter.name == config.SOURCE_GOOGLE_BOOKS
    assert config.EDITION_JP in adapter.supported_editions
    assert config.EDITION_MANGA in adapter.supported_editions
