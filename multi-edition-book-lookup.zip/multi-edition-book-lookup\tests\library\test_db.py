"""library db 模块的单元测试。

覆盖：
- init_db 后 library_items 表存在
- init_db 幂等（连续调用两次不报错）
- get_connection 返回的 row_factory 为 sqlite3.Row
- 父目录自动创建（多级不存在的目录路径）
- WAL 日志模式（文件库）
"""

from __future__ import annotations

import sqlite3

from app.modules.library.db import get_connection, init_db


class TestInitDb:
    """init_db 建表功能测试。"""

    def test_table_exists_after_init(self, tmp_path):
        """init_db 后 library_items 表应存在于数据库中。"""
        db_path = str(tmp_path / "test.db")
        init_db(db_path)

        conn = sqlite3.connect(db_path)
        try:
            rows = conn.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name='library_items'"
            ).fetchall()
            assert len(rows) == 1
            assert rows[0][0] == "library_items"
        finally:
            conn.close()

    def test_idempotent(self, tmp_path):
        """连续调用两次 init_db 不应报错（幂等性）。"""
        db_path = str(tmp_path / "test.db")
        init_db(db_path)
        init_db(db_path)  # 第二次不应报错

        conn = sqlite3.connect(db_path)
        try:
            rows = conn.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name='library_items'"
            ).fetchall()
            assert len(rows) == 1
        finally:
            conn.close()


class TestGetConnection:
    """get_connection 连接配置测试。"""

    def test_row_factory_is_sqlite_row(self, tmp_path):
        """get_connection 返回的 conn.row_factory 应为 sqlite3.Row。"""
        db_path = str(tmp_path / "test.db")
        init_db(db_path)

        conn = get_connection(db_path)
        try:
            assert conn.row_factory is sqlite3.Row

            # 验证实际可按列名取值
            conn.execute(
                "INSERT INTO library_items "
                "(title, ownership_status, created_at, updated_at) "
                "VALUES (?, ?, ?, ?)",
                ("测试书名", "已购", "2025-01-01T00:00:00", "2025-01-01T00:00:00"),
            )
            conn.commit()
            row = conn.execute("SELECT * FROM library_items LIMIT 1").fetchone()
            assert row["title"] == "测试书名"
            assert row["ownership_status"] == "已购"
        finally:
            conn.close()


class TestParentDirCreation:
    """父目录自动创建测试。"""

    def test_deep_nested_dir_auto_created(self, tmp_path):
        """给一个多级不存在的目录路径，init_db 后数据库文件应存在。"""
        db_path = str(tmp_path / "sub" / "deep" / "x.db")
        init_db(db_path)

        from pathlib import Path

        assert Path(db_path).exists()


class TestWalMode:
    """WAL 日志模式测试。"""

    def test_wal_enabled_for_file_db(self, tmp_path):
        """文件库的 journal_mode 应为 'wal'（小写）。"""
        db_path = str(tmp_path / "test.db")
        conn = get_connection(db_path)
        try:
            result = conn.execute("PRAGMA journal_mode;").fetchone()
            assert result[0] == "wal"
        finally:
            conn.close()
