"""博客来（books.com.tw）台版数据源适配器。

博客来是台湾最主要的图书电商，但**没有公开的结构化 API**，只能抓取其
搜索结果页与商品页 HTML，再用 BeautifulSoup + lxml 解析。这是台版繁中
书目**唯一稳定的公开来源**，因此在 `SOURCE_PRIORITY` 中与 openBD 同为最高优先级。

现实性约定（参见 design.md「各 Adapter 设计思路与字段现实性」）：

- 稳定可得：书名、作者、出版社、定价(TWD)、ISBN、出版日期。
- best-effort（不稳定）：判型（format）、最新册数（latest_volume）。
- 基本拿不到：连载状态、总卷数（一律留 None，交由 Merger 处理）。

**页面抓取脆弱性**：博客来随时可能改版导致选择器失效。因此本适配器对
网络错误与 HTML 结构解析失败一律**容错降级**——`search` 返回 `[]`、
`fetch` 返回 `None`，缺失字段置 `None`，**绝不外抛异常**（失败隔离约定，
见 base.py 与 design.md Error Handling）。
"""

from __future__ import annotations

import hashlib
import re
from typing import TYPE_CHECKING

from bs4 import BeautifulSoup

from app.shared import config
from app.modules.book_lookup.adapters.base import DataSourceAdapter
from app.modules.book_lookup.models import Candidate, Price, RawEditionRecord

if TYPE_CHECKING:  # 仅类型检查期引入，运行期避免强依赖。
    import httpx

# 博客来搜索结果页 URL 模板（书名会被 URL 编码后拼入 <书名> 位置）。
_SEARCH_URL = "https://search.books.com.tw/search/query/key/{title}/"

# 从商品 URL 中提取商品 id（形如 .../products/0010901234 或 ?...item=0010901234）。
_PRODUCT_ID_RE = re.compile(r"/products/([0-9A-Za-z]+)")
# 定价文本中提取数字（如 "優惠價：140元" → 140）。
_PRICE_RE = re.compile(r"([0-9][0-9,]*)")


class BooksComTwAdapter(DataSourceAdapter):
    """台版繁中数据源适配器：抓取博客来页面并解析为内部模型。

    异常处理遵循 base 约定：任何网络/解析异常在内部捕获，
    ``search`` 降级为 ``[]``、``fetch`` 降级为 ``None``。
    """

    name = config.SOURCE_BOOKS_COM_TW
    supported_editions = [config.EDITION_TW]

    async def search(self, title: str, client: "httpx.AsyncClient") -> list[Candidate]:
        """抓取博客来搜索结果页并解析候选列表。

        任何网络错误或页面结构异常都降级为返回空列表，绝不外抛。
        """
        try:
            url = _SEARCH_URL.format(title=title)
            resp = await client.get(url)
            resp.raise_for_status()
            return self._parse_search_html(resp.text)
        except Exception:
            # 网络失败 / HTTP 4xx-5xx / 解析异常统统降级为空结果。
            return []

    async def fetch(
        self, candidate: Candidate, edition: str, client: "httpx.AsyncClient"
    ) -> RawEditionRecord | None:
        """抓取商品页并解析为单条 RawEditionRecord。

        商品 URL 优先取 candidate.identifiers["url"]；缺失或抓取/解析失败
        一律降级为 None，缺失字段置 None。
        """
        try:
            product_url = candidate.identifiers.get("url")
            if not product_url:
                return None
            resp = await client.get(product_url)
            resp.raise_for_status()
            return self._parse_product_html(resp.text, edition)
        except Exception:
            return None

    # ------------------------------------------------------------------
    # 解析辅助（纯函数，便于单测；内部异常同样吞掉以保证降级）
    # ------------------------------------------------------------------

    def _parse_search_html(self, html: str) -> list[Candidate]:
        """从搜索结果页 HTML 解析候选列表。

        博客来搜索结果通常是一组商品条目，每条含商品链接（书名）、作者、
        出版社等信息。此处采用 best-effort 选择器，解析不到时返回 []。
        """
        candidates: list[Candidate] = []
        try:
            soup = BeautifulSoup(html, "lxml")
        except Exception:
            return []

        # 商品条目容器：博客来搜索页每条结果常见为 <li class="item"> 结构。
        items = soup.select("li.item")
        for item in items:
            try:
                cand = self._parse_search_item(item)
            except Exception:
                # 单条解析失败不影响其余条目。
                cand = None
            if cand is not None:
                candidates.append(cand)
        return candidates

    def _parse_search_item(self, item) -> Candidate | None:
        """解析单个搜索结果条目为 Candidate。解析不出书名/链接则返回 None。"""
        # 书名与商品链接：优先取 <h4><a href=...>书名</a></h4>。
        link = item.select_one("h4 a") or item.select_one("a.mslocation") or item.select_one("a")
        if link is None:
            return None
        title = link.get_text(strip=True)
        href = link.get("href") or ""
        if not title:
            return None

        # 规范化 URL（博客来搜索页链接常为 //www.books.com.tw/... 形式）。
        url = self._normalize_url(href)

        product_id = self._extract_product_id(url)
        candidate_id = self._make_candidate_id(product_id, url, title)

        author = self._text_or_none(item.select_one("p.author, a.author"))
        publisher = self._text_or_none(item.select_one("p.publisher, a.publisher"))

        identifiers: dict[str, str] = {}
        if url:
            identifiers["url"] = url

        return Candidate(
            candidate_id=candidate_id,
            title=title,
            author=author,
            publisher=publisher,
            source=self.name,
            identifiers=identifiers,
        )

    def _parse_product_html(self, html: str, edition: str) -> RawEditionRecord | None:
        """从商品页 HTML 解析单源原始记录。

        任一字段解析失败仅将该字段置 None，不影响其余字段；若整页无法解析
        出任何有效内容则返回 None。
        """
        try:
            soup = BeautifulSoup(html, "lxml")
        except Exception:
            return None

        title = self._text_or_none(soup.select_one("h1"))
        # 完全解析不到书名，视为无效页面。
        if not title:
            return None

        author = self._text_or_none(
            soup.select_one("li.author a, .author a, span.author a")
        )
        publisher = self._text_or_none(
            soup.select_one("li.publish a, .publisher a, span.publisher a")
        )
        price = self._parse_price(soup)
        isbn = self._parse_isbn(soup)
        publish_date = self._parse_publish_date(soup)
        fmt = self._parse_format(soup)

        return RawEditionRecord(
            edition=edition,
            source=self.name,
            title=title,
            author=author,
            publisher=publisher,
            format=fmt,
            price=price,
            serialization_status=None,  # 博客来不提供，交由 Merger 落「未知」。
            total_volumes=None,
            latest_volume=self._parse_latest_volume(title),
            isbn=isbn,
            publish_date=publish_date,
        )

    # --- 字段级解析（best-effort，失败返回 None） ---

    def _parse_price(self, soup) -> Price | None:
        """解析定价（TWD）。金额与币种必须成对，解析不到金额则返回 None。

        博客来定价区通常形如 ``<li class="price">優惠價：<b>79</b>折<em>140</em>元</li>``，
        真正的售价放在 ``<em>`` 中。遍历定价区内所有候选节点，取第一个能解析出
        数字的作为金额，避免误取「優惠價：」这类无数字的标签节点。
        """
        # 优先取 <em>（博客来售价惯用 em 承载）；其次退回 strong/b。
        # 注意 CSS select 返回文档顺序而非选择器顺序，故按优先级分组查询，
        # 避免误取同一定价区里靠前的折扣数字（如 "79" 折）。
        for selector in (".price em, li.price em, .set1 em", ".price strong, .price b"):
            for node in soup.select(selector):
                m = _PRICE_RE.search(node.get_text(strip=True))
                if not m:
                    continue
                try:
                    amount = float(m.group(1).replace(",", ""))
                except ValueError:
                    continue
                return Price(amount=amount, currency="TWD")
        return None

    def _parse_isbn(self, soup) -> str | None:
        """从商品资料区解析 ISBN。博客来常以 'ISBN：9789573...' 文本呈现。"""
        # 优先在含 "ISBN" 文案的节点附近取 13 位数字。
        text = soup.get_text(" ", strip=True)
        m = re.search(r"ISBN[：:\s]*([0-9Xx\-]{10,17})", text)
        if not m:
            return None
        isbn = m.group(1).replace("-", "").strip()
        return isbn or None

    def _parse_publish_date(self, soup) -> str | None:
        """解析出版日期，尽量规范化为 ISO 8601（YYYY-MM-DD）。"""
        text = soup.get_text(" ", strip=True)
        # 匹配 "出版日期：2021/08/10" 或 "2021-08-10"。
        m = re.search(r"出版日期[：:\s]*([0-9]{4})[/\-.]([0-9]{1,2})[/\-.]([0-9]{1,2})", text)
        if not m:
            return None
        y, mo, d = m.group(1), m.group(2).zfill(2), m.group(3).zfill(2)
        return f"{y}-{mo}-{d}"

    def _parse_format(self, soup) -> str | None:
        """best-effort 解析判型/开本（如 '25開'）。拿不到返回 None。"""
        text = soup.get_text(" ", strip=True)
        m = re.search(r"([0-9]{1,2}\s*開|[0-9]{1,2}開本|菊[0-9]*開|新書判)", text)
        if not m:
            return None
        return m.group(1).replace(" ", "") or None

    def _parse_latest_volume(self, title: str | None) -> int | None:
        """best-effort：从书名尾部数字推断最新册数（如 '葬送的芙莉莲 13' → 13）。"""
        if not title:
            return None
        m = re.search(r"(\d+)\s*$", title)
        if not m:
            return None
        try:
            return int(m.group(1))
        except ValueError:
            return None

    # --- 通用小工具 ---

    @staticmethod
    def _text_or_none(node) -> str | None:
        """取节点文本，去空白；节点为空或文本为空返回 None。"""
        if node is None:
            return None
        text = node.get_text(strip=True)
        return text or None

    @staticmethod
    def _normalize_url(href: str) -> str:
        """规范化博客来链接：补全协议头的 // 前缀。"""
        if not href:
            return ""
        if href.startswith("//"):
            return "https:" + href
        return href

    @classmethod
    def _extract_product_id(cls, url: str) -> str | None:
        """从商品 URL 提取商品 id，提取不到返回 None。"""
        if not url:
            return None
        m = _PRODUCT_ID_RE.search(url)
        return m.group(1) if m else None

    @classmethod
    def _make_candidate_id(cls, product_id: str | None, url: str, title: str) -> str:
        """构造稳定 candidate_id：'books_com_tw:<商品id或url哈希>'。"""
        if product_id:
            key = product_id
        elif url:
            key = hashlib.sha1(url.encode("utf-8")).hexdigest()[:12]
        else:
            key = hashlib.sha1(title.encode("utf-8")).hexdigest()[:12]
        return f"{config.SOURCE_BOOKS_COM_TW}:{key}"
