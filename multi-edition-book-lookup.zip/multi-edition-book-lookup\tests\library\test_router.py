"""library HTTP 路由层（router）的端到端测试，使用 FastAPI TestClient。

关键：library 的默认库来自 config.LIBRARY_DB_PATH，repository 在每次调用时
读取该值（db.get_connection 中 `if db_path is None: db_path = config.LIBRARY_DB_PATH`）。
因此测试用 monkeypatch 把 config.LIBRARY_DB_PATH 指向 tmp_path 下的临时库，
并在建 app 前 init_db 该临时库，避免污染项目 data/library.db。

覆盖：CRUD 全流程、校验 400（VALIDATION_ERROR）、未找到 404（NOT_FOUND）、
筛选、导出 CSV/JSON（含空清单）、按筛选导出。
"""

from __future__ import annotations

import json

import pytest
from fastapi.testclient import TestClient

from app.main import create_app
from app.modules.library.db import init_db
from app.shared import config


@pytest.fixture()
def client(tmp_path, monkeypatch) -> TestClient:
    """提供一个使用临时库的 TestClient。

    先把 config.LIBRARY_DB_PATH patch 到临时文件，再 init_db（建表用新库），
    最后建 app（create_app 内部的 init_db 占位也走已 patch 的路径）。
    """
    db_file = str(tmp_path / "router_test.db")
    monkeypatch.setattr(config, "LIBRARY_DB_PATH", db_file)
    init_db()  # 用已 patch 的默认路径建表
    return TestClient(create_app())


def _make_payload(title="海贼王", ownership_status="已购", purchase_price=100.0,
                  sale_price=150.0, **extra) -> dict:
    """构造一条合法的新建条目请求体。"""
    payload = {
        "title": title,
        "ownership_status": ownership_status,
        "purchase_price": purchase_price,
        "sale_price": sale_price,
    }
    payload.update(extra)
    return payload


# ==================== POST 新增 ====================


def test_post_create_ok(client):
    """POST 合法条目（含中文 title + 买入/卖出价）→ 201，含 id 与正确 profit。"""
    resp = client.post("/api/library/items", json=_make_payload())
    assert resp.status_code == 201
    body = resp.json()
    assert isinstance(body["id"], int)
    assert body["title"] == "海贼王"
    assert body["profit"] == 50.0  # 150 - 100
    assert body["profit_rate"] == 50.0  # (150-100)/100*100


def test_post_empty_title_400(client):
    """POST 空 title → 400 VALIDATION_ERROR。"""
    resp = client.post("/api/library/items", json=_make_payload(title=""))
    assert resp.status_code == 400
    assert resp.json()["code"] == "VALIDATION_ERROR"


def test_post_invalid_edition_400(client):
    """POST 非法 edition（"美版"）→ 400 VALIDATION_ERROR。"""
    resp = client.post(
        "/api/library/items", json=_make_payload(edition="美版")
    )
    assert resp.status_code == 400
    assert resp.json()["code"] == "VALIDATION_ERROR"


# ==================== GET 列表 / 详情 ====================


def test_get_list_contains_created(client):
    """GET 列表 → 200，含刚建的条目。"""
    client.post("/api/library/items", json=_make_payload(title="灌篮高手"))
    resp = client.get("/api/library/items")
    assert resp.status_code == 200
    titles = [item["title"] for item in resp.json()]
    assert "灌篮高手" in titles


def test_get_item_found_and_not_found(client):
    """GET 详情：存在 → 200；不存在（99999）→ 404 NOT_FOUND。"""
    created = client.post("/api/library/items", json=_make_payload()).json()
    item_id = created["id"]

    resp_ok = client.get(f"/api/library/items/{item_id}")
    assert resp_ok.status_code == 200
    assert resp_ok.json()["id"] == item_id

    resp_404 = client.get("/api/library/items/99999")
    assert resp_404.status_code == 404
    assert resp_404.json()["code"] == "NOT_FOUND"


# ==================== PUT 更新 ====================


def test_put_update_refreshes_profit(client):
    """PUT 改价 → 200，profit 随新价刷新。"""
    created = client.post(
        "/api/library/items", json=_make_payload(purchase_price=100.0, sale_price=150.0)
    ).json()
    item_id = created["id"]

    updated_payload = _make_payload(purchase_price=200.0, sale_price=260.0)
    resp = client.put(f"/api/library/items/{item_id}", json=updated_payload)
    assert resp.status_code == 200
    body = resp.json()
    assert body["profit"] == 60.0  # 260 - 200
    assert body["profit_rate"] == 30.0  # 60/200*100


def test_put_not_found_404(client):
    """PUT 不存在 id → 404 NOT_FOUND。"""
    resp = client.put("/api/library/items/99999", json=_make_payload())
    assert resp.status_code == 404
    assert resp.json()["code"] == "NOT_FOUND"


# ==================== DELETE 删除 ====================


def test_delete_flow(client):
    """DELETE 存在 → 200 {"deleted": true}；再 GET → 404；DELETE 不存在 → 404。"""
    created = client.post("/api/library/items", json=_make_payload()).json()
    item_id = created["id"]

    resp_del = client.delete(f"/api/library/items/{item_id}")
    assert resp_del.status_code == 200
    assert resp_del.json() == {"deleted": True}

    resp_get = client.get(f"/api/library/items/{item_id}")
    assert resp_get.status_code == 404

    resp_del_again = client.delete("/api/library/items/99999")
    assert resp_del_again.status_code == 404
    assert resp_del_again.json()["code"] == "NOT_FOUND"


# ==================== 筛选 ====================


def test_filter_by_ownership_status(client):
    """建多条不同 ownership_status，GET ?ownership_status=已购 只返回匹配。"""
    client.post("/api/library/items", json=_make_payload(title="A", ownership_status="已购"))
    client.post("/api/library/items", json=_make_payload(title="B", ownership_status="想要",
                                                          purchase_price=None, sale_price=None))
    client.post("/api/library/items", json=_make_payload(title="C", ownership_status="已售"))

    resp = client.get("/api/library/items", params={"ownership_status": "已购"})
    assert resp.status_code == 200
    body = resp.json()
    assert len(body) >= 1
    assert all(item["ownership_status"] == "已购" for item in body)
    titles = [item["title"] for item in body]
    assert "A" in titles
    assert "B" not in titles
    assert "C" not in titles


# ==================== 导出 ====================


def test_export_csv(client):
    """导出 CSV → 200，Content-Type 含 text/csv，body 前 3 字节是 BOM，
    Content-Disposition 含 attachment。"""
    client.post("/api/library/items", json=_make_payload())
    resp = client.get("/api/library/export", params={"format": "csv"})
    assert resp.status_code == 200
    assert "text/csv" in resp.headers["content-type"]
    assert resp.content[:3] == b"\xef\xbb\xbf"
    assert "attachment" in resp.headers["content-disposition"]


def test_export_json(client):
    """导出 JSON → 200，body 可 json.loads 为 list。"""
    client.post("/api/library/items", json=_make_payload())
    resp = client.get("/api/library/export", params={"format": "json"})
    assert resp.status_code == 200
    data = json.loads(resp.content)
    assert isinstance(data, list)
    assert len(data) >= 1


def test_export_empty(client):
    """空清单导出：CSV → 只表头行且有 BOM；JSON → []。"""
    # 新库无任何条目
    resp_csv = client.get("/api/library/export", params={"format": "csv"})
    assert resp_csv.status_code == 200
    assert resp_csv.content[:3] == b"\xef\xbb\xbf"
    # 去掉 BOM 后按行拆分，非空行应只有表头一行
    text = resp_csv.content.decode("utf-8-sig")
    non_empty_lines = [ln for ln in text.splitlines() if ln.strip()]
    assert len(non_empty_lines) == 1  # 只有表头

    resp_json = client.get("/api/library/export", params={"format": "json"})
    assert resp_json.status_code == 200
    assert json.loads(resp_json.content) == []


def test_export_json_with_filter(client):
    """按筛选导出：?format=json&ownership_status=已购 → 只含匹配条目。"""
    client.post("/api/library/items", json=_make_payload(title="X", ownership_status="已购"))
    client.post("/api/library/items", json=_make_payload(title="Y", ownership_status="已售"))

    resp = client.get(
        "/api/library/export",
        params={"format": "json", "ownership_status": "已购"},
    )
    assert resp.status_code == 200
    data = json.loads(resp.content)
    assert all(item["ownership_status"] == "已购" for item in data)
    titles = [item["title"] for item in data]
    assert "X" in titles
    assert "Y" not in titles


def test_export_default_format_is_csv(client):
    """不带 format 参数 → 默认 CSV。"""
    resp = client.get("/api/library/export")
    assert resp.status_code == 200
    assert "text/csv" in resp.headers["content-type"]
