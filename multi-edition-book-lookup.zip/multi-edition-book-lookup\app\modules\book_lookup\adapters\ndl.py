"""NdlAdapter：国立国会図書館（NDL）OpenSearch API（日版）数据源适配器。

NDL Search 提供 OpenSearch API，按检索条件返回 RSS 2.0 风格的 XML：

    GET https://ndlsearch.ndl.go.jp/api/opensearch?title=<title>

返回 XML 形如：

    <rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/" ...>
      <channel>
        <item>
          <title>葬送のフリーレン 1</title>
          <author>山田 鐘人 原作</author>
          <dc:publisher>小学館</dc:publisher>
          <dc:date>2020-08</dc:date>
          <dc:identifier xsi:type="dcndl:ISBN">9784098501234</dc:identifier>
          ...
        </item>
        ...
      </channel>
    </rss>

字段现实性（参见 design.md 的字段对照表）：书名/作者/出版社/ISBN/出版日期可得，
无定价。作为日版第三方交叉校验源。

设计约定：
- ``search`` 亦按书名走 OpenSearch，可选地把 item 解析为候选（本实现返回 []，
  因日版候选主要由 Google Books 提供，NDL 只做 fetch 交叉校验；保持接口简洁）。
- ``fetch`` 按 candidate 的书名查询 OpenSearch，用 lxml 解析首个 item 为 RawEditionRecord。
- 缺失字段一律置 ``None``；所有网络/HTTP/XML 解析异常内部捕获转空结果，绝不外抛。
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from lxml import etree

from app.shared import config
from app.modules.book_lookup.adapters.base import DataSourceAdapter
from app.modules.book_lookup.models import Candidate, RawEditionRecord

if TYPE_CHECKING:
    import httpx

_NDL_OPENSEARCH_URL = "https://ndlsearch.ndl.go.jp/api/opensearch"

# RSS item 中 Dublin Core 命名空间。
_NS = {
    "dc": "http://purl.org/dc/elements/1.1/",
    "dcndl": "http://ndl.go.jp/dcndl/terms/",
}


class NdlAdapter(DataSourceAdapter):
    """NDL 日版适配器。OpenSearch XML → RawEditionRecord。"""

    name = config.SOURCE_NDL
    supported_editions = [config.EDITION_JP]

    async def search(self, title: str, client: "httpx.AsyncClient") -> list[Candidate]:
        """NDL 作为交叉校验源，不产出候选，恒返回 ``[]``。"""
        return []

    async def fetch(
        self, candidate: Candidate, edition: str, client: "httpx.AsyncClient"
    ) -> RawEditionRecord | None:
        """按 candidate 书名查询 NDL OpenSearch，解析首个 item 为日版原始记录。

        无书名或网络/解析异常时返回 ``None``。
        """
        title = candidate.title
        if not title or not title.strip():
            return None

        try:
            resp = await client.get(_NDL_OPENSEARCH_URL, params={"title": title})
            resp.raise_for_status()
            content = resp.content
        except Exception:
            return None

        return self._parse(content, edition)

    # --- XML 解析 -------------------------------------------------------------

    def _parse(self, content: bytes, edition: str) -> RawEditionRecord | None:
        """用 lxml 解析 OpenSearch XML，取首个 <item> 映射为 RawEditionRecord。"""
        if not content:
            return None
        try:
            root = etree.fromstring(content)
        except Exception:
            return None

        item = root.find(".//channel/item")
        if item is None:
            # 兼容无 channel 包裹的情形。
            item = root.find(".//item")
        if item is None:
            return None

        title = self._text(item, "title")
        author = self._text(item, "author") or self._text_ns(item, "dc:creator")
        publisher = self._text_ns(item, "dc:publisher")
        publish_date = self._text_ns(item, "dc:date")
        isbn = self._extract_isbn(item)

        return RawEditionRecord(
            edition=edition,
            source=self.name,
            title=title,
            author=author,
            publisher=publisher,
            format=None,
            price=None,  # NDL 无定价
            serialization_status=None,
            total_volumes=None,
            latest_volume=None,
            isbn=isbn,
            publish_date=publish_date,
        )

    @staticmethod
    def _text(item: "etree._Element", tag: str) -> str | None:
        """取无命名空间子元素文本，缺失/空白置 None。"""
        el = item.find(tag)
        if el is None or el.text is None:
            return None
        text = el.text.strip()
        return text or None

    @staticmethod
    def _text_ns(item: "etree._Element", qname: str) -> str | None:
        """取带命名空间前缀（dc:/dcndl:）子元素文本，缺失/空白置 None。"""
        try:
            el = item.find(qname, namespaces=_NS)
        except Exception:
            return None
        if el is None or el.text is None:
            return None
        text = el.text.strip()
        return text or None

    @staticmethod
    def _extract_isbn(item: "etree._Element") -> str | None:
        """从 dc:identifier 中提取 ISBN（best-effort）。

        NDL 常以 ``<dc:identifier xsi:type="dcndl:ISBN">...</dc:identifier>`` 表达 ISBN；
        遍历所有 dc:identifier，优先取 type 含 ISBN 的项，否则取形似 ISBN 的纯数字串。
        """
        try:
            ids = item.findall("dc:identifier", namespaces=_NS)
        except Exception:
            return None
        fallback = None
        for el in ids:
            if el.text is None:
                continue
            val = el.text.strip()
            if not val:
                continue
            # 检查 xsi:type 属性是否标注为 ISBN。
            type_attr = ""
            for k, v in el.attrib.items():
                if k.endswith("type"):
                    type_attr = str(v)
                    break
            if "ISBN" in type_attr.upper():
                return val
            # 退化：形似 ISBN（去连字符后 10 或 13 位数字，末位可为 X）。
            digits = val.replace("-", "").upper()
            if fallback is None and len(digits) in (10, 13) and all(
                c.isdigit() or c == "X" for c in digits
            ):
                fallback = val
        return fallback
