"""共享错误处理层：全局异常兜底 handler 与统一错误响应结构。

- `install_exception_handlers(app)`：迁入旧 main.py 的全局 500 兜底，未捕获异常统一
  返回 ``500 {"error":"内部错误","code":"INTERNAL"}``，记 logger.exception，不泄露堆栈。
- `error_response(code, message, status)`：构造统一错误响应结构 ``{"error": msg, "code": code}``，
  供各模块 router 复用，保证错误结构一致。
"""

from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

_logger = logging.getLogger(__name__)


def error_response(code: str, message: str, status: int) -> JSONResponse:
    """构造统一的错误响应结构。

    :param code: 机器可读错误码（如 ``VALIDATION_ERROR`` / ``NOT_FOUND`` / ``INTERNAL``）。
    :param message: 面向用户的可读错误信息。
    :param status: HTTP 状态码。
    :return: 带 ``{"error": message, "code": code}`` 内容的 JSONResponse。
    """
    return JSONResponse(status_code=status, content={"error": message, "code": code})


def install_exception_handlers(app: FastAPI) -> None:
    """为 FastAPI 应用安装全局异常兜底 handler。

    未捕获的异常统一转为 ``500 {"error":"内部错误","code":"INTERNAL"}``，
    记 logger.exception 便于排查，但不向客户端泄露堆栈或内部细节。
    """

    @app.exception_handler(Exception)
    async def _unhandled_exception_handler(
        request: Request, exc: Exception
    ) -> JSONResponse:
        _logger.exception("未捕获的内部异常：%s", exc)
        return error_response("INTERNAL", "内部错误", 500)
