"""library repository 仓储层的集成测试与 hypothesis 属性测试。

覆盖设计文档 Correctness Properties 中的 Property 6~11：
- Property 6  写读往返一致
- Property 7  删除彻底
- Property 8  更新覆盖
- Property 9  持久化跨连接
- Property 10 筛选子集性
- Property 11 排序单调性

测试策略：全部使用真实的临时 SQLite 文件库（不用 :memory:，因为本设计每次操作
独立开关连接，内存库跨连接会丢数据）。集成测试用 pytest tmp_path fixture；属性
测试因 hypothesis 会复用同一测试函数跑多个 example，故每个 example 在函数内用
tempfile 新建唯一库文件，避免 example 之间互相污染。
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from app.modules.library import repository as repo
from app.modules.library.db import init_db
from app.modules.library.models import (
    LibraryItemCreate,
    LibraryItemUpdate,
    OwnershipStatus,
)
from app.shared import config


# ==================== fixtures / helpers ====================


@pytest.fixture()
def db_path(tmp_path) -> str:
    """提供一个已 init_db 的临时库路径，供集成测试注入。"""
    p = str(tmp_path / "lib_test.db")
    init_db(p)
    return p


def _fresh_db() -> str:
    """为属性测试的每个 example 新建一个唯一的临时库文件并建表，返回路径。

    每个 example 用独立文件，确保 example 之间数据互不干扰。临时目录由系统
    管理，测试后无需手动清理。
    """
    d = tempfile.mkdtemp(prefix="lib_pbt_")
    p = str(Path(d) / "lib.db")
    init_db(p)
    return p


def _full_item() -> LibraryItemCreate:
    """构造一条全字段的合法新建条目，供往返测试使用。"""
    return LibraryItemCreate(
        title="海贼王",
        author="尾田荣一郎",
        publisher="集英社",
        category="漫画",
        edition="日版",
        is_completed=False,
        total_volumes=105,
        latest_volume=105,
        ownership_status="已购",
        owned_count=105,
        purchase_price=100.0,
        sale_price=150.0,
        purchase_channel="书店",
    )


# ==================== 集成测试 ====================


class TestInsertGetRoundtrip:
    """写读往返一致性。"""

    def test_insert_then_get_all_fields(self, db_path):
        """insert 一条全字段后 get(id)，各字段应与写入一致。"""
        item = _full_item()
        new_id = repo.insert(item, db_path=db_path)
        assert isinstance(new_id, int) and new_id > 0

        got = repo.get(new_id, db_path=db_path)
        assert got is not None
        assert got["id"] == new_id
        assert got["title"] == "海贼王"
        assert got["author"] == "尾田荣一郎"
        assert got["category"] == "漫画"
        assert got["edition"] == "日版"
        # is_completed 以 bool 往返
        assert got["is_completed"] is False
        assert isinstance(got["is_completed"], bool)
        # ownership_status 以字符串存储
        assert got["ownership_status"] == "已购"
        # 价格 float 往返
        assert got["purchase_price"] == pytest.approx(100.0)
        assert got["sale_price"] == pytest.approx(150.0)
        # 时间戳存在且初始相等
        assert got["created_at"] == got["updated_at"]

    def test_is_completed_true_and_none_roundtrip(self, db_path):
        """is_completed 为 True / None 均能正确往返。"""
        id_true = repo.insert(
            LibraryItemCreate(title="完结书", is_completed=True), db_path=db_path
        )
        id_none = repo.insert(
            LibraryItemCreate(title="未知书", is_completed=None), db_path=db_path
        )
        assert repo.get(id_true, db_path=db_path)["is_completed"] is True
        assert repo.get(id_none, db_path=db_path)["is_completed"] is None

    def test_get_missing_returns_none(self, db_path):
        """get 不存在的 id 返回 None。"""
        assert repo.get(9999, db_path=db_path) is None


class TestUpdate:
    """更新覆盖行为。"""

    def test_update_reflects_new_values(self, db_path):
        """update 改 title/价格后 get 反映新值，且 updated_at >= created_at。"""
        new_id = repo.insert(_full_item(), db_path=db_path)
        before = repo.get(new_id, db_path=db_path)

        updated = LibraryItemUpdate(
            title="海贼王完全版",
            ownership_status="已售",
            purchase_price=120.0,
            sale_price=200.0,
        )
        ok = repo.update(new_id, updated, db_path=db_path)
        assert ok is True

        after = repo.get(new_id, db_path=db_path)
        assert after["title"] == "海贼王完全版"
        assert after["ownership_status"] == "已售"
        assert after["purchase_price"] == pytest.approx(120.0)
        assert after["sale_price"] == pytest.approx(200.0)
        # created_at 不变，updated_at 不早于 created_at
        assert after["created_at"] == before["created_at"]
        assert after["updated_at"] >= after["created_at"]

    def test_update_missing_returns_false(self, db_path):
        """更新不存在的 id 返回 False。"""
        ok = repo.update(9999, LibraryItemUpdate(title="x"), db_path=db_path)
        assert ok is False


class TestDelete:
    """删除彻底性。"""

    def test_delete_removes_from_get_and_list(self, db_path):
        """delete 后 get 为 None，且不在 list 中。"""
        new_id = repo.insert(_full_item(), db_path=db_path)
        assert repo.delete(new_id, db_path=db_path) is True

        assert repo.get(new_id, db_path=db_path) is None
        ids = [row["id"] for row in repo.list(db_path=db_path)]
        assert new_id not in ids

    def test_delete_missing_returns_false(self, db_path):
        """删除不存在的 id 返回 False。"""
        assert repo.delete(9999, db_path=db_path) is False


class TestListFilters:
    """列表筛选（精确 + 模糊搜索）。"""

    def _seed(self, db_path):
        """插入若干条不同属性的条目，返回 (title -> id) 映射。"""
        ids = {}
        ids["a"] = repo.insert(
            LibraryItemCreate(
                title="漫画A", category="漫画", edition="日版", ownership_status="想要"
            ),
            db_path=db_path,
        )
        ids["b"] = repo.insert(
            LibraryItemCreate(
                title="小说B", category="小说", edition="台版", ownership_status="已购"
            ),
            db_path=db_path,
        )
        ids["c"] = repo.insert(
            LibraryItemCreate(
                title="漫画C", category="漫画", edition="港版", ownership_status="已售"
            ),
            db_path=db_path,
        )
        return ids

    def test_filter_by_ownership_status(self, db_path):
        """按藏书状态筛选只返回匹配项。"""
        self._seed(db_path)
        rows = repo.list({"ownership_status": "已购"}, db_path=db_path)
        assert len(rows) == 1
        assert all(r["ownership_status"] == "已购" for r in rows)

    def test_filter_by_category(self, db_path):
        """按种类筛选只返回匹配项。"""
        self._seed(db_path)
        rows = repo.list({"category": "漫画"}, db_path=db_path)
        assert len(rows) == 2
        assert all(r["category"] == "漫画" for r in rows)

    def test_filter_by_edition(self, db_path):
        """按版本筛选只返回匹配项。"""
        self._seed(db_path)
        rows = repo.list({"edition": "台版"}, db_path=db_path)
        assert len(rows) == 1
        assert all(r["edition"] == "台版" for r in rows)

    def test_combined_filters_use_and(self, db_path):
        """多条件组合以 AND 生效。"""
        self._seed(db_path)
        rows = repo.list(
            {"category": "漫画", "ownership_status": "已售"}, db_path=db_path
        )
        assert len(rows) == 1
        assert rows[0]["title"] == "漫画C"

    def test_title_search_substring_case_insensitive(self, db_path):
        """书名搜索：子串匹配，且不区分大小写；中文/日文子串命中。"""
        repo.insert(LibraryItemCreate(title="Attack on Titan"), db_path=db_path)
        repo.insert(LibraryItemCreate(title="鬼灭の刃"), db_path=db_path)

        # 大小写混合子串
        rows = repo.list({"title_search": "TITAN"}, db_path=db_path)
        assert len(rows) == 1
        assert rows[0]["title"] == "Attack on Titan"

        # 日文子串
        rows2 = repo.list({"title_search": "の刃"}, db_path=db_path)
        assert len(rows2) == 1
        assert rows2[0]["title"] == "鬼灭の刃"


class TestListSort:
    """列表排序。"""

    def test_sort_by_purchase_price_asc_desc(self, db_path):
        """按 purchase_price 升序/降序返回有序结果。"""
        repo.insert(LibraryItemCreate(title="p1", purchase_price=30.0), db_path=db_path)
        repo.insert(LibraryItemCreate(title="p2", purchase_price=10.0), db_path=db_path)
        repo.insert(LibraryItemCreate(title="p3", purchase_price=20.0), db_path=db_path)

        asc = repo.list(
            {"sort_by": "purchase_price", "sort_dir": "asc"}, db_path=db_path
        )
        prices_asc = [r["purchase_price"] for r in asc]
        assert prices_asc == sorted(prices_asc)

        desc = repo.list(
            {"sort_by": "purchase_price", "sort_dir": "desc"}, db_path=db_path
        )
        prices_desc = [r["purchase_price"] for r in desc]
        assert prices_desc == sorted(prices_desc, reverse=True)

    def test_illegal_sort_by_falls_back_to_default(self, db_path):
        """非法排序字段不报错，回退默认（按 updated_at desc）。"""
        repo.insert(LibraryItemCreate(title="x"), db_path=db_path)
        repo.insert(LibraryItemCreate(title="y"), db_path=db_path)
        # 恶意/非法列名不应引发异常，也不应注入
        rows = repo.list(
            {"sort_by": "id; DROP TABLE library_items"}, db_path=db_path
        )
        assert len(rows) == 2

    def test_default_no_filter_returns_all(self, db_path):
        """无筛选返回全部条目。"""
        repo.insert(LibraryItemCreate(title="x"), db_path=db_path)
        repo.insert(LibraryItemCreate(title="y"), db_path=db_path)
        assert len(repo.list(db_path=db_path)) == 2


class TestCrossConnectionPersistence:
    """跨连接持久化：每次操作独立开关连接，天然验证落盘。"""

    def test_insert_then_reopen_get(self, db_path):
        """insert（连接已关闭）后重新 get 仍能读到，证明数据已落盘。"""
        new_id = repo.insert(_full_item(), db_path=db_path)
        # insert 内部已关闭连接；这里的 get 会开新连接
        got = repo.get(new_id, db_path=db_path)
        assert got is not None
        assert got["title"] == "海贼王"


# ==================== 属性测试（hypothesis） ====================

# 合法版本集合（含 None），供生成器采样。
_EDITIONS = list(config.ALL_EDITIONS) + [None]

# 非空、去空白后非空的书名。
_titles = st.text(min_size=1, max_size=30).filter(lambda s: s.strip() != "")
# 价格：0~1e6 的有限浮点，或 None。
_prices = st.one_of(
    st.none(),
    st.floats(min_value=0, max_value=1e6, allow_nan=False, allow_infinity=False),
)
_owners = st.sampled_from([s.value for s in OwnershipStatus])
_editions = st.sampled_from(_EDITIONS)
_categories = st.one_of(st.none(), st.sampled_from(["漫画", "小说", "画集"]))
_bools = st.one_of(st.none(), st.booleans())


@st.composite
def _library_items(draw) -> LibraryItemCreate:
    """生成一条合法的 LibraryItemCreate。"""
    return LibraryItemCreate(
        title=draw(_titles),
        category=draw(_categories),
        edition=draw(_editions),
        is_completed=draw(_bools),
        ownership_status=draw(_owners),
        purchase_price=draw(_prices),
        sale_price=draw(_prices),
    )


# Feature: library, Property 6: 写读往返一致
@settings(max_examples=30, deadline=None)
@given(item=_library_items())
def test_property_insert_get_roundtrip(item):
    p = _fresh_db()
    new_id = repo.insert(item, db_path=p)
    got = repo.get(new_id, db_path=p)
    assert got is not None
    assert got["title"] == item.title
    assert got["category"] == item.category
    assert got["edition"] == item.edition
    assert got["is_completed"] == item.is_completed  # bool/None 往返
    assert got["ownership_status"] == item.ownership_status.value
    # 价格 float / None 往返
    if item.purchase_price is None:
        assert got["purchase_price"] is None
    else:
        assert got["purchase_price"] == pytest.approx(item.purchase_price)
    if item.sale_price is None:
        assert got["sale_price"] is None
    else:
        assert got["sale_price"] == pytest.approx(item.sale_price)


# Feature: library, Property 7: 删除彻底
@settings(max_examples=30, deadline=None)
@given(item=_library_items())
def test_property_delete_is_thorough(item):
    p = _fresh_db()
    new_id = repo.insert(item, db_path=p)
    assert repo.delete(new_id, db_path=p) is True
    assert repo.get(new_id, db_path=p) is None
    assert new_id not in [r["id"] for r in repo.list(db_path=p)]


# Feature: library, Property 8: 更新覆盖
@settings(max_examples=30, deadline=None)
@given(item=_library_items(), new_title=_titles)
def test_property_update_overwrites(item, new_title):
    p = _fresh_db()
    new_id = repo.insert(item, db_path=p)
    updated = LibraryItemUpdate(title=new_title, ownership_status="已售")
    assert repo.update(new_id, updated, db_path=p) is True
    got = repo.get(new_id, db_path=p)
    assert got["title"] == new_title
    assert got["ownership_status"] == "已售"
    # ISO 8601 字符串可直接字典序比较
    assert got["updated_at"] >= got["created_at"]


# Feature: library, Property 9: 持久化跨连接
@settings(max_examples=30, deadline=None)
@given(item=_library_items())
def test_property_cross_connection_persistence(item):
    p = _fresh_db()
    # insert 用一次独立连接，get 用另一次独立连接
    new_id = repo.insert(item, db_path=p)
    got = repo.get(new_id, db_path=p)
    assert got is not None
    assert got["id"] == new_id


# Feature: library, Property 10: 筛选子集性
@settings(max_examples=30, deadline=None)
@given(items=st.lists(_library_items(), min_size=1, max_size=8))
def test_property_filter_is_subset(items):
    p = _fresh_db()
    for it in items:
        repo.insert(it, db_path=p)

    all_ids = {r["id"] for r in repo.list(db_path=p)}
    # 任取一个存在的筛选值
    target_status = items[0].ownership_status.value
    filtered = repo.list({"ownership_status": target_status}, db_path=p)

    filtered_ids = {r["id"] for r in filtered}
    # 子集性
    assert filtered_ids <= all_ids
    # 每条都满足筛选条件
    assert all(r["ownership_status"] == target_status for r in filtered)


# Feature: library, Property 11: 排序单调性
@settings(max_examples=30, deadline=None)
@given(
    prices=st.lists(
        st.floats(min_value=0, max_value=1e6, allow_nan=False, allow_infinity=False),
        min_size=1,
        max_size=8,
    )
)
def test_property_sort_is_monotonic(prices):
    p = _fresh_db()
    for i, price in enumerate(prices):
        repo.insert(
            LibraryItemCreate(title=f"book{i}", purchase_price=price), db_path=p
        )

    asc = [
        r["purchase_price"]
        for r in repo.list(
            {"sort_by": "purchase_price", "sort_dir": "asc"}, db_path=p
        )
    ]
    desc = [
        r["purchase_price"]
        for r in repo.list(
            {"sort_by": "purchase_price", "sort_dir": "desc"}, db_path=p
        )
    ]
    # 全部为非 None 价格，可直接判定单调
    assert asc == sorted(asc)
    assert desc == sorted(desc, reverse=True)
