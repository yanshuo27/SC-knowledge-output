"""library 图书管理模块的业务编排层（Service）。

本层位于 router 与 repository 之间，负责：

- 编排 repository（持久化）与 compute（计算字段），产出带 profit / profit_rate
  的输出模型 LibraryItemOut。
- 把「目标条目不存在」这一业务语义用领域异常 ItemNotFoundError 表达，供上层
  router 统一转换为 HTTP 404，而不泄露持久化细节。

计算字段现算约定（Property 12）：
    profit / profit_rate 不落库，每次组装 LibraryItemOut 时都基于当前的
    purchase_price / sale_price 现场计算，绝不从数据库行读取旧值。这样即便
    价格被更新，输出的计算字段也必定与最新价格一致。

所有对外函数都带 `db_path=None` 参数并原样透传给 repository，便于测试注入临时库。
"""

from __future__ import annotations

from app.modules.library import repository
from app.modules.library.compute import compute_profit, compute_profit_rate
from app.modules.library.models import (
    LibraryItemCreate,
    LibraryItemOut,
    LibraryItemUpdate,
)


class ItemNotFoundError(Exception):
    """请求的藏书条目不存在（供 router 转 404）。"""


def _to_out(row: dict) -> LibraryItemOut:
    """把 repository 返回的原始行 dict 组装为带计算字段的 LibraryItemOut。

    profit / profit_rate 每次都用行内当前的 purchase_price / sale_price 现算
    （不从 row 取旧值），保证计算字段与当前价格一致（Property 12）。

    row 不含 profit / profit_rate 两列，故可安全地 `**row` 展开后再补这两个
    关键字参数；row 中 ownership_status 是字符串，pydantic 会自动转为
    OwnershipStatus 枚举。
    """
    purchase = row.get("purchase_price")
    sale = row.get("sale_price")
    profit = compute_profit(purchase, sale)
    profit_rate = compute_profit_rate(purchase, sale)
    return LibraryItemOut(**row, profit=profit, profit_rate=profit_rate)


def create_item(item: LibraryItemCreate, db_path: str | None = None) -> LibraryItemOut:
    """新建一条藏书条目，返回带计算字段的输出模型。

    Args:
        item: 已通过模型校验的新建条目。
        db_path: 数据库文件路径；None 时用 config 默认库。

    Returns:
        新建条目的 LibraryItemOut（含 id 与现算的 profit / profit_rate）。
    """
    new_id = repository.insert(item, db_path)
    row = repository.get(new_id, db_path)
    return _to_out(row)


def get_item(item_id: int, db_path: str | None = None) -> LibraryItemOut:
    """按 id 读取单条藏书条目。

    Args:
        item_id: 目标条目 id。
        db_path: 数据库文件路径；None 时用 config 默认库。

    Returns:
        对应条目的 LibraryItemOut（含现算计算字段）。

    Raises:
        ItemNotFoundError: id 对应的条目不存在。
    """
    row = repository.get(item_id, db_path)
    if row is None:
        raise ItemNotFoundError(f"藏书条目不存在: id={item_id}")
    return _to_out(row)


def list_items(
    filters: dict | None = None, db_path: str | None = None
) -> list[LibraryItemOut]:
    """列出藏书条目，每条都带现算的计算字段。

    Args:
        filters: 筛选/排序条件字典，语义同 repository.list。
        db_path: 数据库文件路径；None 时用 config 默认库。

    Returns:
        LibraryItemOut 列表（顺序由 repository 的排序决定）。
    """
    rows = repository.list(filters, db_path)
    return [_to_out(row) for row in rows]


def update_item(
    item_id: int, item: LibraryItemUpdate, db_path: str | None = None
) -> LibraryItemOut:
    """全量覆盖更新一条藏书条目，返回刷新后的输出模型。

    Args:
        item_id: 目标条目 id。
        item: 全字段更新内容。
        db_path: 数据库文件路径；None 时用 config 默认库。

    Returns:
        更新后条目的 LibraryItemOut（计算字段随新价格刷新，Property 12）。

    Raises:
        ItemNotFoundError: id 对应的条目不存在。
    """
    ok = repository.update(item_id, item, db_path)
    if not ok:
        raise ItemNotFoundError(f"藏书条目不存在: id={item_id}")
    row = repository.get(item_id, db_path)
    return _to_out(row)


def delete_item(item_id: int, db_path: str | None = None) -> None:
    """按 id 删除一条藏书条目。

    Args:
        item_id: 目标条目 id。
        db_path: 数据库文件路径；None 时用 config 默认库。

    Raises:
        ItemNotFoundError: id 对应的条目不存在。
    """
    ok = repository.delete(item_id, db_path)
    if not ok:
        raise ItemNotFoundError(f"藏书条目不存在: id={item_id}")
