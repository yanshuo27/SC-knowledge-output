"""AdapterRegistry 单元测试（任务 6.3）。

用若干 stub adapter（实现 `DataSourceAdapter` 接口、给定 name 与 supported_editions）
注册进 registry，断言：
- 四类 Edition（日版/台版/港版/漫画）均能按 `EDITION_ADAPTER_MAP` 解析到对应的
  已注册 adapter；
- 未注册 adapter 名字的 Edition 返回空列表（港版落空场景，R5.4）；
- `search_adapters` 返回全部已注册 adapter（去重、保持注册顺序）。

_Requirements: 5.4, 5.5_
"""

from __future__ import annotations

from app.shared import config
from app.modules.book_lookup.adapters.base import DataSourceAdapter
from app.modules.book_lookup.models import Candidate, RawEditionRecord
from app.modules.book_lookup.registry import AdapterRegistry


class _StubAdapter(DataSourceAdapter):
    """最小可实例化的 stub：实现抽象接口，行为为"查不到"。

    仅用于验证注册/解析逻辑，不发起任何网络请求。
    """

    def __init__(self, name: str, supported_editions: list[str]) -> None:
        self.name = name
        self.supported_editions = list(supported_editions)

    async def search(self, title: str, client) -> list[Candidate]:  # noqa: D102
        return []

    async def fetch(  # noqa: D102
        self, candidate: Candidate, edition: str, client
    ) -> RawEditionRecord | None:
        return None


def _make_registry_with_all_sources() -> AdapterRegistry:
    """注册 config 中登记的全部数据源（含港版 hk_generic）。"""
    registry = AdapterRegistry()
    stubs = {
        config.SOURCE_OPENBD: [config.EDITION_JP],
        config.SOURCE_GOOGLE_BOOKS: [config.EDITION_JP, config.EDITION_MANGA],
        config.SOURCE_NDL: [config.EDITION_JP],
        config.SOURCE_BOOKS_COM_TW: [config.EDITION_TW],
        config.SOURCE_HK_GENERIC: [config.EDITION_HK],
    }
    for name, editions in stubs.items():
        registry.register(_StubAdapter(name, editions))
    return registry


def test_register_and_get():
    """按名注册后可按名取回；未注册名返回 None。"""
    registry = AdapterRegistry()
    adapter = _StubAdapter(config.SOURCE_OPENBD, [config.EDITION_JP])
    registry.register(adapter)

    assert registry.get(config.SOURCE_OPENBD) is adapter
    assert registry.get("not_registered") is None


def test_all_four_editions_resolve_to_mapped_adapters():
    """四类 Edition 均能按 EDITION_ADAPTER_MAP 解析到对应的已注册 adapter。"""
    registry = _make_registry_with_all_sources()

    for edition in config.ALL_EDITIONS:
        expected_names = config.EDITION_ADAPTER_MAP[edition]
        resolved = registry.adapters_for_edition(edition)
        # 名字与顺序均与映射声明一致。
        assert [a.name for a in resolved] == expected_names
        # 每个解析出的实例都是已注册对象。
        for a in resolved:
            assert registry.get(a.name) is a


def test_edition_maps_to_expected_specific_adapters():
    """逐 Edition 断言映射到的具体 adapter 名（防止映射被静默改动）。"""
    registry = _make_registry_with_all_sources()

    assert [a.name for a in registry.adapters_for_edition(config.EDITION_JP)] == [
        config.SOURCE_OPENBD,
        config.SOURCE_GOOGLE_BOOKS,
        config.SOURCE_NDL,
    ]
    assert [a.name for a in registry.adapters_for_edition(config.EDITION_TW)] == [
        config.SOURCE_BOOKS_COM_TW,
    ]
    assert [a.name for a in registry.adapters_for_edition(config.EDITION_HK)] == [
        config.SOURCE_HK_GENERIC,
    ]
    assert [a.name for a in registry.adapters_for_edition(config.EDITION_MANGA)] == [
        config.SOURCE_GOOGLE_BOOKS,
    ]


def test_edition_with_unregistered_adapter_returns_empty():
    """映射的 adapter 未注册时返回空列表（港版 hk_generic 未注册 → 落空，R5.4）。"""
    registry = AdapterRegistry()
    # 只注册非港版的源，故意不注册 hk_generic。
    registry.register(_StubAdapter(config.SOURCE_OPENBD, [config.EDITION_JP]))
    registry.register(_StubAdapter(config.SOURCE_BOOKS_COM_TW, [config.EDITION_TW]))

    assert registry.adapters_for_edition(config.EDITION_HK) == []


def test_edition_not_in_map_returns_empty():
    """映射中不存在的 Edition 返回空列表。"""
    registry = _make_registry_with_all_sources()
    assert registry.adapters_for_edition("不存在的版本") == []


def test_partial_registration_filters_unregistered_names():
    """某 Edition 映射多个源但只注册其中部分时，仅返回已注册者，保持顺序。"""
    registry = AdapterRegistry()
    # 日版映射 [openbd, google_books, ndl]，此处只注册 openbd 与 ndl。
    registry.register(_StubAdapter(config.SOURCE_OPENBD, [config.EDITION_JP]))
    registry.register(_StubAdapter(config.SOURCE_NDL, [config.EDITION_JP]))

    resolved = registry.adapters_for_edition(config.EDITION_JP)
    assert [a.name for a in resolved] == [config.SOURCE_OPENBD, config.SOURCE_NDL]


def test_search_adapters_returns_all_registered_dedup_ordered():
    """search_adapters 返回全部已注册 adapter，按注册顺序、去重。"""
    registry = AdapterRegistry()
    a1 = _StubAdapter(config.SOURCE_OPENBD, [config.EDITION_JP])
    a2 = _StubAdapter(config.SOURCE_GOOGLE_BOOKS, [config.EDITION_JP, config.EDITION_MANGA])
    registry.register(a1)
    registry.register(a2)

    assert registry.search_adapters() == [a1, a2]


def test_search_adapters_same_name_overrides():
    """同名重复注册以后者覆盖，search_adapters 不产生重复项。"""
    registry = AdapterRegistry()
    first = _StubAdapter(config.SOURCE_OPENBD, [config.EDITION_JP])
    second = _StubAdapter(config.SOURCE_OPENBD, [config.EDITION_JP])
    registry.register(first)
    registry.register(second)

    search_adapters = registry.search_adapters()
    assert search_adapters == [second]
    assert registry.get(config.SOURCE_OPENBD) is second


def test_empty_registry_returns_empty_for_all_editions():
    """空注册表下四类 Edition 均返回空列表，search_adapters 为空。"""
    registry = AdapterRegistry()
    for edition in config.ALL_EDITIONS:
        assert registry.adapters_for_edition(edition) == []
    assert registry.search_adapters() == []
