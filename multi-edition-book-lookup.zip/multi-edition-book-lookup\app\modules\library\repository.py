"""library 图书管理模块的 SQLite 持久化仓储层（Repository）。

本模块提供对 `library_items` 表的原子 CRUD 与列表查询，全部遵循以下约定：

- **每次操作独立开关连接**：每个函数内部通过 `db.get_connection(db_path)` 打开一条
  连接，操作完成后立即关闭。SQLite 轻量、单用户本地场景足够，且这种设计天然满足
  「跨连接持久化」——insert 与随后的 get 各用独立连接，数据必然已落盘。
- **SQL 全部参数化**：所有用户提供的值一律用 `?` 占位符传参，绝不用字符串拼接，
  杜绝 SQL 注入。
- **排序字段/方向走白名单**：ORDER BY 的字段名与方向无法参数化（SQL 语法限制），
  因此排序字段限定在白名单内、方向限定 asc/desc，非法输入回退到安全默认值。
- **计算字段不落库**：profit / profit_rate 不在表中，由 service 层读时现算，
  本层只负责存取原始字段。

数据类型转换约定：
- `is_completed`：模型层 bool | None ←→ 存储层 INTEGER 1/0/NULL。
- `ownership_status`：模型层枚举 ←→ 存储层 `.value` 字符串（如「已购」）。
- `created_at` / `updated_at`：ISO 8601 字符串，统一取 UTC 时间。
"""

from __future__ import annotations

import builtins
import sqlite3
from datetime import datetime, timezone

from app.modules.library.db import get_connection
from app.modules.library.models import LibraryItemCreate, LibraryItemUpdate

# 排序字段白名单：仅这些列允许出现在 ORDER BY 中，防止 SQL 注入与非法列名。
_SORT_WHITELIST = {
    "id",
    "title",
    "purchase_price",
    "sale_price",
    "created_at",
    "updated_at",
}

# 默认排序：无有效 sort_by 时按更新时间倒序（最近更新的排在前）。
_DEFAULT_SORT_BY = "updated_at"
_DEFAULT_SORT_DIR = "DESC"

# 持久化字段顺序（不含自增 id 与时间戳，时间戳单独处理）。
_ITEM_COLUMNS = [
    "title",
    "author",
    "publisher",
    "category",
    "edition",
    "is_completed",
    "total_volumes",
    "latest_volume",
    "ownership_status",
    "owned_count",
    "purchase_price",
    "sale_price",
    "purchase_channel",
]


def _now_iso() -> str:
    """返回当前 UTC 时间的 ISO 8601 字符串，用作 created_at / updated_at。"""
    return datetime.now(timezone.utc).isoformat()


def _bool_to_int(value: bool | None) -> int | None:
    """把 is_completed 的 bool | None 转换为存储层的 1 / 0 / None。"""
    if value is None:
        return None
    return 1 if value else 0


def _int_to_bool(value: int | None) -> bool | None:
    """把存储层的 1 / 0 / NULL 转换回 is_completed 的 True / False / None。"""
    if value is None:
        return None
    return bool(value)


def _row_to_dict(row: sqlite3.Row) -> dict:
    """把 sqlite3.Row 转为普通 dict，并把 is_completed 由 0/1/NULL 还原为 bool/None。"""
    d = dict(row)
    if "is_completed" in d:
        d["is_completed"] = _int_to_bool(d["is_completed"])
    return d


def _item_values(item: LibraryItemCreate | LibraryItemUpdate) -> list:
    """按 `_ITEM_COLUMNS` 顺序抽取 DTO 的持久化字段值（含类型转换）。

    - is_completed 转 1/0/None；
    - ownership_status 取枚举 `.value` 字符串；
    - 其余字段原样取用。
    """
    return [
        item.title,
        item.author,
        item.publisher,
        item.category,
        item.edition,
        _bool_to_int(item.is_completed),
        item.total_volumes,
        item.latest_volume,
        item.ownership_status.value,
        item.owned_count,
        item.purchase_price,
        item.sale_price,
        item.purchase_channel,
    ]


def insert(item: LibraryItemCreate, db_path: str | None = None) -> int:
    """插入一条藏书条目，返回新行的自增 id。

    created_at 与 updated_at 均设为当前 UTC 时间（初始相等）。

    Args:
        item: 已通过模型校验的新建条目。
        db_path: 数据库文件路径；None 时用 config 默认库。

    Returns:
        新插入行的 id（`cursor.lastrowid`）。
    """
    now = _now_iso()
    columns = _ITEM_COLUMNS + ["created_at", "updated_at"]
    placeholders = ", ".join(["?"] * len(columns))
    sql = f"INSERT INTO library_items ({', '.join(columns)}) VALUES ({placeholders})"
    values = _item_values(item) + [now, now]

    conn = get_connection(db_path)
    try:
        cursor = conn.execute(sql, values)
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def get(item_id: int, db_path: str | None = None) -> dict | None:
    """按 id 读取单条藏书条目。

    Args:
        item_id: 目标条目 id。
        db_path: 数据库文件路径；None 时用 config 默认库。

    Returns:
        条目 dict（is_completed 已还原为 bool/None），不存在时返回 None。
    """
    conn = get_connection(db_path)
    try:
        row = conn.execute(
            "SELECT * FROM library_items WHERE id = ?", (item_id,)
        ).fetchone()
        if row is None:
            return None
        return _row_to_dict(row)
    finally:
        conn.close()


def list(filters: dict | None = None, db_path: str | None = None) -> "builtins.list[dict]":
    """列出藏书条目，支持精确筛选、书名模糊搜索与排序。

    Args:
        filters: 筛选条件字典，支持以下键（均可选）：
            - ownership_status: 精确匹配藏书状态字符串。
            - category: 精确匹配种类。
            - edition: 精确匹配版本。
            - title_search: 书名模糊搜索关键词，用 LOWER(title) LIKE LOWER(%kw%)
              实现不区分大小写的子串匹配。
            - sort_by: 排序字段，须在白名单内，否则回退 updated_at。
            - sort_dir: 排序方向 asc/desc（不区分大小写），非法回退 desc。
        db_path: 数据库文件路径；None 时用 config 默认库。

    Returns:
        条目 dict 列表（每条 is_completed 已还原）。无筛选时返回全部，按
        updated_at 降序排列。
    """
    filters = filters or {}

    where_clauses: builtins.list[str] = []
    params: builtins.list = []

    # 精确筛选：逐个用参数化 ? 拼入 WHERE，用 AND 组合。
    if filters.get("ownership_status") is not None:
        where_clauses.append("ownership_status = ?")
        params.append(filters["ownership_status"])
    if filters.get("category") is not None:
        where_clauses.append("category = ?")
        params.append(filters["category"])
    if filters.get("edition") is not None:
        where_clauses.append("edition = ?")
        params.append(filters["edition"])

    # 书名模糊搜索：不区分大小写的子串匹配。关键词值仍走参数化，
    # 只有 LIKE 模式里的 % 由我们拼接，用户输入不进 SQL 文本。
    title_search = filters.get("title_search")
    if title_search:
        where_clauses.append("LOWER(title) LIKE LOWER(?)")
        params.append(f"%{title_search}%")

    where_sql = ""
    if where_clauses:
        where_sql = " WHERE " + " AND ".join(where_clauses)

    # 排序字段与方向必须经白名单/枚举校验后才拼进 SQL（无法参数化）。
    sort_by = filters.get("sort_by")
    if sort_by not in _SORT_WHITELIST:
        sort_by = _DEFAULT_SORT_BY

    sort_dir_raw = filters.get("sort_dir")
    if isinstance(sort_dir_raw, str) and sort_dir_raw.lower() == "asc":
        sort_dir = "ASC"
    else:
        sort_dir = "DESC"

    order_sql = f" ORDER BY {sort_by} {sort_dir}"

    sql = "SELECT * FROM library_items" + where_sql + order_sql

    conn = get_connection(db_path)
    try:
        rows = conn.execute(sql, params).fetchall()
        return [_row_to_dict(r) for r in rows]
    finally:
        conn.close()


def update(item_id: int, item: LibraryItemUpdate, db_path: str | None = None) -> bool:
    """全量覆盖更新一条藏书条目（PUT 语义）。

    刷新 updated_at 为当前 UTC 时间，created_at 保持不变。

    Args:
        item_id: 目标条目 id。
        item: 全字段更新内容。
        db_path: 数据库文件路径；None 时用 config 默认库。

    Returns:
        是否更新了行（True 表示 id 存在并已更新；id 不存在返回 False）。
    """
    now = _now_iso()
    set_sql = ", ".join([f"{col} = ?" for col in _ITEM_COLUMNS] + ["updated_at = ?"])
    sql = f"UPDATE library_items SET {set_sql} WHERE id = ?"
    values = _item_values(item) + [now, item_id]

    conn = get_connection(db_path)
    try:
        cursor = conn.execute(sql, values)
        conn.commit()
        return cursor.rowcount > 0
    finally:
        conn.close()


def delete(item_id: int, db_path: str | None = None) -> bool:
    """按 id 删除一条藏书条目。

    Args:
        item_id: 目标条目 id。
        db_path: 数据库文件路径；None 时用 config 默认库。

    Returns:
        是否删除了行（True 表示 id 存在并已删除；id 不存在返回 False）。
    """
    conn = get_connection(db_path)
    try:
        cursor = conn.execute("DELETE FROM library_items WHERE id = ?", (item_id,))
        conn.commit()
        return cursor.rowcount > 0
    finally:
        conn.close()
