"""library export 导出层的单元测试（纯内存，不依赖数据库）。

直接构造 LibraryItemOut 列表，验证 CSV / JSON 导出的关键性质：
- CSV：utf-8-sig BOM 开头、中文表头齐全、行数正确、中文可读、None 输出为空串、
  空清单只写表头。
- JSON：可被 json.loads 解析、中文不转义、计算字段存在（缺价为 null）、空清单为 []。
"""

from __future__ import annotations

import csv
import io
import json

from app.modules.library.export import EXPORT_FIELDS, to_csv, to_json
from app.modules.library.models import LibraryItemOut


# ==================== helpers ====================


def _sample_items() -> list[LibraryItemOut]:
    """构造两条样例条目：一条有完整价格与利润，一条缺卖出价（利润为 None）。"""
    with_profit = LibraryItemOut(
        id=1,
        title="海贼王",
        author="尾田荣一郎",
        publisher="集英社",
        category="漫画",
        edition="日版",
        is_completed=False,
        total_volumes=None,
        latest_volume=108,
        ownership_status="已购",
        owned_count=108,
        purchase_price=100.0,
        sale_price=150.0,
        purchase_channel="书店",
        profit=50.0,
        profit_rate=50.0,
        created_at="2024-01-01T00:00:00",
        updated_at="2024-01-02T00:00:00",
    )
    without_sale = LibraryItemOut(
        id=2,
        title="进击的巨人",
        author="谏山创",
        publisher=None,
        category="漫画",
        edition="台版",
        is_completed=True,
        total_volumes=34,
        latest_volume=34,
        ownership_status="想要",
        owned_count=None,
        purchase_price=80.0,
        sale_price=None,   # 缺卖出价 → profit / profit_rate 为 None
        purchase_channel=None,
        profit=None,
        profit_rate=None,
        created_at="2024-02-01T00:00:00",
        updated_at="2024-02-02T00:00:00",
    )
    return [with_profit, without_sale]


# ==================== CSV 测试 ====================


def test_to_csv_starts_with_utf8_bom():
    """返回的 bytes 以 UTF-8 BOM 开头（utf-8-sig）。"""
    result = to_csv(_sample_items())
    assert result[:3] == b"\xef\xbb\xbf"


def test_to_csv_header_and_row_count():
    """表头字段数量与 EXPORT_FIELDS 一致；数据行数 == len(items)。"""
    items = _sample_items()
    text = to_csv(items).decode("utf-8-sig")  # 去掉 BOM
    rows = list(csv.reader(io.StringIO(text)))
    # 第 1 行为表头，其余为数据行
    assert len(rows[0]) == len(EXPORT_FIELDS)
    assert len(rows) == 1 + len(items)


def test_to_csv_chinese_readable():
    """解码后内容包含中文书名与作者（中文可正确读取）。"""
    text = to_csv(_sample_items()).decode("utf-8-sig")
    assert "海贼王" in text
    assert "尾田荣一郎" in text


def test_to_csv_none_becomes_empty_string():
    """含 None 的字段导出为空串，而不是字面量 "None"。"""
    items = _sample_items()
    text = to_csv(items).decode("utf-8-sig")
    rows = list(csv.reader(io.StringIO(text)))

    # 全表不应出现 "None" 文本
    assert "None" not in text

    # 第 2 条数据行（rows[2]）对应缺卖出价的条目，sale_price / profit / profit_rate 应为空
    header = rows[0]
    data_row = rows[2]
    cell = dict(zip(EXPORT_FIELDS, data_row))
    # 表头是中文，但列顺序与 EXPORT_FIELDS 一致，故按位置取值
    assert cell["sale_price"] == ""
    assert cell["profit"] == ""
    assert cell["profit_rate"] == ""
    assert len(header) == len(EXPORT_FIELDS)


def test_to_csv_empty_list_header_only_with_bom():
    """空清单：解码后只有表头一行，且仍带 BOM。"""
    result = to_csv([])
    assert result[:3] == b"\xef\xbb\xbf"
    text = result.decode("utf-8-sig")
    rows = list(csv.reader(io.StringIO(text)))
    assert len(rows) == 1
    assert len(rows[0]) == len(EXPORT_FIELDS)


# ==================== JSON 测试 ====================


def test_to_json_parses_to_list_of_len():
    """to_json 可被 json.loads 解析为 list，长度 == len(items)。"""
    items = _sample_items()
    data = json.loads(to_json(items))
    assert isinstance(data, list)
    assert len(data) == len(items)


def test_to_json_chinese_not_escaped():
    """中文不转义：解析后第一条 title == "海贼王"。"""
    data = json.loads(to_json(_sample_items()))
    assert data[0]["title"] == "海贼王"
    # 直接看原始字节也应含未转义的中文
    raw = to_json(_sample_items()).decode("utf-8")
    assert "海贼王" in raw


def test_to_json_has_computed_fields_null_when_missing():
    """计算字段键存在；缺价的那条 profit / profit_rate 为 null。"""
    data = json.loads(to_json(_sample_items()))
    for entry in data:
        assert "profit" in entry
        assert "profit_rate" in entry
    # 第二条缺卖出价 → null
    assert data[1]["profit"] is None
    assert data[1]["profit_rate"] is None


def test_to_json_empty_list():
    """空清单：to_json([]) == b"[]"，且 json.loads 得 []。"""
    result = to_json([])
    assert result == b"[]"
    assert json.loads(result) == []
