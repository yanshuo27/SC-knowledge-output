"""CLI 入口示例单测（任务 13.4）。

覆盖：
- 无书名参数（非 --serve）→ 非零退出码 + 用法/错误提示到 stderr（R1.4）。
- 非法 --format → 提示含受支持取值（json, table）+ 非零退出（R12.5）。
- 端口占用（mock uvicorn.run 抛 OSError/EADDRINUSE）→ 提示 + 非零退出（R9.4）。
- table 输出格式：四版本对照表格，含四类 Edition 表头、字段行、免责说明、占位/未知文本。

用 FakeAdapter（来自 tests.conftest）组装真实 Aggregator 并注入 cli.run，避免真实网络。

_Requirements: 1.4, 9.4, 12.4, 12.5_
"""

from __future__ import annotations

import errno

import pytest

from app.modules.book_lookup import cli
from app.shared import config
from app.modules.book_lookup.aggregator import Aggregator
from app.modules.book_lookup.models import Candidate, Price, RawEditionRecord, SerializationStatus
from app.modules.book_lookup.registry import AdapterRegistry
from tests.conftest import FakeAdapter, make_raw


# --------------------------------------------------------------------------- #
# 辅助：用 FakeAdapter 组装 Aggregator                                        #
# --------------------------------------------------------------------------- #
def _build_aggregator(adapters: list) -> Aggregator:
    reg = AdapterRegistry()
    for a in adapters:
        reg.register(a)
    return Aggregator(reg, timeout_s=1.0)


def _one_candidate() -> Candidate:
    return Candidate(
        candidate_id="fake:1",
        title="葬送のフリーレン",
        source=config.SOURCE_GOOGLE_BOOKS,
    )


def _full_aggregator() -> Aggregator:
    """四类 Edition 各有映射源，日版/台版/漫画有结果、港版无结果（落占位）。"""
    cand = _one_candidate()

    openbd = FakeAdapter(
        config.SOURCE_OPENBD,
        supported_editions=[config.EDITION_JP],
        search_results=[cand],
        fetch_result={
            config.EDITION_JP: make_raw(
                config.EDITION_JP,
                config.SOURCE_OPENBD,
                title="葬送のフリーレン 1",
                author="山田鐘人",
                publisher="小学館",
                price=Price(amount=550, currency="JPY"),
                serialization_status=SerializationStatus.ONGOING,
                isbn="9784098501234",
                publish_date="2020-08-18",
            )
        },
    )
    gbooks = FakeAdapter(
        config.SOURCE_GOOGLE_BOOKS,
        supported_editions=[config.EDITION_JP, config.EDITION_MANGA],
        search_results=[cand],
        fetch_result={
            config.EDITION_MANGA: make_raw(
                config.EDITION_MANGA,
                config.SOURCE_GOOGLE_BOOKS,
                title="葬送のフリーレン",
                latest_volume=13,
            ),
        },
    )
    ndl = FakeAdapter(
        config.SOURCE_NDL,
        supported_editions=[config.EDITION_JP],
        search_results=[],
        fetch_result=None,
    )
    bkl = FakeAdapter(
        config.SOURCE_BOOKS_COM_TW,
        supported_editions=[config.EDITION_TW],
        search_results=[],
        fetch_result={
            config.EDITION_TW: make_raw(
                config.EDITION_TW,
                config.SOURCE_BOOKS_COM_TW,
                title="葬送的芙莉莲 1",
                price=Price(amount=140, currency="TWD"),
            )
        },
    )
    hk = FakeAdapter(
        config.SOURCE_HK_GENERIC,
        supported_editions=[config.EDITION_HK],
        search_results=[],
        fetch_result=None,  # 港版无结果 → 整版占位。
    )
    return _build_aggregator([openbd, gbooks, ndl, bkl, hk])


# --------------------------------------------------------------------------- #
# 无书名参数 → 非零退出 + 用法提示（R1.4）                                     #
# --------------------------------------------------------------------------- #
def test_main_no_title_exits_nonzero_with_usage(capsys):
    code = cli.main([])
    assert code != 0
    assert code == cli.EXIT_USAGE
    err = capsys.readouterr().err
    # 用法提示与错误说明到 stderr。
    assert "usage" in err.lower() or "用法" in err or "书名" in err


def test_main_blank_title_exits_nonzero(capsys):
    """纯空白书名也视为未提供 → 非零退出。"""
    code = cli.main(["   "])
    assert code != 0
    assert code == cli.EXIT_USAGE


# --------------------------------------------------------------------------- #
# 非法 --format → 提示含受支持取值 + 非零退出（R12.5）                         #
# --------------------------------------------------------------------------- #
def test_main_invalid_format_reports_supported_values(capsys, monkeypatch):
    # 注入 fake aggregator，避免真实网络（虽然格式校验先于查询，但稳妥起见）。
    monkeypatch.setattr(cli, "build_default_aggregator", _full_aggregator)

    code = cli.main(["葬送のフリーレン", "--format", "xml"])
    assert code != 0
    err = capsys.readouterr().err
    assert "json" in err and "table" in err


def test_validate_format_raises_for_invalid():
    with pytest.raises(cli.CliError) as excinfo:
        cli.validate_format("yaml")
    assert "json" in excinfo.value.message
    assert "table" in excinfo.value.message
    assert excinfo.value.exit_code != 0


@pytest.mark.parametrize("fmt", ["json", "table"])
def test_validate_format_accepts_valid(fmt):
    assert cli.validate_format(fmt) == fmt


# --------------------------------------------------------------------------- #
# 端口占用 → 提示 + 非零退出（R9.4），mock uvicorn.run 抛 OSError               #
# --------------------------------------------------------------------------- #
def test_serve_port_in_use_raises_cli_error(monkeypatch):
    import uvicorn

    def _raise_eaddrinuse(*args, **kwargs):
        raise OSError(errno.EADDRINUSE, "address in use")

    monkeypatch.setattr(uvicorn, "run", _raise_eaddrinuse)
    # 延迟 import 的 app.main 需可导入；若不可导入则跳过（不在本任务范围）。
    pytest.importorskip("app.main")

    with pytest.raises(cli.CliError) as excinfo:
        cli.serve(port=config.DEFAULT_PORT)
    assert excinfo.value.exit_code != 0
    assert str(config.DEFAULT_PORT) in excinfo.value.message


def test_main_serve_port_in_use_exits_nonzero(monkeypatch, capsys):
    import uvicorn

    def _raise_eaddrinuse(*args, **kwargs):
        raise OSError(errno.EADDRINUSE, "address in use")

    monkeypatch.setattr(uvicorn, "run", _raise_eaddrinuse)
    pytest.importorskip("app.main")

    code = cli.main(["--serve", "--port", "8123"])
    assert code != 0
    err = capsys.readouterr().err
    assert "8123" in err


def test_serve_starts_uvicorn_on_success(monkeypatch):
    """成功路径：serve 调用 uvicorn.run（用给定端口），不抛异常。"""
    import uvicorn

    called = {}

    def _fake_run(app, host, port):  # noqa: ANN001
        called["host"] = host
        called["port"] = port

    monkeypatch.setattr(uvicorn, "run", _fake_run)
    pytest.importorskip("app.main")

    cli.serve(port=8200)
    assert called["port"] == 8200


# --------------------------------------------------------------------------- #
# table 输出格式（R12.4）                                                      #
# --------------------------------------------------------------------------- #
def test_run_table_output_contains_editions_and_disclaimer(monkeypatch):
    output = cli.run("葬送のフリーレン", fmt="table", aggregator=_full_aggregator())

    # 四类 Edition 表头齐全。
    for ed in config.ALL_EDITIONS:
        assert ed in output

    # 字段标签存在。
    assert "书名" in output
    assert "定价" in output
    assert "来源" in output

    # 有结果的字段值。
    assert "葬送のフリーレン 1" in output  # 日版书名
    assert "550 JPY" in output            # 日版定价渲染
    assert "葬送的芙莉莲 1" in output       # 台版书名

    # 港版整版缺失 → 占位文本（取自后端常量，不硬编码）。
    assert config.MISSING_EDITION_PLACEHOLDER in output

    # 缺失字段 → N/A（后端 UNKNOWN_MARKER）。
    assert config.UNKNOWN_MARKER in output

    # 免责说明恒存在。
    assert config.SERIALIZATION_DISCLAIMER in output


def test_run_json_output_is_valid_json(monkeypatch):
    import json

    output = cli.run("葬送のフリーレン", fmt="json", aggregator=_full_aggregator())
    data = json.loads(output)

    # 四类 Edition 键齐全。
    assert set(data["editions"].keys()) == set(config.ALL_EDITIONS)
    # 免责说明存在。
    assert data["disclaimer"] == config.SERIALIZATION_DISCLAIMER
    # 港版占位。
    assert data["editions"][config.EDITION_HK]["present"] is False


def test_main_table_success_exit_zero(monkeypatch, capsys):
    monkeypatch.setattr(cli, "build_default_aggregator", _full_aggregator)

    code = cli.main(["葬送のフリーレン", "--format", "table"])
    assert code == cli.EXIT_OK
    out = capsys.readouterr().out
    assert config.EDITION_JP in out
    assert config.SERIALIZATION_DISCLAIMER in out


def test_main_no_candidates_reports_not_found(monkeypatch, capsys):
    """无候选 → 提示"未找到匹配作品"，正常退出（0）。"""

    def _empty_aggregator() -> Aggregator:
        # 所有源 search 都返回空 → 无候选。
        adapters = [
            FakeAdapter(
                config.SOURCE_OPENBD,
                supported_editions=[config.EDITION_JP],
                search_results=[],
            ),
        ]
        return _build_aggregator(adapters)

    monkeypatch.setattr(cli, "build_default_aggregator", _empty_aggregator)

    code = cli.main(["不存在的作品"])
    assert code == cli.EXIT_OK
    out = capsys.readouterr().out
    assert "未找到匹配作品" in out


# --------------------------------------------------------------------------- #
# select_candidate 纯逻辑（配合 Property 18）                                  #
# --------------------------------------------------------------------------- #
def test_select_candidate_empty_returns_none():
    selected, auto = cli.select_candidate([])
    assert selected is None
    assert auto is False


def test_select_candidate_single_no_auto():
    cand = _one_candidate()
    selected, auto = cli.select_candidate([cand])
    assert selected is cand
    assert auto is False


def test_select_candidate_multiple_picks_first_auto():
    c1 = Candidate(candidate_id="a:1", title="A", source=config.SOURCE_OPENBD)
    c2 = Candidate(candidate_id="b:2", title="B", source=config.SOURCE_NDL)
    selected, auto = cli.select_candidate([c1, c2])
    assert selected is c1
    assert auto is True
