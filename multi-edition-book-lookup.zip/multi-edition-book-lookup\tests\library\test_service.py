"""library service 业务编排层的集成测试与 hypothesis 属性测试。

覆盖设计文档 Correctness Property 12（计算字段随读重算）：service 层组装
LibraryItemOut 时，profit / profit_rate 必须基于当前 purchase_price /
sale_price 现算，与最新价格一致——即便价格被更新过。

测试策略与 repository 层一致：全部用真实的临时 SQLite 文件库（不用 :memory:，
因本设计每次操作独立开关连接，内存库跨连接会丢数据）。集成测试用 pytest
tmp_path fixture；属性测试因 hypothesis 会复用同一函数跑多个 example，故每个
example 在函数内用 tempfile 新建唯一库文件，避免相互污染。
"""

from __future__ import annotations

import math
import tempfile
from pathlib import Path

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from app.modules.library import service
from app.modules.library.compute import compute_profit, compute_profit_rate
from app.modules.library.db import init_db
from app.modules.library.models import LibraryItemCreate, LibraryItemUpdate
from app.modules.library.service import ItemNotFoundError


# ==================== fixtures / helpers ====================


@pytest.fixture()
def db_path(tmp_path) -> str:
    """提供一个已 init_db 的临时库路径，供集成测试注入。"""
    p = str(tmp_path / "lib_test.db")
    init_db(p)
    return p


def _fresh_db() -> str:
    """为属性测试的每个 example 新建一个唯一的临时库文件并建表，返回路径。"""
    d = tempfile.mkdtemp(prefix="lib_svc_pbt_")
    p = str(Path(d) / "lib.db")
    init_db(p)
    return p


def _item(purchase=100.0, sale=150.0, title="海贼王") -> LibraryItemCreate:
    """构造一条带指定买入/卖出价的合法新建条目。"""
    return LibraryItemCreate(
        title=title,
        ownership_status="已购",
        purchase_price=purchase,
        sale_price=sale,
    )


# ==================== 集成测试 ====================


def test_create_item_computes_profit_fields(db_path):
    """create_item：purchase=100/sale=150 → profit=50、rate=50.0，且带 id。"""
    out = service.create_item(_item(100.0, 150.0), db_path=db_path)
    assert out.id is not None
    assert out.profit == 50.0
    assert out.profit_rate == 50.0


def test_create_then_get_returns_same_content(db_path):
    """create 后 get_item 返回同样内容（含计算字段）。"""
    created = service.create_item(_item(100.0, 150.0), db_path=db_path)
    fetched = service.get_item(created.id, db_path=db_path)
    assert fetched.id == created.id
    assert fetched.title == created.title
    assert fetched.purchase_price == created.purchase_price
    assert fetched.sale_price == created.sale_price
    assert fetched.profit == created.profit
    assert fetched.profit_rate == created.profit_rate


def test_create_missing_sale_price_leaves_fields_none(db_path):
    """缺卖出价：purchase=100/sale=None → profit / profit_rate 均为 None。"""
    out = service.create_item(_item(100.0, None), db_path=db_path)
    assert out.profit is None
    assert out.profit_rate is None


def test_update_refreshes_computed_fields(db_path):
    """Property 12 核心：改价后计算字段随新价刷新。

    先 create(100/150)，再 update 成 purchase=100/sale=80 →
    profit=-20、rate=-20.0。
    """
    created = service.create_item(_item(100.0, 150.0), db_path=db_path)
    updated = service.update_item(
        created.id,
        LibraryItemUpdate(
            title="海贼王",
            ownership_status="已购",
            purchase_price=100.0,
            sale_price=80.0,
        ),
        db_path=db_path,
    )
    assert updated.profit == -20.0
    assert updated.profit_rate == -20.0


def test_get_missing_id_raises(db_path):
    """get_item 不存在 id → 抛 ItemNotFoundError。"""
    with pytest.raises(ItemNotFoundError):
        service.get_item(99999, db_path=db_path)


def test_update_missing_id_raises(db_path):
    """update_item 不存在 id → 抛 ItemNotFoundError。"""
    with pytest.raises(ItemNotFoundError):
        service.update_item(
            99999,
            LibraryItemUpdate(title="不存在", ownership_status="已购"),
            db_path=db_path,
        )


def test_delete_then_get_raises(db_path):
    """delete_item 后再 get_item 抛 ItemNotFoundError。"""
    created = service.create_item(_item(), db_path=db_path)
    service.delete_item(created.id, db_path=db_path)
    with pytest.raises(ItemNotFoundError):
        service.get_item(created.id, db_path=db_path)


def test_delete_missing_id_raises(db_path):
    """delete_item 不存在 id → 抛 ItemNotFoundError。"""
    with pytest.raises(ItemNotFoundError):
        service.delete_item(99999, db_path=db_path)


def test_list_items_each_has_computed_fields(db_path):
    """list_items 多条，每条都带正确的计算字段。"""
    service.create_item(_item(100.0, 150.0, title="书A"), db_path=db_path)
    service.create_item(_item(200.0, 180.0, title="书B"), db_path=db_path)
    service.create_item(_item(50.0, None, title="书C"), db_path=db_path)

    items = service.list_items(db_path=db_path)
    assert len(items) == 3
    for out in items:
        assert out.profit == compute_profit(out.purchase_price, out.sale_price)
        assert out.profit_rate == compute_profit_rate(
            out.purchase_price, out.sale_price
        )


# ==================== 属性测试（Property 12） ====================


@settings(max_examples=30, deadline=None)
@given(
    title=st.text(min_size=1).filter(lambda s: s.strip() != ""),
    purchase=st.one_of(
        st.none(),
        st.floats(min_value=0, max_value=1e6, allow_nan=False, allow_infinity=False),
    ),
    sale=st.one_of(
        st.none(),
        st.floats(min_value=0, max_value=1e6, allow_nan=False, allow_infinity=False),
    ),
)
def test_property_computed_fields_recomputed_on_read(title, purchase, sale):
    """Property 12：create 后 get_item，计算字段等于对当前价格现算的结果。

    Validates: Property 12
    """
    db = _fresh_db()
    item = LibraryItemCreate(
        title=title,
        ownership_status="已购",
        purchase_price=purchase,
        sale_price=sale,
    )
    created = service.create_item(item, db_path=db)
    out = service.get_item(created.id, db_path=db)

    expected_profit = compute_profit(out.purchase_price, out.sale_price)
    expected_rate = compute_profit_rate(out.purchase_price, out.sale_price)

    # profit
    if expected_profit is None:
        assert out.profit is None
    else:
        assert out.profit == pytest.approx(expected_profit)

    # profit_rate
    if expected_rate is None:
        assert out.profit_rate is None
    else:
        assert out.profit_rate == pytest.approx(expected_rate) or math.isclose(
            out.profit_rate, expected_rate, rel_tol=1e-9, abs_tol=1e-9
        )
