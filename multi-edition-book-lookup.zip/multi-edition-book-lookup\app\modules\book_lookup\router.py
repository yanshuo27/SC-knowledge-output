"""查书模块的 HTTP 路由层（router）。

本模块把原 `app/main.py` 中查书相关的路由处理函数抽出，通过
`register(app)` 约定挂载到共享的 FastAPI 实例上。逻辑与原内联版本一致，
不改变任何行为：

- ``GET  /api/health``：就绪探测。
- ``POST /api/search``：书名 → 候选列表（入参校验 EMPTY_TITLE）。
- ``POST /api/detail``：候选 → 四版本聚合结果（入参校验 MISSING_CANDIDATE）。
- ``GET  /``：前端入口（index.html，缺失时返回占位 HTML）。
- ``/static/*``：前端静态资源目录（web/ 存在才挂载）。

依赖（aggregator、client）继续从 ``request.app.state`` 取用，由 lifespan
装配。本模块只做「路由定义 + 把路由注册到传入的 app」，不涉及 lifespan 与
`build_registry` 的装配（那些仍在 main.py，由后续任务重写）。
"""

from __future__ import annotations

from pathlib import Path

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app.shared import config
from app.modules.book_lookup.aggregator import Aggregator
from app.modules.book_lookup.models import Candidate

# 前端静态资源目录（此处仅做存在性判断，不强制存在）。
# router.py 位于 app/modules/book_lookup/ 下，需回溯三级 parent 才到项目根。
_WEB_DIR = Path(__file__).resolve().parent.parent.parent.parent / "web"
_INDEX_HTML = _WEB_DIR / "index.html"

# 前端尚未就绪时返回的占位 HTML（GET / 文件不存在时用）。
_PLACEHOLDER_HTML = (
    "<!DOCTYPE html><html lang=\"zh\"><head><meta charset=\"utf-8\">"
    "<title>多版本书籍查询</title></head><body>"
    "<h1>多版本书籍查询</h1>"
    "<p>前端页面尚未就绪。API 可用：POST /api/search、POST /api/detail、"
    "GET /api/health。</p></body></html>"
)


def register(app: FastAPI) -> None:
    """把查书模块的路由注册到传入的 FastAPI 实例上。

    依赖（aggregator / client）由 lifespan 挂到 ``app.state``，路由处理函数
    从 ``request.app.state`` 取用。
    """

    # --- 健康检查 ---
    @app.get("/api/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    # --- 第一阶段：候选检索 ---
    @app.post("/api/search")
    async def search(request: Request) -> JSONResponse:
        payload = await request.json()
        title = payload.get("title") if isinstance(payload, dict) else None

        # 书名为空或纯空白 → 400 EMPTY_TITLE（R1.2）。校验发生在触发任何检索之前。
        if not isinstance(title, str) or title.strip() == "":
            return JSONResponse(
                status_code=400,
                content={"error": "书名不可为空", "code": "EMPTY_TITLE"},
            )

        aggregator: Aggregator = request.app.state.aggregator
        client: httpx.AsyncClient = request.app.state.client
        result = await aggregator.search_candidates(title, client)
        return JSONResponse(content=result.model_dump(mode="json"))

    # --- 第二阶段：四版本聚合 ---
    @app.post("/api/detail")
    async def detail(request: Request) -> JSONResponse:
        payload = await request.json()
        candidate_data = (
            payload.get("candidate") if isinstance(payload, dict) else None
        )

        # 缺少 candidate → 400 MISSING_CANDIDATE。
        if not candidate_data:
            return JSONResponse(
                status_code=400,
                content={"error": "缺少候选", "code": "MISSING_CANDIDATE"},
            )

        candidate = Candidate.model_validate(candidate_data)
        aggregator: Aggregator = request.app.state.aggregator
        client: httpx.AsyncClient = request.app.state.client
        result = await aggregator.aggregate_editions(candidate, client)
        return JSONResponse(content=result.model_dump(mode="json"))

    # --- 前端入口 ---
    @app.get("/", response_class=HTMLResponse)
    async def index() -> HTMLResponse:
        if _INDEX_HTML.is_file():
            return HTMLResponse(content=_INDEX_HTML.read_text(encoding="utf-8"))
        return HTMLResponse(content=_PLACEHOLDER_HTML)

    # --- 静态资源托管（web/ 目录存在才挂载；不存在则跳过，不影响 API） ---
    if _WEB_DIR.is_dir():
        app.mount("/static", StaticFiles(directory=str(_WEB_DIR)), name="static")
