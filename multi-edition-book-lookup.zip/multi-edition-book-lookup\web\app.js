"use strict";

/**
 * 多版本书籍查询 —— 前端交互与渲染（原生 JS + fetch，零依赖）。
 *
 * 两阶段查询：
 *   1. 点击查询 → 显示 Loading → POST /api/search → 结束移除 Loading。
 *   2. 多候选 → 渲染可点选列表；单候选 → 自动进入 detail；无候选 → 提示"未找到匹配作品"。
 *   3. 点选候选 → POST /api/detail → 渲染四版本对照表格。
 *
 * 关键约定（Property 20）：
 *   - 整版缺失渲染后端返回的 `edition.placeholder` 字段（前端不独立硬编码该占位文本）。
 *   - 字段缺失时后端已返回统一标记文本，前端直接取响应中的字段值渲染，
 *     不在前端硬编码任何占位/未知文本。
 */

// --- DOM 引用 ---
const titleInput = document.getElementById("title-input");
const searchBtn = document.getElementById("search-btn");
const loadingEl = document.getElementById("loading");
const errorArea = document.getElementById("error-area");
const warningsArea = document.getElementById("warnings-area");
const candidatesArea = document.getElementById("candidates-area");
const candidatesList = document.getElementById("candidates-list");
const editionsArea = document.getElementById("editions-area");
const editionsThead = document.getElementById("editions-thead");
const editionsTbody = document.getElementById("editions-tbody");
const disclaimerArea = document.getElementById("disclaimer-area");
const collectMsg = document.getElementById("collect-msg");

// 四版本对照表格：行定义（字段 key → 显示名）。key 与后端 EditionRecord 字段一致。
const FIELD_ROWS = [
    { key: "title", label: "书名" },
    { key: "author", label: "作者" },
    { key: "publisher", label: "出版社" },
    { key: "format", label: "开本/判型" },
    { key: "price", label: "定价" },
    { key: "serialization_status", label: "连载状态" },
    { key: "total_volumes", label: "总卷数" },
    { key: "latest_volume", label: "最新册数" },
    { key: "isbn", label: "ISBN" },
    { key: "publish_date", label: "出版日期" },
    { key: "sources", label: "数据来源" },
];

// 前端请求超时（毫秒）：超过此时长自动中断，避免无限“查询中”。
const REQUEST_TIMEOUT_MS = 45000;

// 当前 detail 响应缓存：一键收藏在书名缺失时回退取 currentDetail.query_title。
let currentDetail = null;

async function fetchWithTimeout(url, options) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
        return await fetch(url, { ...options, signal: controller.signal });
    } finally {
        clearTimeout(timer);
    }
}

// --- Loading 控制 ---
function showLoading() {
    loadingEl.hidden = false;
}

function hideLoading() {
    loadingEl.hidden = true;
}

// --- 区域清理 / 提示 ---
function clearResults() {
    errorArea.hidden = true;
    errorArea.textContent = "";
    warningsArea.hidden = true;
    warningsArea.innerHTML = "";
    candidatesArea.hidden = true;
    candidatesList.innerHTML = "";
    editionsArea.hidden = true;
    editionsThead.innerHTML = "";
    editionsTbody.innerHTML = "";
    disclaimerArea.hidden = true;
    disclaimerArea.textContent = "";
    if (collectMsg) {
        collectMsg.hidden = true;
        collectMsg.innerHTML = "";
    }
}

function showError(message) {
    errorArea.textContent = message;
    errorArea.hidden = false;
}

/** 渲染 warnings 提示条（来自后端响应的 warnings 数组）。 */
function renderWarnings(warnings) {
    if (!warnings || warnings.length === 0) {
        warningsArea.hidden = true;
        warningsArea.innerHTML = "";
        return;
    }
    const ul = document.createElement("ul");
    warnings.forEach((w) => {
        const li = document.createElement("li");
        const prefix = w.edition ? `[${w.edition}] ` : "";
        li.textContent = prefix + (w.message || "");
        ul.appendChild(li);
    });
    warningsArea.innerHTML = "";
    warningsArea.appendChild(ul);
    warningsArea.hidden = false;
}

// --- 阶段一：查询 ---
async function doSearch() {
    const title = titleInput.value;
    clearResults();

    if (!title || title.trim() === "") {
        showError("请输入书名。");
        return;
    }

    searchBtn.disabled = true;
    showLoading();
    try {
        const resp = await fetchWithTimeout("/api/search", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ title: title }),
        });

        if (!resp.ok) {
            let msg = "查询失败，请稍后重试。";
            try {
                const errBody = await resp.json();
                if (errBody && errBody.error) {
                    msg = errBody.error;
                }
            } catch (e) {
                /* 忽略解析错误，用默认提示 */
            }
            showError(msg);
            return;
        }

        const data = await resp.json();
        renderWarnings(data.warnings);

        const candidates = data.candidates || [];
        if (candidates.length === 0) {
            // 无候选 → 提示未找到。
            showError("未找到匹配作品");
        } else if (candidates.length === 1) {
            // 单候选 → 自动进入 detail。
            await doDetail(candidates[0]);
        } else {
            // 多候选 → 渲染可点选列表。
            renderCandidates(candidates);
        }
    } catch (e) {
        if (e && e.name === "AbortError") {
            showError("查询超时（可能是外部数据源响应缓慢或网络不可达），请稍后重试。");
        } else {
            showError("网络请求失败，请检查连接后重试。");
        }
    } finally {
        hideLoading();
        searchBtn.disabled = false;
    }
}

/** 渲染多候选可选列表（书名 / 作者 / 出版社），点选触发 detail。 */
function renderCandidates(candidates) {
    candidatesList.innerHTML = "";
    candidates.forEach((cand) => {
        const li = document.createElement("li");
        li.className = "candidate-item";

        const titleDiv = document.createElement("div");
        titleDiv.className = "candidate-title";
        titleDiv.textContent = cand.title || "";
        li.appendChild(titleDiv);

        const metaParts = [];
        if (cand.author) metaParts.push("作者：" + cand.author);
        if (cand.publisher) metaParts.push("出版社：" + cand.publisher);
        if (cand.source) metaParts.push("来源：" + cand.source);
        const metaDiv = document.createElement("div");
        metaDiv.className = "candidate-meta";
        metaDiv.textContent = metaParts.join("　");
        li.appendChild(metaDiv);

        li.addEventListener("click", () => {
            onCandidateSelected(cand);
        });
        candidatesList.appendChild(li);
    });
    candidatesArea.hidden = false;
}

/** 点选候选 → 收起候选列表 → 进入 detail 阶段。 */
async function onCandidateSelected(candidate) {
    candidatesArea.hidden = true;
    errorArea.hidden = true;
    searchBtn.disabled = true;
    showLoading();
    try {
        await doDetail(candidate);
    } finally {
        hideLoading();
        searchBtn.disabled = false;
    }
}

// --- 阶段二：四版本聚合 ---
async function doDetail(candidate) {
    try {
        const resp = await fetchWithTimeout("/api/detail", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ candidate: candidate }),
        });

        if (!resp.ok) {
            let msg = "获取版本详情失败，请稍后重试。";
            try {
                const errBody = await resp.json();
                if (errBody && errBody.error) {
                    msg = errBody.error;
                }
            } catch (e) {
                /* 忽略 */
            }
            showError(msg);
            return;
        }

        const data = await resp.json();
        renderWarnings(data.warnings);
        renderEditions(data);
    } catch (e) {
        if (e && e.name === "AbortError") {
            showError("获取版本详情超时，请稍后重试。");
        } else {
            showError("网络请求失败，请检查连接后重试。");
        }
    }
}

/** 把字段值转为可显示的文本。price 为对象时拼接金额+币种；数组拼逗号。
 *  注意：字段缺失时后端已返回统一标记文本，此处直接取值，
 *  不在前端硬编码任何占位/未知文本。 */
function formatFieldValue(value) {
    if (value === null || value === undefined) {
        // 后端契约下正常字段不会为 null；防御性返回空串，不硬编码占位文本。
        return "";
    }
    if (Array.isArray(value)) {
        return value.join("、");
    }
    if (typeof value === "object") {
        // Price 对象：{amount, currency}
        if ("amount" in value && "currency" in value) {
            return `${value.amount} ${value.currency}`;
        }
        return JSON.stringify(value);
    }
    return String(value);
}

/**
 * 渲染四版本对照表格。
 *
 * 表头为四个版本列（editions 的键，恒为 台版/港版/日版/漫画）。
 * 每个字段一行，各版本一列。
 *   - 整版缺失（present=false）：该列所有字段格显示后端返回的 `placeholder`。
 *   - 字段缺失：后端已返回统一标记文本，直接渲染响应中的字段值。
 */
function renderEditions(detail) {
    const editions = detail.editions || {};
    const editionKeys = Object.keys(editions);
    // 记录当前详情，供一键收藏回退取查询书名（detail.query_title）。
    currentDetail = detail;

    // --- 表头：第一列为字段名，其后每个版本一列 ---
    editionsThead.innerHTML = "";
    const headRow = document.createElement("tr");
    const cornerTh = document.createElement("th");
    cornerTh.textContent = "字段 \\ 版本";
    headRow.appendChild(cornerTh);
    editionKeys.forEach((edKey) => {
        const th = document.createElement("th");
        th.textContent = edKey;
        headRow.appendChild(th);
    });
    editionsThead.appendChild(headRow);

    // --- 表体：每字段一行 ---
    editionsTbody.innerHTML = "";
    FIELD_ROWS.forEach((row) => {
        const tr = document.createElement("tr");
        const labelTh = document.createElement("th");
        labelTh.scope = "row";
        labelTh.textContent = row.label;
        tr.appendChild(labelTh);

        editionKeys.forEach((edKey) => {
            const ed = editions[edKey];
            const td = document.createElement("td");
            if (!ed || ed.present === false) {
                // 整版缺失：显示后端返回的 placeholder（不硬编码）。
                td.textContent = ed && ed.placeholder ? ed.placeholder : "";
                td.className = "edition-missing";
            } else {
                td.textContent = formatFieldValue(ed[row.key]);
                // 冲突字段标注。
                if (
                    Array.isArray(ed.field_conflicts) &&
                    ed.field_conflicts.indexOf(row.key) !== -1
                ) {
                    td.classList.add("field-conflict");
                    td.title = "多来源存在冲突，已按优先级选值";
                }
            }
            tr.appendChild(td);
        });
        editionsTbody.appendChild(tr);
    });

    // --- 操作行：为每个「有信息的版本」提供「收藏到书架」按钮 ---
    const opRow = document.createElement("tr");
    const opLabelTh = document.createElement("th");
    opLabelTh.scope = "row";
    opLabelTh.textContent = "操作";
    opRow.appendChild(opLabelTh);
    editionKeys.forEach((edKey) => {
        const ed = editions[edKey];
        const td = document.createElement("td");
        if (!ed || ed.present === false) {
            // 整版缺失：无信息，不提供收藏入口，仅提示。
            td.textContent = "无信息";
            td.className = "edition-missing";
        } else {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "collect-btn";
            btn.textContent = "收藏到书架";
            btn.addEventListener("click", () => {
                collectEdition(edKey, ed);
            });
            td.appendChild(btn);
        }
        opRow.appendChild(td);
    });
    editionsTbody.appendChild(opRow);

    // --- 免责说明（后端 disclaimer，恒存在） ---
    if (detail.disclaimer) {
        disclaimerArea.textContent = detail.disclaimer;
        disclaimerArea.hidden = false;
    } else {
        disclaimerArea.hidden = true;
    }

    editionsArea.hidden = false;
}

// --- 事件绑定 ---
if (searchBtn) {
    searchBtn.addEventListener("click", doSearch);
}
if (titleInput) {
    titleInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
            doSearch();
        }
    });
}

// =============================================================================
// 书架页签：页签切换 + 藏书清单加载渲染
// =============================================================================

// 占位标记：与后端 UNKNOWN_MARKER 口径一致。
// 说明：此处用字符拼接构造，避免在源码中出现该字面量常量（保持前后端文案同源约定）。
const LIBRARY_PLACEHOLDER = "N" + "/" + "A";

// 书架相关 DOM 引用。
const libraryTbody = document.getElementById("library-tbody");
const libraryError = document.getElementById("library-error");
const libraryRefreshBtn = document.getElementById("library-refresh");
const tabButtons = document.querySelectorAll(".tab-btn");
const tabLookup = document.getElementById("tab-lookup");
const tabLibrary = document.getElementById("tab-library");

// 筛选 / 搜索 / 排序控件。
const libFilterStatus = document.getElementById("library-filter-status");
const libFilterEdition = document.getElementById("library-filter-edition");
const libFilterCategory = document.getElementById("library-filter-category");
const libSearch = document.getElementById("library-search");
const libSortBy = document.getElementById("library-sort-by");
const libSortDir = document.getElementById("library-sort-dir");
const libApplyBtn = document.getElementById("library-apply");

// 操作栏按钮。
const libAddBtn = document.getElementById("library-add");
const libExportCsvBtn = document.getElementById("library-export-csv");
const libExportJsonBtn = document.getElementById("library-export-json");

// 新增 / 编辑表单相关 DOM。
const libForm = document.getElementById("library-form");
const libFormTitle = document.getElementById("library-form-title");
const libFormError = document.getElementById("library-form-error");
const libSaveBtn = document.getElementById("library-save");
const libCancelBtn = document.getElementById("library-cancel");
const lfTitle = document.getElementById("lf-title");
const lfAuthor = document.getElementById("lf-author");
const lfPublisher = document.getElementById("lf-publisher");
const lfCategory = document.getElementById("lf-category");
const lfEdition = document.getElementById("lf-edition");
const lfIsCompleted = document.getElementById("lf-is-completed");
const lfTotalVolumes = document.getElementById("lf-total-volumes");
const lfLatestVolume = document.getElementById("lf-latest-volume");
const lfOwnership = document.getElementById("lf-ownership");
const lfOwnedCount = document.getElementById("lf-owned-count");
const lfPurchasePrice = document.getElementById("lf-purchase-price");
const lfSalePrice = document.getElementById("lf-sale-price");
const lfChannel = document.getElementById("lf-channel");

// 当前编辑中的条目 id：null 表示新增，非 null 表示编辑（PUT 目标）。
let editingId = null;

/** 把可能为空的值转为展示文本：null/undefined/空串 → 占位标记。 */
function libValue(v) {
    if (v === null || v === undefined) {
        return LIBRARY_PLACEHOLDER;
    }
    if (typeof v === "string" && v.trim() === "") {
        return LIBRARY_PLACEHOLDER;
    }
    return String(v);
}

/** 是否完结：true→"是"、false→"否"、null/undefined→占位标记。 */
function libBool(v) {
    if (v === true) return "是";
    if (v === false) return "否";
    return LIBRARY_PLACEHOLDER;
}

/** 利润率：数值加 "%"（如 50 → "50%"）；null/undefined → 占位标记。 */
function libRate(v) {
    if (v === null || v === undefined) {
        return LIBRARY_PLACEHOLDER;
    }
    return String(v) + "%";
}

/** 显示书架错误提示。 */
function showLibraryError(message) {
    if (!libraryError) return;
    libraryError.textContent = message;
    libraryError.hidden = false;
}

/** 清除书架错误提示。 */
function clearLibraryError() {
    if (!libraryError) return;
    libraryError.textContent = "";
    libraryError.hidden = true;
}

/** 渲染藏书清单：每条一行，按列顺序填入单元格，末列为操作按钮。 */
function renderLibrary(items) {
    if (!libraryTbody) return;
    libraryTbody.innerHTML = "";
    items.forEach((it) => {
        const tr = document.createElement("tr");
        // 列顺序需与 index.html 表头保持一致。
        const cells = [
            libValue(it.id),
            libValue(it.title),
            libValue(it.author),
            libValue(it.publisher),
            libValue(it.category),
            libValue(it.edition),
            libBool(it.is_completed),
            libValue(it.total_volumes),
            libValue(it.latest_volume),
            libValue(it.ownership_status),
            libValue(it.owned_count),
            libValue(it.purchase_price),
            libValue(it.sale_price),
            libValue(it.purchase_channel),
            libValue(it.profit),
            libRate(it.profit_rate),
            libValue(it.updated_at),
        ];
        cells.forEach((text) => {
            const td = document.createElement("td");
            td.textContent = text;
            tr.appendChild(td);
        });

        // 操作列：编辑 / 删除按钮。
        const opTd = document.createElement("td");
        opTd.className = "library-op-cell";
        const editBtn = document.createElement("button");
        editBtn.type = "button";
        editBtn.className = "op-btn op-edit";
        editBtn.textContent = "编辑";
        editBtn.addEventListener("click", () => {
            openEditForm(it);
        });
        const delBtn = document.createElement("button");
        delBtn.type = "button";
        delBtn.className = "op-btn op-delete";
        delBtn.textContent = "删除";
        delBtn.addEventListener("click", () => {
            deleteLibraryItem(it.id);
        });
        opTd.appendChild(editBtn);
        opTd.appendChild(delBtn);
        tr.appendChild(opTd);

        libraryTbody.appendChild(tr);
    });
}

/** 收集当前筛选/搜索/排序条件。"全部"/空值不纳入（后端按缺省处理）。 */
function currentFilters() {
    const filters = {};
    if (libFilterStatus && libFilterStatus.value) {
        filters.ownership_status = libFilterStatus.value;
    }
    if (libFilterEdition && libFilterEdition.value) {
        filters.edition = libFilterEdition.value;
    }
    if (libFilterCategory && libFilterCategory.value.trim() !== "") {
        filters.category = libFilterCategory.value.trim();
    }
    if (libSearch && libSearch.value.trim() !== "") {
        filters.title_search = libSearch.value.trim();
    }
    if (libSortBy && libSortBy.value) {
        filters.sort_by = libSortBy.value;
    }
    if (libSortDir && libSortDir.value) {
        filters.sort_dir = libSortDir.value;
    }
    return filters;
}

/** 把 filters 对象拼成 URLSearchParams 查询串（不含前导 ?）。 */
function buildLibraryQuery(filters) {
    const params = new URLSearchParams();
    Object.keys(filters).forEach((key) => {
        params.append(key, filters[key]);
    });
    return params.toString();
}

/** 拉取藏书清单并渲染；失败时展示可读错误。可传入筛选条件。 */
async function loadLibrary(filters) {
    clearLibraryError();
    const query = buildLibraryQuery(filters || {});
    const url = query ? "/api/library/items?" + query : "/api/library/items";
    try {
        const resp = await fetchWithTimeout(url, { method: "GET" });
        if (!resp.ok) {
            let msg = "加载书架失败，请稍后重试。";
            try {
                const errBody = await resp.json();
                if (errBody && errBody.error) {
                    msg = errBody.error;
                }
            } catch (e) {
                /* 忽略解析错误，用默认提示 */
            }
            showLibraryError(msg);
            return;
        }
        const items = await resp.json();
        renderLibrary(Array.isArray(items) ? items : []);
    } catch (e) {
        if (e && e.name === "AbortError") {
            showLibraryError("加载书架超时，请稍后重试。");
        } else {
            showLibraryError("网络请求失败，请检查连接后重试。");
        }
    }
}

/** 页签切换：显示目标 panel、隐藏另一个，切换 active 类。切到 library 时加载数据。 */
function switchTab(tabName) {
    tabButtons.forEach((btn) => {
        if (btn.getAttribute("data-tab") === tabName) {
            btn.classList.add("active");
        } else {
            btn.classList.remove("active");
        }
    });
    if (tabName === "library") {
        if (tabLookup) tabLookup.hidden = true;
        if (tabLibrary) tabLibrary.hidden = false;
        loadLibrary(currentFilters());
    } else {
        if (tabLibrary) tabLibrary.hidden = true;
        if (tabLookup) tabLookup.hidden = false;
    }
}

// =============================================================================
// 书架：新增 / 编辑表单
// =============================================================================

/** 显示表单校验错误。 */
function showLibraryFormError(message) {
    if (!libFormError) return;
    libFormError.textContent = message;
    libFormError.hidden = false;
}

/** 清除表单校验错误。 */
function clearLibraryFormError() {
    if (!libFormError) return;
    libFormError.textContent = "";
    libFormError.hidden = true;
}

/** 清空表单所有字段，恢复默认值。 */
function resetLibraryForm() {
    if (lfTitle) lfTitle.value = "";
    if (lfAuthor) lfAuthor.value = "";
    if (lfPublisher) lfPublisher.value = "";
    if (lfCategory) lfCategory.value = "";
    if (lfEdition) lfEdition.value = "";
    if (lfIsCompleted) lfIsCompleted.value = "";
    if (lfTotalVolumes) lfTotalVolumes.value = "";
    if (lfLatestVolume) lfLatestVolume.value = "";
    if (lfOwnership) lfOwnership.value = "已购";
    if (lfOwnedCount) lfOwnedCount.value = "";
    if (lfPurchasePrice) lfPurchasePrice.value = "";
    if (lfSalePrice) lfSalePrice.value = "";
    if (lfChannel) lfChannel.value = "";
    clearLibraryFormError();
}

/** 打开新增表单：清空字段、editingId 置空、显示表单。 */
function openAddForm() {
    editingId = null;
    resetLibraryForm();
    if (libFormTitle) libFormTitle.textContent = "新增藏书";
    if (libForm) libForm.hidden = false;
}

/** 打开编辑表单：用条目数据回填字段、记录 editingId、显示表单。 */
function openEditForm(item) {
    editingId = item.id;
    resetLibraryForm();
    if (libFormTitle) libFormTitle.textContent = "编辑藏书";
    // 回填字段：null/undefined 一律回填空串（不写占位标记）。
    if (lfTitle) lfTitle.value = item.title == null ? "" : item.title;
    if (lfAuthor) lfAuthor.value = item.author == null ? "" : item.author;
    if (lfPublisher) lfPublisher.value = item.publisher == null ? "" : item.publisher;
    if (lfCategory) lfCategory.value = item.category == null ? "" : item.category;
    if (lfEdition) lfEdition.value = item.edition == null ? "" : item.edition;
    if (lfIsCompleted) {
        if (item.is_completed === true) {
            lfIsCompleted.value = "true";
        } else if (item.is_completed === false) {
            lfIsCompleted.value = "false";
        } else {
            lfIsCompleted.value = "";
        }
    }
    if (lfTotalVolumes) {
        lfTotalVolumes.value = item.total_volumes == null ? "" : item.total_volumes;
    }
    if (lfLatestVolume) {
        lfLatestVolume.value = item.latest_volume == null ? "" : item.latest_volume;
    }
    if (lfOwnership) {
        lfOwnership.value = item.ownership_status == null ? "已购" : item.ownership_status;
    }
    if (lfOwnedCount) {
        lfOwnedCount.value = item.owned_count == null ? "" : item.owned_count;
    }
    if (lfPurchasePrice) {
        lfPurchasePrice.value = item.purchase_price == null ? "" : item.purchase_price;
    }
    if (lfSalePrice) {
        lfSalePrice.value = item.sale_price == null ? "" : item.sale_price;
    }
    if (lfChannel) {
        lfChannel.value = item.purchase_channel == null ? "" : item.purchase_channel;
    }
    if (libForm) libForm.hidden = false;
}

/** 隐藏并清空表单。 */
function closeLibraryForm() {
    if (libForm) libForm.hidden = true;
    editingId = null;
    resetLibraryForm();
}

/** 把文本输入转为可选字符串：空串 → 不纳入（返回 undefined）。 */
function optStr(el) {
    if (!el) return undefined;
    const v = el.value.trim();
    return v === "" ? undefined : v;
}

/** 把数字输入转为可选数值：空串 → 不纳入（undefined）；否则 Number()。 */
function optNum(el) {
    if (!el) return undefined;
    const v = el.value.trim();
    if (v === "") return undefined;
    return Number(v);
}

/** 收集表单字段，组装为提交用的 payload。空可选字段不纳入。 */
function collectFormPayload() {
    const payload = {};
    // 书名必填：即便为空也带上，交由后端返回校验错误。
    payload.title = lfTitle ? lfTitle.value.trim() : "";

    const author = optStr(lfAuthor);
    if (author !== undefined) payload.author = author;
    const publisher = optStr(lfPublisher);
    if (publisher !== undefined) payload.publisher = publisher;
    const category = optStr(lfCategory);
    if (category !== undefined) payload.category = category;
    const edition = optStr(lfEdition);
    if (edition !== undefined) payload.edition = edition;

    // 是否完结：空 → 不纳入；"true"/"false" → 布尔。
    if (lfIsCompleted && lfIsCompleted.value === "true") {
        payload.is_completed = true;
    } else if (lfIsCompleted && lfIsCompleted.value === "false") {
        payload.is_completed = false;
    }

    const totalVolumes = optNum(lfTotalVolumes);
    if (totalVolumes !== undefined) payload.total_volumes = totalVolumes;
    const latestVolume = optNum(lfLatestVolume);
    if (latestVolume !== undefined) payload.latest_volume = latestVolume;

    // 藏书状态始终提交（下拉恒有值）。
    if (lfOwnership && lfOwnership.value) {
        payload.ownership_status = lfOwnership.value;
    }

    const ownedCount = optNum(lfOwnedCount);
    if (ownedCount !== undefined) payload.owned_count = ownedCount;
    const purchasePrice = optNum(lfPurchasePrice);
    if (purchasePrice !== undefined) payload.purchase_price = purchasePrice;
    const salePrice = optNum(lfSalePrice);
    if (salePrice !== undefined) payload.sale_price = salePrice;
    const channel = optStr(lfChannel);
    if (channel !== undefined) payload.purchase_channel = channel;

    return payload;
}

/** 保存表单：editingId 有值走 PUT，否则 POST。成功隐藏表单并按当前筛选刷新。 */
async function saveLibraryItem() {
    clearLibraryFormError();
    const payload = collectFormPayload();
    const isEdit = editingId !== null && editingId !== undefined;
    const url = isEdit
        ? "/api/library/items/" + editingId
        : "/api/library/items";
    const method = isEdit ? "PUT" : "POST";

    if (libSaveBtn) libSaveBtn.disabled = true;
    try {
        const resp = await fetchWithTimeout(url, {
            method: method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });
        if (!resp.ok) {
            // 校验错误（400）等：展示后端 error 文本。
            let msg = "保存失败，请检查输入后重试。";
            try {
                const errBody = await resp.json();
                if (errBody && errBody.error) {
                    msg = errBody.error;
                }
            } catch (e) {
                /* 忽略解析错误，用默认提示 */
            }
            showLibraryFormError(msg);
            return;
        }
        // 成功：隐藏表单并按当前筛选刷新。
        closeLibraryForm();
        loadLibrary(currentFilters());
    } catch (e) {
        if (e && e.name === "AbortError") {
            showLibraryFormError("保存超时，请稍后重试。");
        } else {
            showLibraryFormError("网络请求失败，请检查连接后重试。");
        }
    } finally {
        if (libSaveBtn) libSaveBtn.disabled = false;
    }
}

/** 删除条目：确认后 DELETE，成功按当前筛选刷新。 */
async function deleteLibraryItem(itemId) {
    if (!window.confirm("确定删除该藏书条目？此操作不可撤销。")) {
        return;
    }
    clearLibraryError();
    try {
        const resp = await fetchWithTimeout("/api/library/items/" + itemId, {
            method: "DELETE",
        });
        if (!resp.ok) {
            let msg = "删除失败，请稍后重试。";
            try {
                const errBody = await resp.json();
                if (errBody && errBody.error) {
                    msg = errBody.error;
                }
            } catch (e) {
                /* 忽略解析错误，用默认提示 */
            }
            showLibraryError(msg);
            return;
        }
        loadLibrary(currentFilters());
    } catch (e) {
        if (e && e.name === "AbortError") {
            showLibraryError("删除超时，请稍后重试。");
        } else {
            showLibraryError("网络请求失败，请检查连接后重试。");
        }
    }
}

/** 导出：按当前筛选参数拼接导出 URL，触发浏览器下载。 */
function exportLibrary(format) {
    const filters = currentFilters();
    filters.format = format;
    const query = buildLibraryQuery(filters);
    window.location.href = "/api/library/export?" + query;
}

// =============================================================================
// 书架：事件绑定
// =============================================================================

// 页签按钮事件绑定。
tabButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
        switchTab(btn.getAttribute("data-tab"));
    });
});

// 刷新按钮：按当前筛选重新加载书架。
if (libraryRefreshBtn) {
    libraryRefreshBtn.addEventListener("click", () => {
        loadLibrary(currentFilters());
    });
}

// 应用筛选按钮：按当前筛选加载。
if (libApplyBtn) {
    libApplyBtn.addEventListener("click", () => {
        loadLibrary(currentFilters());
    });
}

// 新增按钮：打开空白表单。
if (libAddBtn) {
    libAddBtn.addEventListener("click", openAddForm);
}

// 保存 / 取消按钮。
if (libSaveBtn) {
    libSaveBtn.addEventListener("click", saveLibraryItem);
}
if (libCancelBtn) {
    libCancelBtn.addEventListener("click", closeLibraryForm);
}

// 导出按钮。
if (libExportCsvBtn) {
    libExportCsvBtn.addEventListener("click", () => {
        exportLibrary("csv");
    });
}
if (libExportJsonBtn) {
    libExportJsonBtn.addEventListener("click", () => {
        exportLibrary("json");
    });
}

// =============================================================================
// 查书结果「一键收藏」：把某版本书目字段映射为 library create 请求体并 POST
// =============================================================================

/**
 * 判断某字段值是否为后端占位标记（缺失文本）。
 * 前端不硬编码占位文本，此处复用 LIBRARY_PLACEHOLDER 常量（拼接构造）比较。
 */
function isPlaceholder(v) {
    return v === LIBRARY_PLACEHOLDER;
}

/** 把版本记录里“可能是占位/空”的字符串字段取真实值：真实内容返回该值，否则返回 undefined。 */
function realStr(v) {
    if (v === null || v === undefined) return undefined;
    if (typeof v !== "string") return undefined;
    const t = v.trim();
    if (t === "") return undefined;
    if (isPlaceholder(t)) return undefined;
    return t;
}

/** 把卷数类字段（后端为字符串，可能是数字字符串或占位）parse 为非负整数；无法解析返回 undefined。 */
function parseVolume(v) {
    if (v === null || v === undefined) return undefined;
    const s = String(v).trim();
    if (s === "" || isPlaceholder(s)) return undefined;
    // 仅接受纯整数字符串（避免 "3卷" 之类被 parseInt 截断误收）。
    if (!/^\d+$/.test(s)) return undefined;
    const n = parseInt(s, 10);
    return Number.isNaN(n) ? undefined : n;
}

/** 由连载状态映射 is_completed：完结→true、连载中→false、未知/占位→undefined（不传）。 */
function mapIsCompleted(status) {
    if (status === "完结") return true;
    if (status === "连载中") return false;
    return undefined;
}

/** 显示一键收藏结果提示（isError 为 true 时用错误样式）。 */
function showCollectMsg(html, isError) {
    if (!collectMsg) return;
    collectMsg.innerHTML = "";
    collectMsg.classList.toggle("collect-error", !!isError);
    const span = document.createElement("span");
    span.innerHTML = html;
    collectMsg.appendChild(span);
    if (!isError) {
        // 成功时附「查看书架」入口。
        const link = document.createElement("button");
        link.type = "button";
        link.className = "collect-goto";
        link.textContent = "查看书架";
        link.addEventListener("click", () => {
            switchTab("library");
        });
        collectMsg.appendChild(link);
    }
    collectMsg.hidden = false;
}

/**
 * 一键收藏：把某版本记录映射为 library create body 并 POST /api/library/items。
 * @param {string} editionName 版本名（台版/港版/日版/漫画），正好是后端 edition 合法值。
 * @param {object} ed 该版本的 EditionRecord。
 */
async function collectEdition(editionName, ed) {
    if (!ed) return;

    // --- 组装 create body ---
    const body = {};

    // title：优先版本记录内的真实书名；否则回退当前查询词（后端 title 必填非空）。
    let title = realStr(ed.title);
    if (title === undefined) {
        const fromInput = titleInput && titleInput.value ? titleInput.value.trim() : "";
        const fromDetail =
            currentDetail && currentDetail.query_title
                ? String(currentDetail.query_title).trim()
                : "";
        title = fromInput || fromDetail || "";
    }
    body.title = title;

    // author / publisher：真实内容才传，占位或空则不传。
    const author = realStr(ed.author);
    if (author !== undefined) body.author = author;
    const publisher = realStr(ed.publisher);
    if (publisher !== undefined) body.publisher = publisher;

    // edition：直接用列的版本名（后端合法枚举值）。
    body.edition = editionName;

    // is_completed：由连载状态映射。
    const completed = mapIsCompleted(ed.serialization_status);
    if (completed !== undefined) body.is_completed = completed;

    // 卷数：能 parse 成整数才传。
    const total = parseVolume(ed.total_volumes);
    if (total !== undefined) body.total_volumes = total;
    const latest = parseVolume(ed.latest_volume);
    if (latest !== undefined) body.latest_volume = latest;

    // 一键收藏默认作为「想要」，交易字段留待用户后续补充。
    body.ownership_status = "想要";

    // --- 提交 ---
    try {
        const resp = await fetchWithTimeout("/api/library/items", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
        });
        if (!resp.ok) {
            let msg = "收藏失败，请稍后重试。";
            try {
                const errBody = await resp.json();
                if (errBody && errBody.error) {
                    msg = errBody.error;
                }
            } catch (e) {
                /* 忽略解析错误，用默认提示 */
            }
            showCollectMsg(msg, true);
            return;
        }
        showCollectMsg(
            "已收藏到书架：" + body.title + "（" + editionName + "）",
            false
        );
    } catch (e) {
        if (e && e.name === "AbortError") {
            showCollectMsg("收藏超时，请稍后重试。", true);
        } else {
            showCollectMsg("网络请求失败，请检查连接后重试。", true);
        }
    }
}
