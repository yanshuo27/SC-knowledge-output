"""数据源适配器抽象基类。

所有真实数据源（openBD、Google Books、NDL、博客来、港版通用等）都必须实现
本模块定义的 `DataSourceAdapter` 抽象契约，从而保证：

- **可插拔**：新增数据源只需实现本接口并注册到 `AdapterRegistry`，无需改动编排层。
- **统一调度**：编排层（Aggregator）以相同方式并发调用每个 Adapter 的 `search` / `fetch`。

实现方约定（务必遵守，参见 design.md 的 Adapter 接口抽象与 Error Handling 章节）：

1. `search` / `fetch` 均为 `async`，共享由 Aggregator 注入的 `httpx.AsyncClient`
   （连接复用、无代理直连），实现方不得自行创建带代理的客户端。
2. Adapter 只负责"检索 + 解析成内部模型"，**不负责合并、不负责占位**：
   缺失字段一律置 `None`，交由 Merger 统一转为 `Unknown_Marker`。
3. **异常吞掉转空结果**：网络错误、DNS 失败、HTTP 4xx/5xx、超时、页面结构解析
   失败等源特有异常，实现方必须在 Adapter 内部捕获，`search` 返回 `[]`、
   `fetch` 返回 `None`，**绝不让异常穿透到编排层之外**（失败隔离由本约定与
   Aggregator 共同保证）。
4. 部分字段解析失败时，仅将该字段置 `None`，不影响其余字段。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from app.modules.book_lookup.models import Candidate, RawEditionRecord

if TYPE_CHECKING:  # 仅类型检查期引入，运行期避免强依赖 httpx 与潜在循环导入。
    import httpx


class DataSourceAdapter(ABC):
    """所有数据源适配器的统一契约。

    类属性：
        name: 数据源唯一名称（如 ``"openbd"``），用于来源集合与冲突选值优先级，
            必须与 `app.config.SOURCE_PRIORITY` / `EDITION_ADAPTER_MAP` 中登记的名字一致。
        supported_editions: 该源可服务的 Edition 列表（如 ``["日版", "漫画"]``）。

    实现方必须吞掉源特有异常，以空结果（``search`` → ``[]`` / ``fetch`` → ``None``）
    回报，绝不让异常穿透到编排层之外；缺失字段一律置 ``None``，由 Merger 统一处理。
    """

    name: str
    supported_editions: list[str]

    @abstractmethod
    async def search(self, title: str, client: "httpx.AsyncClient") -> list[Candidate]:
        """按书名检索候选，返回 0..N 个 `Candidate`。

        约定：
        - 查不到返回 ``[]``。
        - 任何源特有异常（网络/HTTP/解析/超时）必须在内部捕获并转为 ``[]``，
          不得向编排层抛出。

        Args:
            title: 用户输入的书名（已由上层校验非空）。
            client: 由 Aggregator 注入并复用的异步 HTTP 客户端（无代理直连）。

        Returns:
            候选作品列表；查不到时为空列表。
        """
        ...

    @abstractmethod
    async def fetch(
        self, candidate: Candidate, edition: str, client: "httpx.AsyncClient"
    ) -> RawEditionRecord | None:
        """针对指定候选与 Edition 抓取该源的单条原始记录。

        约定：
        - 查不到返回 ``None``。
        - 缺失字段以 ``None`` 表示（由 Merger 后续转为 ``Unknown_Marker``），
          不在 Adapter 层填占位。
        - 任何源特有异常必须在内部捕获并转为 ``None``，不得向编排层抛出。

        Args:
            candidate: search 阶段选定并回传的候选作品。
            edition: 目标 Edition（台版 / 港版 / 日版 / 漫画之一）。
            client: 由 Aggregator 注入并复用的异步 HTTP 客户端（无代理直连）。

        Returns:
            单源原始记录 `RawEditionRecord`；查不到时为 ``None``。
        """
        ...
