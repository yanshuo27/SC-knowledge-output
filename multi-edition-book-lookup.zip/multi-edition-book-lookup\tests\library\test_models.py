"""library 数据模型 models 的单元测试与 hypothesis 属性测试。

覆盖设计文档 Correctness Properties 中的 Property 13~15：
- Property 13 空书名必拒
- Property 14 枚举约束（ownership_status / edition）
- Property 15 非负约束（各数值字段）

同时验证合法样例可正常构造、默认藏书状态为「已购」。
"""

from __future__ import annotations

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st
from pydantic import ValidationError

from app.modules.library.models import (
    LibraryItemCreate,
    LibraryItemOut,
    OwnershipStatus,
)
from app.shared import config


# ==================== 单元测试 ====================

def test_full_valid_item():
    """全字段合法样例可成功构造，各字段值原样保留。"""
    item = LibraryItemCreate(
        title="海贼王",
        author="尾田荣一郎",
        publisher="集英社",
        category="漫画",
        edition="日版",
        is_completed=False,
        total_volumes=105,
        latest_volume=105,
        ownership_status="已购",
        owned_count=105,
        purchase_price=100.0,
        sale_price=150.0,
        purchase_channel="书店",
    )
    assert item.title == "海贼王"
    assert item.edition == "日版"
    assert item.ownership_status is OwnershipStatus.OWNED
    assert item.purchase_price == 100.0


def test_minimal_item_defaults():
    """最小样例（仅 title）可构造，藏书状态默认「已购」，其余为 None。"""
    item = LibraryItemCreate(title="孤独的美食家")
    assert item.title == "孤独的美食家"
    assert item.ownership_status is OwnershipStatus.OWNED
    assert item.author is None
    assert item.edition is None
    assert item.purchase_price is None


@pytest.mark.parametrize("bad_title", ["", "   ", "\t", "\n", "  \t \n "])
def test_blank_title_rejected(bad_title: str):
    """空串或纯空白书名被拒绝。"""
    with pytest.raises(ValidationError):
        LibraryItemCreate(title=bad_title)


def test_edition_none_ok():
    """版本为 None 通过校验。"""
    assert LibraryItemCreate(title="x", edition=None).edition is None


@pytest.mark.parametrize("edition", config.ALL_EDITIONS)
def test_edition_valid_values(edition: str):
    """四类合法版本均通过校验。"""
    assert LibraryItemCreate(title="x", edition=edition).edition == edition


def test_edition_invalid_rejected():
    """非法版本（美版）被拒绝。"""
    with pytest.raises(ValidationError):
        LibraryItemCreate(title="x", edition="美版")


@pytest.mark.parametrize("status", ["想要", "已购", "已售"])
def test_ownership_status_valid(status: str):
    """三种合法藏书状态均通过校验。"""
    assert LibraryItemCreate(title="x", ownership_status=status).ownership_status.value == status


def test_ownership_status_invalid_rejected():
    """非法藏书状态（借来的）被拒绝。"""
    with pytest.raises(ValidationError):
        LibraryItemCreate(title="x", ownership_status="借来的")


@pytest.mark.parametrize(
    "field",
    ["purchase_price", "sale_price", "owned_count", "total_volumes", "latest_volume"],
)
def test_negative_numeric_rejected(field: str):
    """任一数值字段为负均被拒绝。"""
    with pytest.raises(ValidationError):
        LibraryItemCreate(title="x", **{field: -1})


@pytest.mark.parametrize(
    "field",
    ["purchase_price", "sale_price", "owned_count", "total_volumes", "latest_volume"],
)
@pytest.mark.parametrize("value", [0, 1, 100])
def test_non_negative_numeric_ok(field: str, value: int):
    """数值字段为 0 或正数均通过校验。"""
    item = LibraryItemCreate(title="x", **{field: value})
    assert getattr(item, field) == value


def test_out_model_has_computed_and_meta_fields():
    """输出模型可携带 id、计算字段与时间戳。"""
    out = LibraryItemOut(
        id=1,
        title="x",
        profit=50.0,
        profit_rate=50.0,
        created_at="2024-01-01T00:00:00",
        updated_at="2024-01-02T00:00:00",
    )
    assert out.id == 1
    assert out.profit == 50.0
    assert out.profit_rate == 50.0
    assert out.created_at == "2024-01-01T00:00:00"


# ==================== 属性测试 ====================

# 合法版本 + None 的集合，用于在 Property 14 中过滤掉合法值
_VALID_EDITIONS_SET = set(config.ALL_EDITIONS)
_VALID_STATUS_SET = {s.value for s in OwnershipStatus}


# Feature: library, Property 13: 空书名必拒——纯空白或空串 title 恒被拒绝
@settings(max_examples=100)
@given(blank=st.text(alphabet=" \t\n\r\f\v", max_size=8))
def test_property_blank_title_rejected(blank: str):
    with pytest.raises(ValidationError):
        LibraryItemCreate(title=blank)


# Feature: library, Property 14: 枚举约束——非法 ownership_status 恒被拒绝
@settings(max_examples=100)
@given(status=st.text(min_size=1, max_size=12).filter(lambda s: s not in _VALID_STATUS_SET))
def test_property_invalid_ownership_status_rejected(status: str):
    with pytest.raises(ValidationError):
        LibraryItemCreate(title="x", ownership_status=status)


# Feature: library, Property 14: 枚举约束——非四类且非 None 的 edition 恒被拒绝
@settings(max_examples=100)
@given(edition=st.text(min_size=1, max_size=12).filter(lambda s: s not in _VALID_EDITIONS_SET))
def test_property_invalid_edition_rejected(edition: str):
    with pytest.raises(ValidationError):
        LibraryItemCreate(title="x", edition=edition)


# Feature: library, Property 15: 非负约束——任一整数数值字段取负恒被拒绝
@settings(max_examples=100)
@given(
    field=st.sampled_from(["owned_count", "total_volumes", "latest_volume"]),
    value=st.integers(max_value=-1),
)
def test_property_negative_int_rejected(field: str, value: int):
    with pytest.raises(ValidationError):
        LibraryItemCreate(title="x", **{field: value})


# Feature: library, Property 15: 非负约束——任一价格字段取负恒被拒绝
@settings(max_examples=100)
@given(
    field=st.sampled_from(["purchase_price", "sale_price"]),
    value=st.floats(max_value=-0.01, allow_nan=False, allow_infinity=False),
)
def test_property_negative_price_rejected(field: str, value: float):
    with pytest.raises(ValidationError):
        LibraryItemCreate(title="x", **{field: value})
