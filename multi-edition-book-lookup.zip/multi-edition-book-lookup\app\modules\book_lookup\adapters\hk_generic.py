"""港版繁中数据源适配器（占位/可选型）。

港版繁中书目数据在公开网络上极其零散，**没有统一且稳定的公开检索源**
（既无官方 API，也无可长期依赖的结构化页面）。为在缺少可靠来源时仍保持
系统行为稳定，本适配器设计为**占位型**：

- `search` 恒返回 `[]`。
- `fetch` 恒返回 `None`。

如此，港版这一 Edition 在编排层聚合时因所有映射 Adapter 均返回空，会被
Merger 稳定判定为整版缺失，落到 `MISSING_EDITION_PLACEHOLDER`（"无此版本信息"），
而非因抓取异常导致整体报错（R5.3 / R5.4）。

**保留可扩展结构**：未来若接入某个可靠的港版书目源（如某公开图书馆
目录或电商 API），只需在下方 `search` / `fetch` 的占位实现处填入真实的
抓取与解析逻辑，其余分层（Registry / Aggregator / Merger）无需改动。
届时同样必须遵守 base.py 的约定——把源特有异常吞掉转为空结果，缺失字段置 None。
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from app.shared import config
from app.modules.book_lookup.adapters.base import DataSourceAdapter
from app.modules.book_lookup.models import Candidate, RawEditionRecord

if TYPE_CHECKING:  # 仅类型检查期引入，运行期避免强依赖。
    import httpx


class HkGenericAdapter(DataSourceAdapter):
    """港版繁中占位适配器：当前无稳定公开源，检索恒空。

    行为契约（R5.3 / R5.4）：
    - ``search`` 恒返回 ``[]``。
    - ``fetch`` 恒返回 ``None``。

    使港版稳定落到整版缺失占位，而不引入不稳定抓取带来的失败风险。
    """

    name = config.SOURCE_HK_GENERIC
    supported_editions = [config.EDITION_HK]

    async def search(self, title: str, client: "httpx.AsyncClient") -> list[Candidate]:
        """占位实现：港版暂无稳定公开检索源，恒返回空候选列表。

        未来接入真实港版源时，在此处发起检索并解析为 ``list[Candidate]``，
        并遵守「异常吞掉转空结果」约定。
        """
        # 未来扩展点：此处填入真实港版源的检索与解析逻辑。
        return []

    async def fetch(
        self, candidate: Candidate, edition: str, client: "httpx.AsyncClient"
    ) -> RawEditionRecord | None:
        """占位实现：港版暂无稳定公开数据源，恒返回 ``None``。

        未来接入真实港版源时，在此处发起抓取并解析为 ``RawEditionRecord``，
        缺失字段置 ``None``，并遵守「异常吞掉转空结果」约定。
        """
        # 未来扩展点：此处填入真实港版源的抓取与解析逻辑。
        return None
