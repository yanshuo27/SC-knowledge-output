"""library 图书管理模块的数据传输对象（DTO）与校验规则。

使用 pydantic v2 定义藏书条目的输入/输出模型，并在模型层完成基础校验：
- 书名（title）去空白后必须非空（Property 13 / R3.1）。
- 版本（edition）为 None 或必须取自 ALL_EDITIONS（Property 14 / R3.3）。
- 藏书状态（ownership_status）用枚举天然限值（Property 14 / R3.2）。
- 数值字段（总卷数/最新册数/拥有册数/买入价/卖出价）不得为负（Property 15 / R3.4）。

校验失败一律抛出 pydantic ValidationError，由 router 层统一转换为 400 校验错误。
计算字段（profit/profit_rate）不落库、不由用户填写，仅出现在输出模型 LibraryItemOut 中。
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, field_validator

from app.shared import config


class OwnershipStatus(str, Enum):
    """藏书状态枚举，取值严格限定为「想要 / 已购 / 已售」（R2.5 / R3.2）。"""

    WANT = "想要"
    OWNED = "已购"
    SOLD = "已售"


class LibraryItemBase(BaseModel):
    """藏书条目基础模型，包含书目字段与交易字段。

    Create / Update 均直接继承本模型；Out 在此基础上补充 id、计算字段与时间戳。
    """

    # --- 书目字段（Book_Fields） ---
    title: str                              # 书名，必填且非空
    author: str | None = None               # 作者
    publisher: str | None = None            # 出版社
    category: str | None = None             # 种类（自由文本：漫画/小说/画集…）
    edition: str | None = None              # 版本，限 ALL_EDITIONS 或 None
    is_completed: bool | None = None        # 是否完结
    total_volumes: int | None = None        # 全套总卷数
    latest_volume: int | None = None        # 最新册数
    # --- 交易字段（Trade_Fields） ---
    ownership_status: OwnershipStatus = OwnershipStatus.OWNED  # 藏书状态，默认「已购」
    owned_count: int | None = None          # 拥有册数
    purchase_price: float | None = None     # 买入价格
    sale_price: float | None = None         # 卖出价格
    purchase_channel: str | None = None     # 购入渠道

    @field_validator("title")
    @classmethod
    def _validate_title_not_blank(cls, v: str) -> str:
        """校验书名去空白后非空，否则拒绝（Property 13 / R3.1）。"""
        if v is None or v.strip() == "":
            raise ValueError("书名不可为空")
        return v

    @field_validator("edition")
    @classmethod
    def _validate_edition(cls, v: str | None) -> str | None:
        """校验版本：None 直接通过；否则必须取自 ALL_EDITIONS（Property 14 / R3.3）。"""
        if v is None:
            return v
        if v not in config.ALL_EDITIONS:
            raise ValueError(
                f"版本必须为 {config.ALL_EDITIONS} 之一，或留空"
            )
        return v

    @field_validator(
        "total_volumes",
        "latest_volume",
        "owned_count",
        "purchase_price",
        "sale_price",
    )
    @classmethod
    def _validate_non_negative(cls, v: float | int | None) -> float | int | None:
        """校验数值字段非负：None 通过；小于 0 则拒绝（Property 15 / R3.4）。"""
        if v is None:
            return v
        if v < 0:
            raise ValueError("数值字段不可为负数")
        return v


class LibraryItemCreate(LibraryItemBase):
    """新增藏书条目的请求模型（手动录入与一键收藏共用同一入口）。"""

    pass


class LibraryItemUpdate(LibraryItemBase):
    """更新藏书条目的请求模型（PUT 全量覆盖，字段同 Base）。"""

    pass


class LibraryItemOut(LibraryItemBase):
    """藏书条目的输出模型，在基础字段之上补充 id、计算字段与时间戳。

    profit / profit_rate 为计算字段，不落库、读时现算；created_at / updated_at
    为 ISO 8601 字符串。
    """

    id: int
    profit: float | None = None             # 计算字段：利润
    profit_rate: float | None = None        # 计算字段：利润率（百分数值，如 25.0 表示 25%）
    created_at: str
    updated_at: str
