"""HkGenericAdapter（港版占位型）行为单测。

港版无稳定公开源，设计为占位型：search 恒 []、fetch 恒 None，
使港版稳定落到整版缺失占位（R5.3 / R5.4）。

不发起任何真实网络请求（占位实现根本不触网）。
async 测试依赖 pyproject 中 asyncio_mode = "auto"。
"""

from __future__ import annotations

import httpx
import pytest

from app.shared import config
from app.modules.book_lookup.adapters.hk_generic import HkGenericAdapter
from app.modules.book_lookup.models import Candidate


@pytest.fixture
def adapter() -> HkGenericAdapter:
    return HkGenericAdapter()


async def test_search_always_empty(adapter: HkGenericAdapter):
    """search 恒返回空列表。"""
    async with httpx.AsyncClient() as client:
        result = await adapter.search("葬送のフリーレン", client)
    assert result == []


async def test_search_empty_title_still_empty(adapter: HkGenericAdapter):
    """任意输入（含空串）search 恒返回空列表。"""
    async with httpx.AsyncClient() as client:
        result = await adapter.search("", client)
    assert result == []


async def test_fetch_always_none(adapter: HkGenericAdapter):
    """fetch 恒返回 None。"""
    candidate = Candidate(
        candidate_id=f"{config.SOURCE_HK_GENERIC}:x",
        title="任意书名",
        source=config.SOURCE_HK_GENERIC,
    )
    async with httpx.AsyncClient() as client:
        result = await adapter.fetch(candidate, config.EDITION_HK, client)
    assert result is None


def test_adapter_metadata(adapter: HkGenericAdapter):
    """name / supported_editions 与 config 常量一致（港版）。"""
    assert adapter.name == config.SOURCE_HK_GENERIC
    assert adapter.supported_editions == [config.EDITION_HK]
